#include "libtexturedescriptors.h"

double Distance(char *fv1_path, char *fv2_path)
{
  
  FeatureVector1D *gabor1=NULL;
  FeatureVector1D *gabor2=NULL;
  double distance;

  gabor1 = ReadFileFeatureVector1D(fv1_path);
  gabor2 = ReadFileFeatureVector1D(fv2_path);

  distance = EuclideanDistance(gabor1, gabor2);

  DestroyFeatureVector1D(&gabor1);
  DestroyFeatureVector1D(&gabor2);

  return (distance);
}

int main(int argc, char** argv)
{
  double distance;

  if (argc != 3) {
    fprintf(stderr,"usage: gch_distance <fv1_path> <fv2_path>\n");
    exit(-1);
  }

  distance=Distance(argv[1], argv[2]);

  printf("%f\n",distance);

  return(0);
}
