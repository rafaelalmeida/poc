#ifndef _STACK_H_
#define _STACK_H_

#include "common.h"

typedef struct _stack {
  int elem;
  struct _stack *next;
} Stack;

void PushStack(Stack **S, int elem);
int  PopStack(Stack **S);
void DestroyStack(Stack **S);

#endif
