#include "tensorscale.h" 

//#define TSDEBUG       1
//#define TSPROPAGATION 1

#ifdef TSDEBUG
#define MY_X 104
#define MY_Y 113
#endif

int TS_NearValue(float teta, float values[], int size){
  int i,j,k;

  i=0; j=size-1;
  while(j-i>1){
    k = (i+j)/2;
    if(teta>values[k])      i=k;
    else if(teta<values[k]) j=k;
    else return k;
  }

  if(teta-values[i] > values[j]-teta)  return j;
  else return i;
}

TensorScale *CreateTensorScale(Image *img, Image *mask, int m_pairs, int L, float stdDev){
  Point *epsilon;
  TensorScale *ts;
  Vector *tau;
  int i,j,k,ray,p,v,Imax;
  float val_p,val,threshold,threshold2,difacc1,difacc2,difacc3,dif;
  float x,y, taux, tauy;
  float a2,b2,teta,l1E,l2E,uu,vv,aux;
  float gSx2, gSy2, gSxy;
  float Su2v2,Su4,Sv4,Su2,Sv2;
  float sin_teta, cos_teta;
  int L2;
  int x1,x2,y1,y2,a,b,c,d,pp,qq;
  float dx1,dx2,dy1,dy2;
  int ncols,nrows,destroymask,box;
#ifdef TSPROPAGATION
  int **current,**previous,**pprevious,**change;
  float **cur_dac,**prev_dac,**pprev_dac,**change_dac;
  int *who_x,*who_y,posx,posy,pos;
  float angle[9];
#endif
#ifdef TSDEBUG
  CImage *cimg_edgelocation;

  cimg_edgelocation = Convert2CImage(img);
#endif

  L2 = L*L;
  ray = 0;
  ncols = img->ncols;
  nrows = img->nrows;
  if(mask==NULL){
    mask = CreateImage(ncols,nrows);
    SetImage(mask, 1);
    destroymask = 1;
  }
  else destroymask = 0;
  ts = (TensorScale *)malloc(sizeof(TensorScale));
  ts->orientation = CreateImage(ncols,nrows);
  ts->anisotropy = CreateImage(ncols,nrows);
  ts->thickness = CreateImage(ncols,nrows);
  ts->m_pairs = m_pairs;
  ts->L = L;

  Imax = MaximumValue(img);

  tau = (Vector *)malloc(sizeof(Vector)*m_pairs);
  epsilon = (Point *)malloc(sizeof(Point)*m_pairs);

#ifdef TSPROPAGATION
  who_x = (int *)malloc(sizeof(int)*m_pairs);
  who_y = (int *)malloc(sizeof(int)*m_pairs);
  
  current = (int **)malloc(sizeof(int *)*ncols);
  previous = (int **)malloc(sizeof(int *)*ncols);
  pprevious = (int **)malloc(sizeof(int *)*ncols);

  cur_dac = (float **)malloc(sizeof(float *)*ncols);
  prev_dac = (float **)malloc(sizeof(float *)*ncols);
  pprev_dac = (float **)malloc(sizeof(float *)*ncols);

  for(i=0;i<ncols;i++){
    current[i] = (int *)malloc(sizeof(int)*m_pairs);
    previous[i] = (int *)malloc(sizeof(int)*m_pairs);
    pprevious[i] = (int *)malloc(sizeof(int)*m_pairs);

    cur_dac[i] = (float *)malloc(sizeof(float)*m_pairs);
    prev_dac[i] = (float *)malloc(sizeof(float)*m_pairs);
    pprev_dac[i] = (float *)malloc(sizeof(float)*m_pairs);
  }

  angle[0] = 0;         //  0.00 graus
  angle[1] = 0.4636476; // 26.56 graus
  angle[2] = PI/4.0;    // 45.00 graus
  angle[3] = 1.1071487; // 63.43 graus
  angle[4] = PI/2.0;    // 90.00 graus
  angle[5] = 2.0344448; //116.56 graus
  angle[6] = 2.3561945; //135.00 graus
  angle[7] = 2.6779459; //153.43 graus
  angle[8] = PI;        //180.00 graus
#endif

  teta = 0.0;
  for(i=0;i<m_pairs;i++){
    tau[i].x = cos(teta);
    tau[i].y = sin(teta);
    tau[i].z = 0.0;

#ifdef TSPROPAGATION
    pos = TS_NearValue(teta,angle,9);
    if(pos==0 || pos==8){ who_x[i]=-1; who_y[i]=0;}
    else if(pos==1){ who_x[i]=-2;   who_y[i]=-1; }
    else if(pos==2){ who_x[i]=-1;   who_y[i]=-1; }
    else if(pos==3){ who_x[i]=-1;   who_y[i]=-2; }
    else if(pos==4){ who_x[i]=0;    who_y[i]=-1; }
    else if(pos==5){ who_x[i]=1;    who_y[i]=-2; }
    else if(pos==6){ who_x[i]=1;    who_y[i]=-1; }
    else if(pos==7){ who_x[i]=2;    who_y[i]=-1; }
#endif
    teta += ((float)PI/m_pairs); 
  }

  threshold = 3.00*stdDev;
  threshold2 = 2*threshold;
  for(i=0;i<nrows;i++){
#ifdef TSPROPAGATION
    change = pprevious;
    pprevious = previous;
    previous = current;
    current = change;

    change_dac = pprev_dac;
    pprev_dac = prev_dac;
    prev_dac = cur_dac;
    cur_dac = change_dac;
#endif
    for(j=0;j<ncols;j++){
      box = (i>=2 && j>=2 && j<ncols-2);
      p=img->tbrow[i]+j;
      val_p = img->val[p];
      if(mask->val[p] == 0){
#ifdef TSPROPAGATION
	for(ray=0;ray<m_pairs;ray++){
	  (current[j])[ray] = 1;
	  (cur_dac[j])[ray] = 0.0;
	}
#endif
	continue;
      }
      
      //--------- Sample lines --------------------------------------
      gSxy = gSx2 = gSy2 = 0.0;
      for(k=0;k<m_pairs;k++){
	x = taux = tau[k].x;
	y = tauy = tau[k].y;
	v=1;
	difacc1 =  0.0;

#ifdef TSPROPAGATION
	if(box){
	  posy = who_y[k];
	  if(posy==0){
	    v = (current[j-1])[k];
	    difacc1 = (cur_dac[j-1])[k];
	  }
	  else if(posy==-1){
	    posx = who_x[k];
	    v = (previous[j+posx])[k];
	    difacc1 = (prev_dac[j+posx])[k];
	  }
	  else if(posy==-2){
	    posx = who_x[k];
	    v = (pprevious[j+posx])[k];
	    difacc1 = (pprev_dac[j+posx])[k];
	  }
	  if(v>1){
	    x = v*taux;
	    y = v*tauy;
	  }
	  else v=1;
	}
#endif
	difacc2 = 0.0;
	for(;v<L;v++){
	  difacc3 = difacc2;
	  difacc2 = difacc1;
	  x1 = (int)(x+j);
	  y1 = (int)(y+i);
	  if(x1>=ncols-1 || y1>=nrows-1 || x1<=0 || y1<=0)
	    break;
	  x2 = x1+1;
	  y2 = y1+1;

	  pp = img->tbrow[y1];
	  qq = img->tbrow[y2];

	  a = img->val[pp+x1];
	  b = img->val[pp+x2];
	  c = img->val[qq+x1];
	  d = img->val[qq+x2];
	  
	  dx1 = x+j-x1; dx2 = x2-x-j;
	  dy1 = y+i-y1; dy2 = y2-y-i;
	  val = ((float)d*dx1+(float)c*dx2)*dy1+((float)b*dx1+(float)a*dx2)*dy2;
	  dif = ((val>val_p)?(val-val_p):(val_p-val));
	  difacc1 += dif;
	  if( dif > threshold )
	    break;

	  x1 = (int)(-x+j);
	  y1 = (int)(-y+i);
	  if(x1>=ncols-1 || y1>=nrows-1 || x1<=0 || y1<=0)
	    break;
	  x2 = x1+1;
	  y2 = y1+1;
	  
	  pp = img->tbrow[y1];
	  qq = img->tbrow[y2];

	  a = img->val[pp+x1];
	  b = img->val[pp+x2];
	  c = img->val[qq+x1];
	  d = img->val[qq+x2];
	  
	  val = ((float)d*dx2+(float)c*dx1)*dy2+((float)b*dx2+(float)a*dx1)*dy1;
	  dif = ((val>val_p)?(val-val_p):(val_p-val));
	  difacc1 += dif;	  
	  if( dif > threshold )
	    break;
	  if( difacc1 > threshold2 ){
	    v -=1;
	    x -= taux;
	    y -= tauy;
	    break;
	  }

	  x += taux; 
	  y += tauy; 
	}
	epsilon[k].x = x;
	epsilon[k].y = -y;

#ifdef TSPROPAGATION
	if(v<=5){ 
	  (current[j])[k] = 1;
	  (cur_dac[j])[k] = 0.0;
	}
	else{
	  (current[j])[k] = v-2-2;
	  (cur_dac[j])[k] = difacc3*(v-2-2)/(v-2);  
	}
#endif

#ifdef TSDEBUG
	//Draw the blue lines.
	if(i==MY_Y && j==MY_X){
	  for(ray=0;ray<v;ray++){
	    pp=img->tbrow[ROUND(i+ray*tauy)]+ROUND(j+ray*taux);
	    cimg_edgelocation->C[0]->val[pp]=0;
	    cimg_edgelocation->C[1]->val[pp]=0;
	    cimg_edgelocation->C[2]->val[pp]=255;
	    pp=img->tbrow[ROUND(i-ray*tauy)]+ROUND(j-ray*taux);
	    cimg_edgelocation->C[0]->val[pp]=0;
	    cimg_edgelocation->C[1]->val[pp]=0;
	    cimg_edgelocation->C[2]->val[pp]=255;
	  }
	}
#endif	
	
	gSxy += x*(-y);
	gSx2 += x*x; 
	gSy2 += y*y;
      }

      //-------------------- TETA -----------------------------------
      if(gSy2-gSx2==0.0){ 
	if(gSxy>0.0) teta=PI/4.0;
	else teta=-PI/4.0;
      }
      else teta=atan((2.0*gSxy)/(gSy2-gSx2))/2.0;

#ifdef TSDEBUG
      if(j==MY_X && i==MY_Y)
	printf("\n teta1 = %f, gSxy = %f, gSy2 = %f, gSx2 = %f\n",(teta/PI)*180,gSxy,gSy2,gSx2);
#endif

      if(gSxy<0.0 && teta<0.0) teta+=PI/2.0;
      else if(gSxy>0.0 && teta>0.0) teta-=PI/2.0;
      else if(gSxy==0 && gSy2>gSx2) teta=PI/2.0;
      else if(gSxy==0 && gSy2==gSx2) teta=0.0;

      //----------------- A & B ---------------------------------
      sin_teta = sin(teta);
      cos_teta = cos(teta);
      Su2v2 = Su2 = Sv2 = Su4 = Sv4 = 0.0;
      for(k=0;k<m_pairs;k++){
	uu = epsilon[k].x;
	vv = epsilon[k].y;
	aux = uu*cos_teta-vv*sin_teta;
	vv = vv*cos_teta+uu*sin_teta;
	uu = aux*aux;
	vv *= vv;
	Su2v2 += uu*vv;
	Su2 += uu;
	Sv2 += vv;
	Su4 += uu*uu;
	Sv4 += vv*vv;
      }

      aux = Su2v2*Su2v2-Su4*Sv4;
      a2 = (aux/(Su2v2*Sv2-Su2*Sv4));
      b2 = (aux/(Su2*Su2v2-Su4*Sv2));

      if(isnan(a2) || a2<0.0) a2=1.0;
      if(isnan(b2) || b2<0.0) b2=1.0;
      if(a2>L2) a2=L2;
      if(b2>L2) b2=L2;

      if(a2>=b2){
	l1E=a2; 
	l2E=b2;
      }
      else{
	l1E=b2;
	l2E=a2;
      }

      ts->anisotropy->val[p]=ROUND((INT_MAX)*(1.0-sqrt(l2E/l1E)));
      ts->thickness->val[p]=ROUND((INT_MAX)*sqrt(sqrt(l2E)/L));

      if(teta<0) teta+=(float)PI;
      if(teta>PI) teta-=((int)(teta/PI))*PI;
      teta = PI-teta;

      ts->orientation->val[p]=ROUND(teta*((INT_MAX)/PI));

#ifdef TSDEBUG
      if(j==MY_X && i==MY_Y){
	printf("\n orientation = %d, anisotropy = %d, ", ts->orientation->val[p], ts->anisotropy->val[p]);
	printf("thickness = %d\n", ts->thickness->val[p]);
	printf("\n tetafinal = %f\n",(teta/PI)*180);
      }
#endif
      
    }
  }

#ifdef TSDEBUG
  WriteCImage(cimg_edgelocation,"edgelocation.pgm");
  DestroyCImage(&cimg_edgelocation);
#endif

#ifdef TSPROPAGATION
  for(i=0;i<ncols;i++){
    free(current[i]);
    free(previous[i]);
    free(pprevious[i]);
  }
  free(current);
  free(previous);
  free(pprevious);
  free(who_x);
  free(who_y);
#endif

  free(tau);
  free(epsilon);

  if(destroymask) DestroyImage(&mask);

  return ts;
}

TensorScale *CreateBinaryTensorScale(Image *img, int m_pairs, int L, int label){
  Point *epsilon;
  TensorScale *ts;
  Vector *tau;
  int i,j,k,ray,p,v,Imax;
  float x,y, val_p, taux, tauy;
  float a2,b2,teta,l1E,l2E,uu,vv,aux;
  float gSx2, gSy2, gSxy;
  float Su2v2,Su4,Sv4,Su2,Sv2;
  float sin_teta, cos_teta;
  int L2;
  int x1,y1,a,pp;
  int ncols,nrows,box;
#ifdef TSPROPAGATION
  int **current,**previous,**pprevious,**change;
  int *who_x,*who_y,posx,posy,pos;
  float angle[9];
#endif
#ifdef TSDEBUG
  CImage *cimg_edgelocation;

  cimg_edgelocation = Convert2CImage(img);
#endif

  L2 = L*L;
  ray = 0;
  ncols = img->ncols;
  nrows = img->nrows;
  ts = (TensorScale *)malloc(sizeof(TensorScale));
  ts->orientation = CreateImage(ncols,nrows);
  ts->anisotropy = CreateImage(ncols,nrows);
  ts->thickness = CreateImage(ncols,nrows);
  ts->m_pairs = m_pairs;
  ts->L = L;

  Imax = MaximumValue(img);

  tau = (Vector *)malloc(sizeof(Vector)*m_pairs);
  epsilon = (Point *)malloc(sizeof(Point)*m_pairs);

#ifdef TSPROPAGATION
  who_x = (int *)malloc(sizeof(int)*m_pairs);
  who_y = (int *)malloc(sizeof(int)*m_pairs);
  current = (int **)malloc(sizeof(int *)*ncols);
  previous = (int **)malloc(sizeof(int *)*ncols);
  pprevious = (int **)malloc(sizeof(int *)*ncols);

  for(i=0;i<ncols;i++){
    current[i] = (int *)malloc(sizeof(int)*m_pairs);
    previous[i] = (int *)malloc(sizeof(int)*m_pairs);
    pprevious[i] = (int *)malloc(sizeof(int)*m_pairs);
  }

  angle[0] = 0;         //  0.00 graus
  angle[1] = 0.4636476; // 26.56 graus
  angle[2] = PI/4.0;    // 45.00 graus
  angle[3] = 1.1071487; // 63.43 graus
  angle[4] = PI/2.0;    // 90.00 graus
  angle[5] = 2.0344448; //116.56 graus
  angle[6] = 2.3561945; //135.00 graus
  angle[7] = 2.6779459; //153.43 graus
  angle[8] = PI;        //180.00 graus
#endif

  teta = 0.0;
  for(i=0;i<m_pairs;i++){
    tau[i].x = cos(teta);
    tau[i].y = sin(teta);
    tau[i].z = 0.0;

#ifdef TSPROPAGATION
    pos = TS_NearValue(teta,angle,9);
    if(pos==0 || pos==8){ who_x[i]=-1; who_y[i]=0;}
    else if(pos==1){ who_x[i]=-2;   who_y[i]=-1; }
    else if(pos==2){ who_x[i]=-1;   who_y[i]=-1; }
    else if(pos==3){ who_x[i]=-1;   who_y[i]=-2; }
    else if(pos==4){ who_x[i]=0;    who_y[i]=-1; }
    else if(pos==5){ who_x[i]=1;    who_y[i]=-2; }
    else if(pos==6){ who_x[i]=1;    who_y[i]=-1; }
    else if(pos==7){ who_x[i]=2;    who_y[i]=-1; }
#endif
    teta += ((float)PI/m_pairs); 
  }

  for(i=0;i<nrows;i++){
#ifdef TSPROPAGATION
    change = pprevious;
    pprevious = previous;
    previous = current;
    current = change;
#endif
    for(j=0;j<ncols;j++){
      box = (i>=2 && j>=2 && j<ncols-2);
      p=img->tbrow[i]+j;
      val_p = img->val[p];
      if(val_p != label){
#ifdef TSPROPAGATION
	for(ray=0;ray<m_pairs;ray++)
	  (current[j])[ray] = 1;
#endif
	continue;
      }
      
      //--------- Sample lines --------------------------------------
      gSxy = gSx2 = gSy2 = 0.0;
      for(k=0;k<m_pairs;k++){
	x = taux = tau[k].x;
	y = tauy = tau[k].y;
	v=1;

#ifdef TSPROPAGATION
	if(box){
	  posy = who_y[k];
	  if(posy==0)
	    v = (current[j-1])[k];
	  else if(posy==-1){
	    posx = who_x[k];
	    v = (previous[j+posx])[k];
	    if(posx>1 || posx<-1) v--;
	  }
	  else if(posy==-2)
	    v = (pprevious[j+who_x[k]])[k] - 1;

	  if(v>1){
	    x = v*taux;
	    y = v*tauy;
	  }
	  else v=1;
	}
#endif

	for(;v<L;v++){

	  x1 = ROUND(x+j);
	  y1 = ROUND(y+i);
	  if(x1>ncols-1 || y1>nrows-1 || x1<0 || y1<0)
	    break;
	  
	  pp = x1+img->tbrow[y1];
	  a = img->val[pp];
	  if(a != label){ 
	    x -= taux;
	    y -= tauy;
	    break;
	  }
	  
	  x1 = ROUND(-x+j);
	  y1 = ROUND(-y+i);
	  if(x1>ncols-1 || y1>nrows-1 || x1<0 || y1<0)
	    break;

	  pp = x1+img->tbrow[y1];
	  a = img->val[pp];
	  if(a != label){ 
	    x -= taux;
	    y -= tauy;
	    break;
	  }
	  
	  x += taux;
	  y += tauy;
	}
	epsilon[k].x = x;
	epsilon[k].y = -y;

#ifdef TSPROPAGATION
	if(v<=3) (current[j])[k] = 1;
	else (current[j])[k] = v-2;
#endif

#ifdef TSDEBUG
	//Draw the blue lines.
	if(i==MY_Y && j==MY_X){
	  for(ray=0;ray<v;ray++){
	    pp=img->tbrow[ROUND(i+ray*tauy)]+ROUND(j+ray*taux);
	    cimg_edgelocation->C[0]->val[pp]=0;
	    cimg_edgelocation->C[1]->val[pp]=0;
	    cimg_edgelocation->C[2]->val[pp]=255;
	    pp=img->tbrow[ROUND(i-ray*tauy)]+ROUND(j-ray*taux);
	    cimg_edgelocation->C[0]->val[pp]=0;
	    cimg_edgelocation->C[1]->val[pp]=0;
	    cimg_edgelocation->C[2]->val[pp]=255;
	  }
	}
#endif	
	
	gSxy += x*(-y);
	gSx2 += x*x; 
	gSy2 += y*y;
      }

      //-------------------- TETA -----------------------------------
      if(gSy2-gSx2==0.0){ 
	if(gSxy>0.0) teta=PI/4.0;
	else teta=-PI/4.0;
      }
      else teta=atan((2.0*gSxy)/(gSy2-gSx2))/2.0;

#ifdef TSDEBUG
      if(j==MY_X && i==MY_Y)
	printf("\n teta1 = %f, gSxy = %f, gSy2 = %f, gSx2 = %f\n",(teta/PI)*180,gSxy,gSy2,gSx2);
#endif

      if(gSxy<0.0 && teta<0.0) teta+=PI/2.0;
      else if(gSxy>0.0 && teta>0.0) teta-=PI/2.0;
      else if(gSxy==0 && gSy2>gSx2) teta=PI/2.0;
      else if(gSxy==0 && gSy2==gSx2) teta=0.0;

      //----------------- A & B ---------------------------------
      sin_teta = sin(teta);
      cos_teta = cos(teta);
      Su2v2 = Su2 = Sv2 = Su4 = Sv4 = 0.0;
      for(k=0;k<m_pairs;k++){
	uu = epsilon[k].x;
	vv = epsilon[k].y;
	aux = uu*cos_teta-vv*sin_teta;
	vv = vv*cos_teta+uu*sin_teta;
	uu = aux*aux;
	vv *= vv;
	Su2v2 += uu*vv;
	Su2 += uu;
	Sv2 += vv;
	Su4 += uu*uu;
	Sv4 += vv*vv;
      }

      aux = Su2v2*Su2v2-Su4*Sv4;
      a2 = (aux/(Su2v2*Sv2-Su2*Sv4));
      b2 = (aux/(Su2*Su2v2-Su4*Sv2));

      if(isnan(a2) || a2<0.0) a2=1.0;
      if(isnan(b2) || b2<0.0) b2=1.0;
      if(a2>L2) a2=L2;
      if(b2>L2) b2=L2;

      if(a2>=b2){
	l1E=a2; 
	l2E=b2;
      }
      else{
	l1E=b2;
	l2E=a2;
      }

      ts->anisotropy->val[p]=ROUND((INT_MAX)*(1.0-sqrt(l2E/l1E)));
      ts->thickness->val[p]=ROUND((INT_MAX)*sqrt(sqrt(l2E)/L));

      if(teta<0) teta+=(float)PI;
      if(teta>PI) teta-=((int)(teta/PI))*PI;
      teta = PI-teta;

      ts->orientation->val[p]=ROUND(teta*((INT_MAX)/PI));

#ifdef TSDEBUG
      if(j==MY_X && i==MY_Y){
	printf("\n orientation = %d, anisotropy = %d, ", ts->orientation->val[p], ts->anisotropy->val[p]);
	printf("thickness = %d\n", ts->thickness->val[p]);
	printf("\n tetafinal = %f\n",(teta/PI)*180);
      }
#endif
      
    }
  }

#ifdef TSDEBUG
  WriteCImage(cimg_edgelocation,"edgelocation.pgm");
  DestroyCImage(&cimg_edgelocation);
#endif

#ifdef TSPROPAGATION
  for(i=0;i<ncols;i++){
    free(current[i]);
    free(previous[i]);
    free(pprevious[i]);
  }
  free(current);
  free(previous);
  free(pprevious);
  free(who_x);
  free(who_y);
#endif

  free(tau);
  free(epsilon);

  return ts;
}

void DestroyTensorScale(TensorScale **ts){
  if(*ts != NULL){
    DestroyImage(&((*ts)->orientation));
    DestroyImage(&((*ts)->anisotropy));
    DestroyImage(&((*ts)->thickness));
    free(*ts);
  }
  *ts = NULL;
}

CImage *ConvertTS2CImage(TensorScale *ts){
  CImage *cimg;
  int i,j,w,h,p;
  int RR,GG,BB,tRGB;
  int HH,SS,VV;
  float ratio;

  ratio = 255.0/INT_MAX;
  w = ts->anisotropy->ncols;
  h = ts->anisotropy->nrows;
  cimg = CreateCImage(w,h);
  for(i=0; i<h; i++){
    for(j=0; j<w; j++){
      p=ts->anisotropy->tbrow[i]+j;
      SS=ROUND(ts->anisotropy->val[p]*ratio);
      VV=ROUND(ts->thickness->val[p]*ratio);
      HH=ROUND(ts->orientation->val[p]*ratio);

      tRGB = HSV2RGB(triplet(HH,SS,VV));
      RR = t0(tRGB);
      GG = t1(tRGB);
      BB = t2(tRGB);
      
      cimg->C[0]->val[p]=RR;
      cimg->C[1]->val[p]=GG;
      cimg->C[2]->val[p]=BB;      
    }
  }

  return cimg;
}


void OutputTSColorSpace(char *filename, int size){
  CImage *cimg_colorspace;
  int i,j,x,y,p;
  float val,teta;
  int HH,SS,VV,tRGB,RR,GG,BB;

  cimg_colorspace = CreateCImage(size,size);
  VV=255;
  for(i=0;i<size;i++){
    for(j=0;j<size;j++){
      y = -(i-size/2);
      x = j-size/2;
      val = sqrt(pow(x,2)+pow(y,2));
      if(x==0 && y>0) teta=PI/2;
      else if(x==0 && y<=0) teta=-PI/2;
      else teta = atan((float)y/(float)x); 
      if(x<0) teta+=PI;
      if(teta<0) teta+=2*PI;
      if(val<size/2-5){
	HH = (ROUND(teta*256.0/PI)%256);
	SS = ROUND(val*(255.0/(size/2-5)));
	tRGB = HSV2RGB(triplet(HH,SS,VV));
	RR = t0(tRGB);
	GG = t1(tRGB);
	BB = t2(tRGB);
	p = j+cimg_colorspace->C[0]->tbrow[i];
	cimg_colorspace->C[0]->val[p]=RR;
	cimg_colorspace->C[1]->val[p]=GG;
	cimg_colorspace->C[2]->val[p]=BB;
      }
    }
  }

  WriteCImage(cimg_colorspace,filename);
  DestroyCImage(&cimg_colorspace);
}


int *TSOrientationHistogram(TensorScale *ts){
  int *hist, bin;
  float ratio;
  int w,h,i,j,p,an,th;
  Image *img;
  
  ratio = 256.0/INT_MAX;
  hist = (int *)malloc(sizeof(int)*257);
  memset(hist, 0, sizeof(int)*257);
  w = ts->anisotropy->ncols;
  h = ts->anisotropy->nrows;
  img = CreateImage(w,h);
  SetImage(img, 0);
  for(i=0; i<h; i++){
    for(j=0; j<w; j++){
      p=ts->anisotropy->tbrow[i]+j;
      an = ts->anisotropy->val[p];
      th = ts->thickness->val[p];
      if(th<INT_MAX*0.6 && an>INT_MAX*0.4){
	bin=ROUND(ts->orientation->val[p]*ratio);  
	hist[bin]++;
	img->val[p] = 255;
      }
    }
  }
  hist[0] += hist[256];
  hist[256] = 0;

  WriteImage(img,"samplepoints.pgm");
  DestroyImage(&img);
  
  return hist;
}


CImage *TSShowHistograms(int *hist1, int *hist2, int offset){
  float newhist[512];
  float *newh1,*newh2;
  CImage *cimg;
  int n1,n2,i;
  float max1,max2,max;
  int col,row,col2,row2;
  int xsize=256*2, ysize=100*2;
  
  //Ajuste no histograma
  newh1=newhist;
  newh2=newhist+256;
  n1=n2=0;
  for(i=0;i<256;i++){
    n1+=hist1[i];
    n2+=hist2[i];
  }

  newh1[0]=(float)(hist1[0]+hist1[255]+hist1[1])/(3.0*n1);
  newh2[0]=(float)(hist2[0]+hist2[255]+hist2[1])/(3.0*n2);
  for(i=1;i<255;i++){
    newh1[i]=(float)(hist1[i]+hist1[i-1]+hist1[i+1])/(3.0*n1);
    newh2[i]=(float)(hist2[i]+hist2[i-1]+hist2[i+1])/(3.0*n2);
  }
  newh1[255]=(float)(hist1[255]+hist1[254]+hist1[0])/(3.0*n1);
  newh2[255]=(float)(hist2[255]+hist2[254]+hist2[0])/(3.0*n2);


  cimg = CreateCImage(10*2+xsize,10*2+ysize);
  SetImage(cimg->C[0], 255);
  SetImage(cimg->C[1], 255);
  SetImage(cimg->C[2], 255);
  TS_DrawLineDDA(cimg, 10, ysize+10, 10+xsize, ysize+10, 0, 0, 0);

  max1=max2=0.0;
  for(i=0;i<256;i++){
    if(newh1[i]>max1) max1=newh1[i];
    if(newh2[i]>max2) max2=newh2[i];
  }

  if(max1==0 || max2==0) exit(1);
  max = (max1>max2)?max1:max2;

  for(i=0;i<255;i++){
    row = 10+ysize*(max-newh1[(i+offset)%256])/max;
    col = xsize*(i/255.0)+10;
    row2 = 10+ysize*(max-newh1[(i+1+offset)%256])/max;
    col2 = xsize*((i+1)/255.0)+10;
    TS_DrawLineDDA(cimg, col, row, col2, row2, 255, 0, 0);

    row = 10+ysize*(max-newh2[i])/max;
    col = xsize*(i/255.0)+10;
    row2 = 10+ysize*(max-newh2[i+1])/max;
    col2 = xsize*((i+1)/255.0)+10;
    TS_DrawLineDDA(cimg, col, row, col2, row2, 0, 0, 255);
  }

  return cimg;
}

float TSHistogramMatch(int *hist1, int *hist2, int *offset){
  float newhist[512];
  float *newh1,*newh2;
  int n1,n2,i,j,p;
  float max,correlacao;
  float score;
  float dabs,dist_eucl,aux;
  
  //Ajuste no histograma
  newh1=newhist;
  newh2=newhist+256;
  n1=n2=0;
  for(i=0;i<256;i++){
    n1+=hist1[i];
    n2+=hist2[i];
  }

  newh1[0]=(float)(hist1[0]+hist1[255]+hist1[1])/(3.0*n1);
  newh2[0]=(float)(hist2[0]+hist2[255]+hist2[1])/(3.0*n2);
  for(i=1;i<255;i++){
    newh1[i]=(float)(hist1[i]+hist1[i-1]+hist1[i+1])/(3.0*n1);
    newh2[i]=(float)(hist2[i]+hist2[i-1]+hist2[i+1])/(3.0*n2);
  }
  newh1[255]=(float)(hist1[255]+hist1[254]+hist1[0])/(3.0*n1);
  newh2[255]=(float)(hist2[255]+hist2[254]+hist2[0])/(3.0*n2);

  //Correlacao
  *offset=0;
  max=0.0;
  for(i=0;i<256;i++){
    correlacao=0.0;
    //if(i==35) i=220; //angulo entre -24 e 24.
    for(p=i,j=0;j<256;j++,p++){
      if(p==256) p=0;
      correlacao+=(newh1[p]*newh2[j]);
    }

    if(correlacao>max){
      max=correlacao;
      *offset=i;
    }
  }

  dabs = 0.0;
  dist_eucl = 0.0;
  for(p=*offset,j=0;j<256;j++,p++){
    if(p==256) p=0;
    dist_eucl+=pow(newh1[p]-newh2[j],2.0);
    aux=(newh1[p]-newh2[j]);
    aux=(aux<0.0)?(-aux):(aux);
    dabs+=aux;
  }
  
  dist_eucl = sqrt(dist_eucl);
  score = 1.0 - dabs;

  return score;
}

void    TS_DrawLineDDA(CImage *cimg, int x1, int y1, int xn, int yn, int RR, int GG, int BB){  
  int vx, vy;
  float Dx, Dy;
  int amostras; /* número de pontos a serem pintados */
  float m; /* coeficiente angular da reta */
  int i;   /* usada no controle do loop */
  float xk, yk;
  int p;

  vx = xn - x1; /* componente x do vetor não unitario */
  vy = yn - y1; /* componente y do vetor não unitario */
  
   if(vx == 0){  
     Dx = 0.0;
     Dy = (float) SIGN(vy);
     amostras = abs(vy)+1;
   }
   else{  
     m = ((float)vy )/((float)vx);
     if( abs(vx) > abs(vy)){
       Dx = (float) SIGN(vx);
       Dy = m * Dx;
       amostras = abs(vx)+1; 
     }
     else{  
       Dy = (float) SIGN(vy);
       Dx = Dy / m;
       amostras = abs(vy)+1;
     }
   }
   
   xk = (float) x1;
   yk = (float) y1;
   for(i = 0; i < amostras; i++){ 
     p = ROUND(xk)+cimg->C[0]->tbrow[ROUND(yk)];
     cimg->C[0]->val[p]=RR;
     cimg->C[1]->val[p]=GG;
     cimg->C[2]->val[p]=BB;
     xk += Dx;
     yk += Dy;
   }
}
