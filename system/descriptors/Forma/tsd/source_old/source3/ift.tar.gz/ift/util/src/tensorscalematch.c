#include "ift.h"

int main(int argc, char **argv){
  timer tic,toc;
  Image *img,*img2,*label,*label2;
  CImage *cimg;
  TensorScale *ts,*ts2;
  char filename[200];
  int offset;
  float totaltime, stdDev;
  int *hist1,*hist2;
  float score;
  
  if (argc != 6) {
    fprintf(stderr,"usage: tsmatch <in:pgmfile> <mask:pgmfile> <in2:pgmfile> <mask2:pgmfile> <StdDev:float>\n");
    exit(-1);
  }

  // Le primeira imagem.
  sprintf(filename,"%s",argv[1]);
  img = ReadImage(filename);

  // Le mascara para primeira imagem. Somente pixels com valores de mascara 
  // diferente de zero serao considerados durante o calculo do tensorscale.
  // Mascara igual a NULL significa que todos pontos serao considerados.
  sprintf(filename,"%s",argv[2]);
  if(strcmp("NULL",filename)==0)
    label = NULL;
  else
    label = ReadImage(filename);

  // Le segunda imagem.
  sprintf(filename,"%s",argv[3]);
  img2 = ReadImage(filename);

  // Le mascara para segunda imagem. Somente pixels com valores de mascara 
  // diferente de zero serao considerados durante o calculo do tensorscale.
  // Mascara igual a NULL significa que todos pontos serao considerados.
  sprintf(filename,"%s",argv[4]);
  if(strcmp("NULL",filename)==0)
    label2 = NULL;
  else
    label2 = ReadImage(filename);

  // Parametro usado durante a fase de deteccao de bordas do tensorscale.
  // Se esse valor for muito grande bordas poderao nao ser detectadas corretamente.
  // Se ele for muito pequeno ruidos da imagem serao considerados.
  // Exemplo de possiveis valores: 5% de Imax, 1% de Imax, etc.
  stdDev = atof(argv[5]);

  // Calcula o tensorscale para a primeira imagem.
  gettimeofday(&tic,NULL);
  ts = CreateTensorScale(img, label, 24, 16, stdDev);
  gettimeofday(&toc,NULL);
  totaltime = (toc.tv_sec-tic.tv_sec)*1000.0 + (toc.tv_usec-tic.tv_usec)*0.001;
  printf("\nTime1: %f ms\n",totaltime);
  // Gera histograma da imagem de orientacao.
  hist1 = TSOrientationHistogram(ts);

  // Calcula o tensorscale para a segunda imagem.
  gettimeofday(&tic,NULL);
  ts2 = CreateTensorScale(img2, label2, 24, 16, stdDev);
  gettimeofday(&toc,NULL);
  totaltime = (toc.tv_sec-tic.tv_sec)*1000.0 + (toc.tv_usec-tic.tv_usec)*0.001;
  printf("\nTime2: %f ms\n",totaltime);
  // Gera histograma da imagem de orientacao.
  hist2 = TSOrientationHistogram(ts2);

  //for(i=0;i<256;i++){
  //  printf("i: %d, hist1: %d, hist2: %d\n",i,hist1[i],hist2[i]);
  //}

  // Gera imagem colorida com os atributos de thickness, anisotropy e 
  // orientation mapeados no espaco de cores HSV.
  cimg = ConvertTS2CImage(ts);
  WriteCImage(cimg,"ts1.pgm");
  DestroyCImage(&cimg);

  // Gera imagem colorida com os atributos de thickness, anisotropy e 
  // orientation mapeados no espaco de cores HSV.
  cimg = ConvertTS2CImage(ts2);
  WriteCImage(cimg,"ts2.pgm");
  DestroyCImage(&cimg);

  // Compara os histogramas de orientacao das duas imagens.
  score = TSHistogramMatch(hist1, hist2, &offset);
  printf("\nScore: %f, offset: %d\n",score,offset); /* Para converter
						       o offset em
						       angulo, nos
						       dividimos por
						       256 (numero de
						       bins do
						       histograma) e
						       multiplicamos
						       por 180 */
  cimg = TSShowHistograms(hist1, hist2, offset);
  WriteCImage(cimg,"plot.pgm");
  DestroyCImage(&cimg);

  DestroyImage(&img);
  if(label!=NULL) DestroyImage(&label);
  DestroyTensorScale(&ts);

  DestroyImage(&img2);
  if(label2!=NULL) DestroyImage(&label2);
  DestroyTensorScale(&ts2);

  return 0;
}
 
