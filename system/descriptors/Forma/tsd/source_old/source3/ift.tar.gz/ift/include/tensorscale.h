#ifndef TENSORSCALE_H
#define TENSORSCALE_H 1

#include "common.h"
#include "image.h"
#include "cimage.h"
#include "geometry.h"
#include "color.h"
#include "adjacency.h"

typedef struct _tensorscale{
  Image *anisotropy;
  Image *orientation;
  Image *thickness;

  int m_pairs;
  int L;
}TensorScale;

TensorScale *CreateTensorScale(Image *img, Image *mask, int m_pairs, int L, float stdDev);
TensorScale *CreateBinaryTensorScale(Image *img, int m_pairs, int L, int label);
void DestroyTensorScale(TensorScale **ts);
CImage *ConvertTS2CImage(TensorScale *ts);
void OutputTSColorSpace(char *filename, int size);

int *TSOrientationHistogram(TensorScale *ts);
CImage *TSShowHistograms(int *hist1, int *hist2, int offset);
float TSHistogramMatch(int *hist1, int *hist2, int *offset);

void TS_DrawLineDDA(CImage *cimg, int x1, int y1, int xn, int yn, int RR, int GG, int BB);  
int TS_NearValue(float teta, float values[], int size);
#endif
