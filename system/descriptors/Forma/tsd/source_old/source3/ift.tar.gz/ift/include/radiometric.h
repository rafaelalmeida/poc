#ifndef _RADIOMETRIC_H_
#define _RADIOMETRIC_H_

#include "image.h"
#include "curve.h"

Curve *Histogram(Image *img);
Curve *NormHistogram(Image *img);
Curve *AccHistogram(Image *img);
Curve *NormAccHistogram(Image *img);

Image *Probability(Image *img);
Image *Equalize(Image *img);
Image *MatchHistogram(Image *img, Image *des);
Image *LinearStretch(Image *img, int f1, int f2, int g1, int g2);
Image *GaussStretch(Image *img, float mean, float stdev);

#endif
