#include "radiometric.h"

Curve *Histogram(Image *img)
{
  int i,p,n,nbins;
  Curve *hist=NULL;

  nbins = MaximumValue(img)+1;
  hist  = CreateCurve(nbins);
  n     = img->ncols*img->nrows;
  for (p=0; p < n; p++)
    hist->Y[img->val[p]]++;
  for (i=0; i < nbins; i++) 
    hist->X[i] = i;

  return(hist);
}

Curve *NormHistogram(Image *img) 
{
  int i,sum;
  Curve *hist=NULL,*nhist=NULL;

  hist  = Histogram(img);
  sum   = img->ncols*img->nrows;
  nhist = CreateCurve(hist->n);
  for (i=0; i < nhist->n;i++){
    nhist->Y[i] = hist->Y[i]/sum;
    nhist->X[i] = hist->X[i];
  }

  DestroyCurve(&hist);

  return(nhist);
}

Image *Probability(Image *img) 
{
  int p,n;
  Image *prob;
  Curve *nhist;

  n     = img->ncols*img->nrows;
  prob  = CreateImage(img->ncols,img->nrows);
  nhist = NormHistogram(img);
  for (p=0; p < n; p++)
      prob->val[p] = (int)(100*nhist->Y[img->val[p]]);

  DestroyCurve(&nhist);
  return(prob);
}

Curve *AccHistogram(Image *img)
{
  int i;
  Curve *hist=NULL,*ahist=NULL;

  hist = Histogram(img);
  ahist = CreateCurve(hist->n);
  ahist->X[0] = 0;
  ahist->Y[0] = hist->Y[0];
  for (i=1; i < ahist->n; i++){
    ahist->X[i] = i;
    ahist->Y[i] = ahist->Y[i-1] + hist->Y[i];
  }

  DestroyCurve(&hist);

  return(ahist);
}

Curve *NormAccHistogram(Image *img)
{
  int i,sum;
  Curve *ahist=NULL,*nahist=NULL;

  ahist  = AccHistogram(img);
  sum    = img->ncols*img->nrows;
  nahist = CreateCurve(ahist->n);
  for (i=0; i < nahist->n;i++){
    nahist->Y[i] = ahist->Y[i]/sum;
    nahist->X[i] = ahist->X[i];
  }
  DestroyCurve(&ahist);

  return(nahist);
}


Image *Equalize(Image *img)
{
  int p,n,Imax;
  Image *eimg=NULL;
  Curve *nhist;

  nhist = NormAccHistogram(img);
  eimg  = CreateImage(img->ncols,img->nrows);
  n     = img->ncols*img->nrows;
  Imax  = MaximumValue(img);

  if (Imax < 255) /* 8 bits */
    Imax = 255;
  else
    if (Imax < 4095) /* 12 bits */
      Imax = 4095;

  for (p=0; p < n; p++)
    eimg->val[p] = (int)(Imax*nhist->Y[img->val[p]]);

  DestroyCurve(&nhist);

  return(eimg);
}

Image *MatchHistogram(Image *img, Image *des)
{
  int   start,end,pos=0,p,n;
  Image *mimg=NULL;
  Curve *nhist1=NULL,*nhist2=NULL;
  double val;
  bool found;

  nhist1 = NormAccHistogram(img);
  nhist2 = NormAccHistogram(des);
  n      = img->nrows*img->ncols;
  mimg   = CreateImage(img->ncols,img->nrows);

  for (p=0; p < n; p++) {
    val   = nhist1->Y[img->val[p]];
    start = 0;
    end   = nhist2->n-1;
    found = false;
    while ((start <= end)&&(!found)){
      pos = (start+end)/2;
      if (val < nhist2->Y[pos])
	end = pos-1;
      else
	if (val > nhist2->Y[pos])
	  start = pos+1;
	else
	  found = true;
    }
    if (found)
      mimg->val[p]=pos;
    else
      if (fabs(val-nhist2->Y[start])<fabs(val-nhist2->Y[end]))
	mimg->val[p]=start;
      else
	mimg->val[p]=end;
  }

  DestroyCurve(&nhist1);
  DestroyCurve(&nhist2);

  return(mimg);
}

Image *LinearStretch(Image *img, int f1, int f2, int g1, int g2)
{
  Image *simg=NULL;
  int p,n;
  float a;

  simg = CreateImage(img->ncols,img->nrows);
  n    = img->ncols*img->nrows;
  if (f1 != f2) 
    a = (float)(g2-g1)/(float)(f2-f1);
  else
    a = INT_MAX;

  for (p=0; p < n; p++){
    if (img->val[p] < f1)
      simg->val[p] = g1;
    else 
      if (img->val[p] > f2)
	simg->val[p] = g2;
      else {
	if (a != INT_MAX)	  
	  simg->val[p] = (int)(a*(img->val[p]-f1)+g1);
	else{
	  simg->val[p] = g2;
	}   
      }
  }
  return(simg);
}

Image *GaussStretch(Image *img, float mean, float stdev)
{
  float *gauss=NULL,sq,var2;
  int i,Imax,n;
  Image *gimg=NULL;

  Imax  = MaximumValue(img);
  gauss = AllocFloatArray(Imax+1);
  var2  = 2*stdev*stdev;
  for (i=0; i < Imax+1; i++){
    sq  = ((float)i-mean)*((float)i-mean);
    gauss[i]=(float)(Imax*exp(-sq/var2));
  }
  n     = img->ncols*img->nrows;
  gimg     = CreateImage(img->ncols,img->nrows);
  for (i=0; i < n; i++){
    gimg->val[i] = (int)(gauss[img->val[i]]);
  }
  free(gauss);
  return(gimg);  
}








