#ifndef _FILTERING_H_
#define _FILTERING_H_

#include "adjacency.h"
#include "image.h"
#include "geometry.h"

typedef struct _kernel {
  float *val;
  AdjRel *adj;
  int xsize,ysize;
} Kernel;

Kernel *MakeKernel(char *coefs);
Kernel *CreateKernel(AdjRel *A);
Kernel *LinearKernel(AdjRel *A);
Kernel *GaussianKernel(AdjRel *A, float mean, float stddev);
Kernel *LaplacianKernel(AdjRel *A, float stddev);
Kernel *CircularGaussianKernel(float R, float s, float f);
Kernel *EllipticalGaussianKernel(Vector *v, float E, float R, float s, float f);

void    DestroyKernel(Kernel **K);
Image  *LinearFilter(Image *img, Kernel *K);
Image  *LinearFilter2(Image *img, Kernel *K);
Image  *LaplacianBorder (Image *img, Kernel *K);
Image  *MedianFilter(Image *img, AdjRel *A);
Image  *ModeFilter(Image *img, AdjRel *A);
Kernel *FoldKernel(Kernel *K);
Image  *SobelFilter(Image *img);


/* ----------- IFT-based Operators ------------------- */

Image  *ShapeFilter(Image *bin, float perc);

#endif
