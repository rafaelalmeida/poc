#include "tensorscale.h" 


TensorScale *CreateTensorScale(Image *img, Image *mask, int m_pairs, int L, float stdDev){
  Point *epsilon;
  TensorScale *ts;
  Vector *tau;
  int i,j,k,p,v;
  float val_p,val1,val2,val,threshold,threshold2,difacc1,dif;
  float x,y, taux, tauy;
  float a2,b2,teta,l1E,l2E,uu,vv,aux;
  float gSxy, gSy2_x2;
  float Su2v2,Su4,Sv4,Su2,Sv2;
  float sin_teta, cos_teta;
  int L2;
  int x1,x2,y1,y2,a,b,c,d,pp,qq;
  float dx1,dx2,dy1,dy2;
  int ncols,nrows,destroymask;


  L2 = L*L;
  ncols = img->ncols;
  nrows = img->nrows;
  if(mask==NULL){
    mask = CreateImage(ncols,nrows);
    SetImage(mask, 1);
    destroymask = 1;
  }
  else destroymask = 0;
  ts = (TensorScale *)malloc(sizeof(TensorScale));
  ts->orientation = CreateImage(ncols,nrows);
  ts->anisotropy = CreateImage(ncols,nrows);
  ts->thickness = CreateImage(ncols,nrows);
  ts->m_pairs = m_pairs;
  ts->L = L;

  tau = (Vector *)malloc(sizeof(Vector)*m_pairs);
  epsilon = (Point *)malloc(sizeof(Point)*m_pairs);

  teta = 0.0;
  for(i=0;i<m_pairs;i++){
    tau[i].x = cos(teta);
    tau[i].y = sin(teta);
    tau[i].z = 0.0;

    teta += ((float)PI/m_pairs); 
  }

  threshold = 3.0*stdDev;
  threshold2 = 2*threshold;
  for(i=1;i<nrows-1;i++){

    for(j=1;j<ncols-1;j++){
      p=img->tbrow[i]+j;
      val_p = 2*img->val[p];
      val_p += img->val[p-ncols];
      val_p += img->val[p+ncols];
      val_p += img->val[p-1];
      val_p += img->val[p+1];
      val_p /= 6.0;

      if(mask->val[p] == 0){
	continue;
      }
      
      //--------- Sample lines --------------------------------------
      gSxy = gSy2_x2 = 0.0;
      for(k=0;k<m_pairs;k++){
	x = taux = tau[k].x;
	y = tauy = tau[k].y;
	v=1;
	difacc1 =  0.0;
	val1 = val2 = val_p;
	for(;v<L;v++){
	  x1 = (int)(x+j);
	  y1 = (int)(y+i);
	  if(x1>=ncols-1 || y1>=nrows-1 || x1<=0 || y1<=0)
	    break;
	  x2 = x1+1;
	  y2 = y1+1;

	  pp = img->tbrow[y1];
	  qq = img->tbrow[y2];

	  a = img->val[pp+x1];
	  b = img->val[pp+x2];
	  c = img->val[qq+x1];
	  d = img->val[qq+x2];
	  
	  dx1 = x+j-x1; dx2 = x2-x-j;
	  dy1 = y+i-y1; dy2 = y2-y-i;

	  val = val1;
	  val1 = ((float)d*dx1+(float)c*dx2)*dy1+((float)b*dx1+(float)a*dx2)*dy2;
	  val = (val+val1)/2.0;
	  dif = ((val>val_p)?(val-val_p):(val_p-val));
	  difacc1 += dif;
	  if( dif > threshold )
	    break;

	  x1 = (int)(-x+j);
	  y1 = (int)(-y+i);
	  if(x1>=ncols-1 || y1>=nrows-1 || x1<=0 || y1<=0)
	    break;
	  x2 = x1+1;
	  y2 = y1+1;
	  
	  pp = img->tbrow[y1];
	  qq = img->tbrow[y2];

	  a = img->val[pp+x1];
	  b = img->val[pp+x2];
	  c = img->val[qq+x1];
	  d = img->val[qq+x2];
	  
	  val = val2;
	  val2 = ((float)d*dx2+(float)c*dx1)*dy2+((float)b*dx2+(float)a*dx1)*dy1;
	  val = (val+val2)/2.0;
	  dif = ((val>val_p)?(val-val_p):(val_p-val));
	  difacc1 += dif;	  
	  if( dif > threshold )
	    break;
	  if( difacc1 > threshold2 ){
	    v -=1;
	    x -= taux;
	    y -= tauy;
	    break;
	  }

	  x += taux; 
	  y += tauy; 
	}
	epsilon[k].x = x;
	epsilon[k].y = -y;

	gSxy += x*(-y);
	gSy2_x2 += (y+x)*(y-x); //(y*y-x*x);
      }

      //-------------------- TETA -----------------------------------

      if(gSy2_x2==0.0){ 
	if(gSxy>0.0) teta=PI/2.0;
	else teta=-PI/2.0;
      }
      else{
	teta = atanf((gSxy+gSxy)/gSy2_x2);
	
	if(gSxy<0.0 && teta<0.0) teta+=PI;
	else if(gSxy>0.0 && teta>0.0) teta-=PI;
	else if(teta==0.0 && gSy2_x2>0.0) teta=PI;
      }
      teta /= 2.0;

      //----------------- A & B ---------------------------------
      sin_teta = sin(teta);
      cos_teta = cos(teta);
      Su2v2 = Su2 = Sv2 = Su4 = Sv4 = 0.0;
      for(k=0;k<m_pairs;k++){
	uu = epsilon[k].x;
	vv = epsilon[k].y;
	aux = uu*cos_teta-vv*sin_teta;
	vv = vv*cos_teta+uu*sin_teta;
	uu = aux*aux;
	vv *= vv;
	Su2v2 += uu*vv;
	Su2 += uu;
	Sv2 += vv;
	Su4 += uu*uu;
	Sv4 += vv*vv;
      }

      aux = Su2v2*Su2v2-Su4*Sv4;
      a2 = (aux/(Su2v2*Sv2-Su2*Sv4));
      b2 = (aux/(Su2*Su2v2-Su4*Sv2));

      if(isnan(a2) || a2<0.0) a2=1.0;
      if(isnan(b2) || b2<0.0) b2=1.0;
      if(a2>L2) a2=L2;
      if(b2>L2) b2=L2;

      if(a2>=b2){
	l1E=a2; 
	l2E=b2;
      }
      else{
	l1E=b2;
	l2E=a2;
      }

      ts->anisotropy->val[p]=ROUND((INT_MAX)*(1.0-sqrt(l2E/l1E)));
      ts->thickness->val[p]=ROUND((INT_MAX)*sqrt(sqrt(l2E)/L));

      if(teta<0) teta+=(float)PI;
      if(teta>PI) teta-=((int)(teta/PI))*PI;
      teta = PI-teta;

      ts->orientation->val[p]=ROUND(teta*((INT_MAX)/PI));
    }
  }

  free(tau);
  free(epsilon);

  if(destroymask) DestroyImage(&mask);

  return ts;
}


TensorScale *CreateBinaryTensorScale(Image *img, int m_pairs, int L, int label){
  Point *epsilon;
  TensorScale *ts;
  Vector *tau;
  int i,j,k,p,v;
  float val_p;
  float x,y, taux, tauy;
  float a2,b2,teta,l1E,l2E,uu,vv,aux;
  float gSxy, gSy2_x2;
  float Su2v2,Su4,Sv4,Su2,Sv2;
  float sin_teta, cos_teta;
  int L2;
  int x1,y1,a,pp;
  int ncols,nrows;

  L2 = L*L;
  ncols = img->ncols;
  nrows = img->nrows;

  ts = (TensorScale *)malloc(sizeof(TensorScale));
  ts->orientation = CreateImage(ncols,nrows);
  ts->anisotropy = CreateImage(ncols,nrows);
  ts->thickness = CreateImage(ncols,nrows);
  ts->m_pairs = m_pairs;
  ts->L = L;

  tau = (Vector *)malloc(sizeof(Vector)*m_pairs);
  epsilon = (Point *)malloc(sizeof(Point)*m_pairs);

  teta = 0.0;
  for(i=0;i<m_pairs;i++){
    tau[i].x = cos(teta);
    tau[i].y = sin(teta);
    tau[i].z = 0.0;

    teta += ((float)PI/m_pairs); 
  }

  for(i=1;i<nrows-1;i++){

    for(j=1;j<ncols-1;j++){
      p=img->tbrow[i]+j;
      val_p = img->val[p];

      if(val_p != label){
	continue;
      }

      //--------- Sample lines --------------------------------------
      gSxy = gSy2_x2 = 0.0;
      for(k=0;k<m_pairs;k++){
	x = taux = tau[k].x;
	y = tauy = tau[k].y;
	v=1;

	for(;v<L;v++){

	  x1 = ROUND(x+j);
	  y1 = ROUND(y+i);
	  if(x1>ncols-1 || y1>nrows-1 || x1<0 || y1<0)
	    break;
	  
	  pp = x1+img->tbrow[y1];
	  a = img->val[pp];
	  if(a != label){ 
	    //x -= taux;
	    //y -= tauy;
	    break;
	  }
	  
	  x1 = ROUND(-x+j);
	  y1 = ROUND(-y+i);
	  if(x1>ncols-1 || y1>nrows-1 || x1<0 || y1<0)
	    break;

	  pp = x1+img->tbrow[y1];
	  a = img->val[pp];
	  if(a != label){ 
	    //x -= taux;
	    //y -= tauy;
	    break;
	  }
	  
	  x += taux;
	  y += tauy;
	}
	epsilon[k].x = x;
	epsilon[k].y = -y;

	gSxy += x*(-y);
	gSy2_x2 += (y+x)*(y-x); //(y*y-x*x);
      }

      //-------------------- TETA -----------------------------------

      if(gSy2_x2==0.0){ 
	if(gSxy>0.0) teta=PI/2.0;
	else teta=-PI/2.0;
      }
      else{
	teta = atanf((gSxy+gSxy)/gSy2_x2);
	
	if(gSxy<0.0 && teta<0.0) teta+=PI;
	else if(gSxy>0.0 && teta>0.0) teta-=PI;
	else if(teta==0.0 && gSy2_x2>0.0) teta=PI;
      }
      teta /= 2.0;

      //----------------- A & B ---------------------------------
      sin_teta = sin(teta);
      cos_teta = cos(teta);
      Su2v2 = Su2 = Sv2 = Su4 = Sv4 = 0.0;
      for(k=0;k<m_pairs;k++){
	uu = epsilon[k].x;
	vv = epsilon[k].y;
	aux = uu*cos_teta-vv*sin_teta;
	vv = vv*cos_teta+uu*sin_teta;
	uu = aux*aux;
	vv *= vv;
	Su2v2 += uu*vv;
	Su2 += uu;
	Sv2 += vv;
	Su4 += uu*uu;
	Sv4 += vv*vv;
      }

      aux = Su2v2*Su2v2-Su4*Sv4;
      a2 = (aux/(Su2v2*Sv2-Su2*Sv4));
      b2 = (aux/(Su2*Su2v2-Su4*Sv2));

      if(isnan(a2) || a2<0.0) a2=1.0;
      if(isnan(b2) || b2<0.0) b2=1.0;
      if(a2>L2) a2=L2;
      if(b2>L2) b2=L2;

      if(a2>=b2){
	l1E=a2; 
	l2E=b2;
      }
      else{
	l1E=b2;
	l2E=a2;
      }

      ts->anisotropy->val[p]=ROUND((INT_MAX)*(1.0-sqrt(l2E/l1E)));
      ts->thickness->val[p]=ROUND((INT_MAX)*sqrt(sqrt(l2E)/L));

      if(teta<0) teta+=(float)PI;
      if(teta>PI) teta-=((int)(teta/PI))*PI;
      teta = PI-teta;

      ts->orientation->val[p]=ROUND(teta*((INT_MAX)/PI));
    }
  }

  free(tau);
  free(epsilon);

  return ts;
}


TensorScale *CreateFastBinaryTensorScale(Image *bin, int m_pairs, int L){
  Image *Dist;
  AdjRel *A;
  Point *epsilon;
  TensorScale *ts;
  Vector *tau;
  int i,j,k,p,v,vi;
  float val_p;
  float x,y, taux, tauy;
  float a2,b2,teta,l1E,l2E,uu,vv,aux;
  float gSxy, gSy2_x2;
  float Su2v2,Su4,Sv4,Su2,Sv2;
  float sin_teta, cos_teta;
  float *lt_sqrt;
  int L2;
  int x1,y1,a,pp,d;
  int ncols,nrows;

  L2 = L*L;
  ncols = bin->ncols;
  nrows = bin->nrows;

  A = Circular(1.5);
  Dist = DistTrans(bin, A, INTERIOR);
  //WriteImage(Dist,"dist.pgm");

  lt_sqrt = (float *)malloc((L2+1)*sizeof(float));
  for(i=0;i<=L2;i++){
    lt_sqrt[i] = sqrt(i);
  }

  ts = (TensorScale *)malloc(sizeof(TensorScale));
  ts->orientation = CreateImage(ncols,nrows);
  ts->anisotropy = CreateImage(ncols,nrows);
  ts->thickness = CreateImage(ncols,nrows);
  ts->m_pairs = m_pairs;
  ts->L = L;

  tau = (Vector *)malloc(sizeof(Vector)*m_pairs);
  epsilon = (Point *)malloc(sizeof(Point)*m_pairs);

  teta = 0.0;
  for(i=0;i<m_pairs;i++){
    tau[i].x = cos(teta);
    tau[i].y = sin(teta);
    tau[i].z = 0.0;

    teta += ((float)PI/m_pairs); 
  }

  for(i=1;i<nrows-1;i++){

    for(j=1;j<ncols-1;j++){
      p = bin->tbrow[i]+j;
      val_p = bin->val[p];

      if(val_p == 0){
	continue;
      }

      d = Dist->val[p];
      if(d>L2) d = L2;
      vi = (int)lt_sqrt[d];

      //--------- Sample lines --------------------------------------
      gSxy = gSy2_x2 = 0.0;
      for(k=0;k<m_pairs;k++){
	taux = tau[k].x;
	tauy = tau[k].y;
	x = taux*vi;
	y = tauy*vi;
	v = vi;

	for(;v<L;v++){

	  x1 = ROUND(x+j);
	  y1 = ROUND(y+i);
	  if(x1>ncols-1 || y1>nrows-1 || x1<0 || y1<0)
	    break;
	  
	  pp = x1+bin->tbrow[y1];
	  a = bin->val[pp];
	  if(a == 0){ 
	    //x -= taux;
	    //y -= tauy;
	    break;
	  }
	  
	  x1 = ROUND(-x+j);
	  y1 = ROUND(-y+i);
	  if(x1>ncols-1 || y1>nrows-1 || x1<0 || y1<0)
	    break;

	  pp = x1+bin->tbrow[y1];
	  a = bin->val[pp];
	  if(a == 0){ 
	    //x -= taux;
	    //y -= tauy;
	    break;
	  }
	  
	  x += taux;
	  y += tauy;
	}
	epsilon[k].x = x;
	epsilon[k].y = -y;

	gSxy += x*(-y);
	gSy2_x2 += (y+x)*(y-x); //(y*y-x*x);
      }

      //-------------------- TETA -----------------------------------

      if(gSy2_x2==0.0){ 
	if(gSxy>0.0) teta=PI/2.0;
	else teta=-PI/2.0;
      }
      else{
	teta = atanf((gSxy+gSxy)/gSy2_x2);
	
	if(gSxy<0.0 && teta<0.0) teta+=PI;
	else if(gSxy>0.0 && teta>0.0) teta-=PI;
	else if(teta==0.0 && gSy2_x2>0.0) teta=PI;
      }
      teta /= 2.0;

      //----------------- A & B ---------------------------------
      sin_teta = sin(teta);
      cos_teta = cos(teta);
      Su2v2 = Su2 = Sv2 = Su4 = Sv4 = 0.0;
      for(k=0;k<m_pairs;k++){
	uu = epsilon[k].x;
	vv = epsilon[k].y;
	aux = uu*cos_teta-vv*sin_teta;
	vv = vv*cos_teta+uu*sin_teta;
	uu = aux*aux;
	vv *= vv;
	Su2v2 += uu*vv;
	Su2 += uu;
	Sv2 += vv;
	Su4 += uu*uu;
	Sv4 += vv*vv;
      }

      aux = Su2v2*Su2v2-Su4*Sv4;
      a2 = (aux/(Su2v2*Sv2-Su2*Sv4));
      b2 = (aux/(Su2*Su2v2-Su4*Sv2));

      if(isnan(a2) || a2<0.0) a2=1.0;
      if(isnan(b2) || b2<0.0) b2=1.0;
      if(a2>L2) a2=L2;
      if(b2>L2) b2=L2;

      if(a2>=b2){
	l1E=a2; 
	l2E=b2;
      }
      else{
	l1E=b2;
	l2E=a2;
      }

      ts->anisotropy->val[p]=ROUND((INT_MAX)*(1.0-sqrt(l2E/l1E)));
      ts->thickness->val[p]=ROUND((INT_MAX)*sqrt(sqrt(l2E)/L));

      if(teta<0) teta+=(float)PI;
      if(teta>PI) teta-=((int)(teta/PI))*PI;
      teta = PI-teta;

      ts->orientation->val[p]=ROUND(teta*((INT_MAX)/PI));
    }
  }

  free(tau);
  free(epsilon);
  free(lt_sqrt);
  DestroyImage(&Dist);
  DestroyAdjRel(&A);

  return ts;
}


void DestroyTensorScale(TensorScale **ts){
  if(*ts != NULL){
    DestroyImage(&((*ts)->orientation));
    DestroyImage(&((*ts)->anisotropy));
    DestroyImage(&((*ts)->thickness));
    free(*ts);
  }
  *ts = NULL;
}

CImage *ConvertTS2CImage(TensorScale *ts){
  CImage *cimg;
  int i,j,w,h,p;
  int RR,GG,BB,tRGB;
  int HH,SS,VV;
  float ratio;

  ratio = 255.0/INT_MAX;
  w = ts->anisotropy->ncols;
  h = ts->anisotropy->nrows;
  cimg = CreateCImage(w,h);
  for(i=0; i<h; i++){
    for(j=0; j<w; j++){
      p=ts->anisotropy->tbrow[i]+j;
      SS=ROUND(ts->anisotropy->val[p]*ratio);
      VV=ROUND(ts->thickness->val[p]*ratio);
      HH=ROUND(ts->orientation->val[p]*ratio);

      tRGB = HSV2RGB(triplet(HH,SS,VV));
      RR = t0(tRGB);
      GG = t1(tRGB);
      BB = t2(tRGB);
      
      cimg->C[0]->val[p]=RR;
      cimg->C[1]->val[p]=GG;
      cimg->C[2]->val[p]=BB;      
    }
  }

  return cimg;
}


void OutputTSColorSpace(char *filename, int size){
  CImage *cimg_colorspace;
  int i,j,x,y,p;
  float val,teta;
  int HH,SS,VV,tRGB,RR,GG,BB;

  cimg_colorspace = CreateCImage(size,size);
  VV=255;
  for(i=0;i<size;i++){
    for(j=0;j<size;j++){
      y = -(i-size/2);
      x = j-size/2;
      val = sqrt(pow(x,2)+pow(y,2));
      if(x==0 && y>0) teta=PI/2;
      else if(x==0 && y<=0) teta=-PI/2;
      else teta = atan((float)y/(float)x); 
      if(x<0) teta+=PI;
      if(teta<0) teta+=2*PI;
      if(val<size/2-5){
	HH = (ROUND(teta*256.0/PI)%256);
	SS = ROUND(val*(255.0/(size/2-5)));
	tRGB = HSV2RGB(triplet(HH,SS,VV));
	RR = t0(tRGB);
	GG = t1(tRGB);
	BB = t2(tRGB);
	p = j+cimg_colorspace->C[0]->tbrow[i];
	cimg_colorspace->C[0]->val[p]=RR;
	cimg_colorspace->C[1]->val[p]=GG;
	cimg_colorspace->C[2]->val[p]=BB;
      }
    }
  }

  WriteCImage(cimg_colorspace,filename);
  DestroyCImage(&cimg_colorspace);
}


int *TSOrientationHistogram(TensorScale *ts){
  int *hist, bin;
  float ratio;
  int w,h,i,j,p,an,th;
  Image *img;
  
  ratio = (float)HISTOGRAMSIZE/INT_MAX;
  hist = (int *)malloc(sizeof(int)*(HISTOGRAMSIZE+1));
  memset(hist, 0, sizeof(int)*(HISTOGRAMSIZE+1));
  w = ts->anisotropy->ncols;
  h = ts->anisotropy->nrows;
  img = CreateImage(w,h);
  SetImage(img, 0);
  for(i=0; i<h; i++){
    for(j=0; j<w; j++){
      p=ts->anisotropy->tbrow[i]+j;
      an = ts->anisotropy->val[p];
      th = ts->thickness->val[p];
      if(th<INT_MAX*0.75 && an>INT_MAX*0.40 && th>INT_MAX*0.40){
	bin=ROUND(ts->orientation->val[p]*ratio);  
	hist[bin]++;
	img->val[p] = 255;
      }
    }
  }
  hist[0] += hist[HISTOGRAMSIZE];
  hist[HISTOGRAMSIZE] = 0;

  WriteImage(img,"samplepoints.pgm");
  DestroyImage(&img);
  
  return hist;
}


CImage *TSShowHistograms(int *hist1, int *hist2, int offset){
  float *newhist;
  float *newh1,*newh2;
  CImage *cimg;
  int n1,n2,i;
  float max1,max2,max;
  int col,row,col2,row2;
  int xsize=HISTOGRAMSIZE*2, ysize=100*2;
  
  newhist = (float *)malloc(sizeof(float)*2*HISTOGRAMSIZE);
  newh1=newhist;
  newh2=newhist+HISTOGRAMSIZE;

  //Ajuste no histograma
  n1=n2=0;
  for(i=0;i<HISTOGRAMSIZE;i++){
    n1+=hist1[i];
    n2+=hist2[i];
  }

  newh1[0]=(float)(hist1[0]+hist1[HISTOGRAMSIZE-1]+hist1[1])/(3.0*n1);
  newh2[0]=(float)(hist2[0]+hist2[HISTOGRAMSIZE-1]+hist2[1])/(3.0*n2);
  for(i=1;i<HISTOGRAMSIZE-1;i++){
    newh1[i]=(float)(hist1[i]+hist1[i-1]+hist1[i+1])/(3.0*n1);
    newh2[i]=(float)(hist2[i]+hist2[i-1]+hist2[i+1])/(3.0*n2);
  }
  newh1[HISTOGRAMSIZE-1]=(float)(hist1[HISTOGRAMSIZE-1]+hist1[HISTOGRAMSIZE-2]+hist1[0])/(3.0*n1);
  newh2[HISTOGRAMSIZE-1]=(float)(hist2[HISTOGRAMSIZE-1]+hist2[HISTOGRAMSIZE-2]+hist2[0])/(3.0*n2);

  cimg = CreateCImage(10*2+xsize,10*2+ysize);
  SetImage(cimg->C[0], 255);
  SetImage(cimg->C[1], 255);
  SetImage(cimg->C[2], 255);
  TS_DrawLineDDA(cimg, 10, ysize+10, 10+xsize, ysize+10, 0, 0, 0);

  max1=max2=0.0;
  for(i=0;i<HISTOGRAMSIZE;i++){
    if(newh1[i]>max1) max1=newh1[i];
    if(newh2[i]>max2) max2=newh2[i];
  }

  if(max1==0 || max2==0) exit(1);
  max = (max1>max2)?max1:max2;

  for(i=0;i<HISTOGRAMSIZE-1;i++){
    row = 10+ysize*(max-newh1[(i+offset)%HISTOGRAMSIZE])/max;
    col = xsize*(i/((float)HISTOGRAMSIZE-1.0))+10;
    row2 = 10+ysize*(max-newh1[(i+1+offset)%HISTOGRAMSIZE])/max;
    col2 = xsize*((i+1)/((float)HISTOGRAMSIZE-1.0))+10;
    TS_DrawLineDDA(cimg, col, row, col2, row2, 255, 0, 0);

    row = 10+ysize*(max-newh2[i])/max;
    col = xsize*(i/((float)HISTOGRAMSIZE-1.0))+10;
    row2 = 10+ysize*(max-newh2[i+1])/max;
    col2 = xsize*((i+1)/((float)HISTOGRAMSIZE-1.0))+10;
    TS_DrawLineDDA(cimg, col, row, col2, row2, 0, 0, 255);
  }
  free(newhist);

  return cimg;
}

float TSHistogramMatch(int *hist1, int *hist2, int *offset){
  float *newhist;
  float *newh1,*newh2;
  int n1,n2,i,j,p;
  float max,correlacao;
  float score;
  float dabs,dist_eucl,aux;
  //int maxoffset;
  FILE *file1,*file2,*file3;

  newhist = (float *)malloc(sizeof(float)*2*HISTOGRAMSIZE);
  newh1=newhist;
  newh2=newhist+HISTOGRAMSIZE;

  //Ajuste no histograma
  n1=n2=0;
  for(i=0;i<HISTOGRAMSIZE;i++){
    n1+=hist1[i];
    n2+=hist2[i];
  }

  newh1[0]=(float)(hist1[0]+hist1[HISTOGRAMSIZE-1]+hist1[1])/(3.0*n1);
  newh2[0]=(float)(hist2[0]+hist2[HISTOGRAMSIZE-1]+hist2[1])/(3.0*n2);
  for(i=1;i<HISTOGRAMSIZE-1;i++){
    newh1[i]=(float)(hist1[i]+hist1[i-1]+hist1[i+1])/(3.0*n1);
    newh2[i]=(float)(hist2[i]+hist2[i-1]+hist2[i+1])/(3.0*n2);
  }
  newh1[HISTOGRAMSIZE-1]=(float)(hist1[HISTOGRAMSIZE-1]+hist1[HISTOGRAMSIZE-2]+hist1[0])/(3.0*n1);
  newh2[HISTOGRAMSIZE-1]=(float)(hist2[HISTOGRAMSIZE-1]+hist2[HISTOGRAMSIZE-2]+hist2[0])/(3.0*n2);

  //Correlacao
  //maxoffset = ROUND((24.0*HISTOGRAMSIZE)/180.0); // 24 graus.
  *offset=0;
  max=0.0;
  for(i=0;i<HISTOGRAMSIZE;i++){
    correlacao=0.0;
    //if(i==maxoffset) i=HISTOGRAMSIZE-maxoffset; //angulo entre -24 e 24.
    for(p=i,j=0;j<HISTOGRAMSIZE;j++,p++){
      if(p==HISTOGRAMSIZE) p=0;
      correlacao+=(newh1[p]*newh2[j]);
    }

    if(correlacao>max){
      max=correlacao;
      *offset=i;
    }
  }

  file1 = fopen("match_histogram1.txt","w");
  file2 = fopen("histogram2.txt","w");
  file3 = fopen("histogram1.txt","w");
  dabs = 0.0;
  dist_eucl = 0.0;
  for(p=*offset,j=0;j<HISTOGRAMSIZE;j++,p++){
    if(p==HISTOGRAMSIZE) p=0;

    fprintf(file1,"%d %f\n",j,newh1[p]);
    fprintf(file2,"%d %f\n",j,newh2[j]);
    fprintf(file3,"%d %f\n",j,newh1[j]);

    dist_eucl+=pow(newh1[p]-newh2[j],2.0);
    aux=(newh1[p]-newh2[j]);
    aux=(aux<0.0)?(-aux):(aux);
    dabs+=aux;
  }
  
  dist_eucl = sqrt(dist_eucl);
  score = 1.0 - dabs;

  free(newhist);
  fclose(file1);
  fclose(file2);
  fclose(file3);

  return score;
}

void    TS_DrawLineDDA(CImage *cimg, int x1, int y1, int xn, int yn, int RR, int GG, int BB){  
  int vx, vy;
  float Dx, Dy;
  int amostras; /* número de pontos a serem pintados */
  float m; /* coeficiente angular da reta */
  int i;   /* usada no controle do loop */
  float xk, yk;
  int p;

  vx = xn - x1; /* componente x do vetor não unitario */
  vy = yn - y1; /* componente y do vetor não unitario */
  
   if(vx == 0){  
     Dx = 0.0;
     Dy = (float) SIGN(vy);
     amostras = abs(vy)+1;
   }
   else{  
     m = ((float)vy )/((float)vx);
     if( abs(vx) > abs(vy)){
       Dx = (float) SIGN(vx);
       Dy = m * Dx;
       amostras = abs(vx)+1; 
     }
     else{  
       Dy = (float) SIGN(vy);
       Dx = Dy / m;
       amostras = abs(vy)+1;
     }
   }
   
   xk = (float) x1;
   yk = (float) y1;
   for(i = 0; i < amostras; i++){ 
     p = ROUND(xk)+cimg->C[0]->tbrow[ROUND(yk)];
     cimg->C[0]->val[p]=RR;
     cimg->C[1]->val[p]=GG;
     cimg->C[2]->val[p]=BB;
     xk += Dx;
     yk += Dy;
   }
}
