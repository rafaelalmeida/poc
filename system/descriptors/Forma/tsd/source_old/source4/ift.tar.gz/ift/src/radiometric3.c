#include "radiometric3.h"

Curve *Histogram3(Scene *scn)
{
  int i, n, nbins;
  Curve *hist = NULL;

  nbins = MaximumValue3(scn)+1;
  hist  = CreateCurve(nbins);
  n = scn->xsize * scn->ysize * scn->zsize;
  for (i = 0; i < n; i++)
    hist->Y[scn->data[i]]++;
  for (i = 0; i < nbins; i++)
    hist->X[i] = i;

  return (hist);
}


Curve *NormHistogram3(Scene *scn)
{
  int i, sum;
  Curve *nhist;

  nhist = Histogram3(scn);
  sum = scn->xsize * scn->ysize * scn->zsize;
  for (i = 0; i < nhist->n; i++){
    nhist->Y[i] /= sum;
    nhist->X[i]=i;
  }

  return (nhist);
}

Curve *AccHistogram3(Scene *scn)
{
  int i;
  Curve *ahist;

  ahist = Histogram3(scn);
  for (i = 1; i < ahist->n; i++){
    ahist->Y[i] += ahist->Y[i-1];
    ahist->X[i] = i;
  }

  return (ahist);
}

Curve *NormAccHistogram3(Scene *scn)
{
  int i, sum;
  Curve *ahist;

  ahist = NormHistogram3(scn);
  sum = scn->xsize * scn->ysize * scn->zsize;
  for (i = 1; i < ahist->n; i++){
    ahist->Y[i] = ahist->Y[i-1] + ahist->Y[i];
    ahist->X[i] = i;
  }
  return (ahist);
}


Scene *GaussStretch3(Scene *scn, float mean, float stdev)
{
  float *gauss=NULL,sq,var2;
  int i,Imax,n;
  Scene *gscn=NULL;

  Imax  = MaximumValue3(scn);
  gauss = AllocFloatArray(Imax+1);
  var2  = 2*stdev*stdev;
  for (i=0; i < Imax+1; i++){
    sq  = ((float)i-mean)*((float)i-mean);
    gauss[i]=(float)(Imax*exp(-sq/var2));
  }
  n     = scn->xsize*scn->ysize*scn->zsize;
  gscn     = CreateScene(scn->xsize,scn->ysize,scn->zsize);
  gscn->dx = scn->dx;
  gscn->dy = scn->dy;
  gscn->dz = scn->dz;

  for (i=0; i < n; i++){
    gscn->data[i] = (int)(gauss[scn->data[i]]);
  }
  gscn->dx = scn->dx;
  gscn->dy = scn->dy;
  gscn->dz = scn->dz;

  free(gauss);
  return(gscn);  
}


Scene *LinearStretch3(Scene *scn, int f1, int f2, int g1, int g2)
{
  Scene *sscn = NULL;
  int p, n;
  float a;

  sscn = CreateScene(scn->xsize, scn->ysize, scn->zsize);
  sscn->dx = scn->dx;
  sscn->dy = scn->dy;
  sscn->dz = scn->dz;

  n = scn->xsize * scn->ysize * scn->zsize;

  if (f1 != f2)
    a = (float)(g2-g1)/(float)(f2-f1);
  else
    a = INT_MAX;

  for (p = 0; p < n; p++) {
    if (scn->data[p] < f1)
      sscn->data[p] = g1;
    else 
      if (scn->data[p] > f2)
	sscn->data[p] = g2;
      else{
	if (a != INT_MAX)
	  sscn->data[p] = (int)(a*(scn->data[p]-f1)+g1);
	else 
	  sscn->data[p] = g2;
      }
  }

  return (sscn);
}


Curve *SceneLabels (Scene *scn) {

  int i,j=0,n=0;
  Curve *c,*out;

  c = Histogram3(scn);
  for (i=1;i<c->n;i++) {
    if (c->Y[i] > 0) {
      n++;
    }
  }
  out = CreateCurve(n);
  for (i=1;i<c->n;i++) {
    if (c->Y[i] > 0) {
      out->X[j] = c->X[i];
      out->Y[j] = c->Y[i];
      j++;
    }
  }
  DestroyCurve(&c);
  return(out);

}

Scene *Equalize3(Scene *scn)
{
  int p,n,Imax;
  Scene *escn=NULL;
  Curve *nhist;

  nhist = NormAccHistogram3(scn);
  escn  = CreateScene(scn->xsize,scn->ysize,scn->zsize);
  escn->dx = scn->dx;
  escn->dy = scn->dy;
  escn->dz = scn->dz;
  n     = scn->xsize*scn->ysize*scn->zsize;
  Imax  = MaximumValue3(scn);

  if (Imax < 255) /* 8 bits */
    Imax = 255;
  else
    if (Imax < 4095) /* 12 bits */
      Imax = 4095;

  for (p=0; p < n; p++)
    escn->data[p] = (int)(Imax*nhist->Y[scn->data[p]]);

  DestroyCurve(&nhist);

  return(escn);
}

Scene *MatchHistogram3(Scene *scn, Scene *des)
{
  int   start,end,pos=0,p,n;
  Scene *mscn=NULL;
  Curve *nhist1=NULL,*nhist2=NULL;
  double val;
  bool found;

  nhist1 = NormAccHistogram3(scn);
  nhist2 = NormAccHistogram3(des);
  n      = scn->zsize*scn->ysize*scn->xsize;
  mscn   = CreateScene(scn->xsize,scn->ysize,scn->zsize);

  for (p=0; p < n; p++) {
    val   = nhist1->Y[scn->data[p]];
    start = 0;
    end   = nhist2->n-1;
    found = false;
    while ((start <= end)&&(!found)){
      pos = (start+end)/2;
      if (val < nhist2->Y[pos])
	end = pos-1;
      else
	if (val > nhist2->Y[pos])
	  start = pos+1;
	else
	  found = true;
    }
    if (found)
      mscn->data[p]=pos;
    else
      if (fabs(val-nhist2->Y[start])<fabs(val-nhist2->Y[end]))
	mscn->data[p]=start;
      else
	mscn->data[p]=end;
  }

  DestroyCurve(&nhist1);
  DestroyCurve(&nhist2);

  return(mscn);
}
