#include "adjacency.h"
#include "adjacency3.h"
#include "analysis3.h"
#include "classify.h"
#include "common.h"
#include "geometry.h"
#include "mathematics3.h"
#include "normal.h"
#include "radiometric.h"
#include "segmentation3.h"
#include "shading.h"
#include "shell.h"
#include "analysis3.h"
#include "mathematics.h"

Shell *CreateShell (Scene *scn, Scene *alpha, int w) {

  Scene *tmp,*border;
  int i,n,nvoxels;
  Shell *shell;
  AdjRel3 *A;

  n = scn->xsize*scn->ysize*scn->zsize;
  A = Spheric(1.8);
  border = Label2Border(scn,A,INTERIOR,w*w);
  tmp = NonTransparentVoxels(border,alpha);
  DestroyScene(&border);
  nvoxels=0; 

  for (i=0;i<n;i++)  
    if (tmp->data[i] != 0) 
      nvoxels++;  

  shell = NewShell(tmp->xsize,tmp->ysize,tmp->zsize,nvoxels);
  
  SetShellVoxels(shell,tmp);
  SetShellList(shell,tmp);
  shell->maxval = MaximumValue3(scn);
  shell->nobjs = MaximumValue3(tmp);
  DestroyScene(&tmp);
  SetShellLabel(shell,scn);
  SetShellOpacity(shell,alpha);
  SetDistNormal (shell);
  shell->dx  = scn->dx;
  shell->dy  = scn->dy;
  shell->dz  = scn->dz;
  DestroyAdjRel3(&A);
  return(shell);
}

Shell *CreateBodyShell (Scene *scn, Scene *alpha) {

  Scene *tmp;
  int i,n,nvoxels;
  Shell *shell;

  n = scn->xsize * scn->ysize * scn->zsize;
  tmp = NonTransparentVoxels(scn,alpha);

  nvoxels=0; 
  for (i=0;i<n;i++)  
    if (tmp->data[i] != 0) 
      nvoxels++;  

  shell = NewBodyShell(tmp->xsize,tmp->ysize,tmp->zsize,nvoxels);
  
  SetShellVoxels(shell,tmp);
  SetShellList(shell,tmp);
  SetShellOpacity(shell,alpha);
  SetBodyShellNormal(shell,tmp,Gradient3);
  SetBodyShellValue (shell,tmp);

  shell->dx  = scn->dx;
  shell->dy  = scn->dy;
  shell->dz  = scn->dz;
  shell->maxval = MaximumValue3(scn);
  DestroyScene(&tmp);
  return(shell);
}

Scene *NonTransparentVoxels (Scene *scn, Scene *alpha) 
{
  Scene *out;
  AdjRel3 *A = NULL;
  AdjVxl *V = NULL;
  int i,j,n,aux=0,xysize=0;
  Voxel v,q;

  xysize = scn->xsize*scn->ysize;
  A=Spheric(1.0);
  V=AdjVoxels(scn,A);
  out = CreateScene(scn->xsize,scn->ysize,scn->zsize);
  n = scn->xsize*scn->ysize*scn->zsize;
  for (i=0;i<n;i++) {
    if (scn->data[i] != 0) {
      if (alpha->data[i] > 12) {
	aux = i%xysize;
	v.x = aux%scn->xsize;
	v.y = aux/scn->xsize;
	v.z = i/xysize;
	for (j=0;j<A->n;j++) {
          q.x = v.x + A->dx[j];
          q.y = v.y + A->dy[j];
          q.z = v.z + A->dz[j];
 	  if (ValidVoxel(scn, q.x, q.y, q.z)) {
	    if (alpha->data[V->dp[j]] < 242) {
              out->data[i] = scn->data[i];
              break;
	    } 
	  } else {
              out->data[i] = scn->data[i];
	  }
	}
      }
    }
  }
  DestroyAdjRel3(&A);
  DestroyAdjVxl(&V);
  return(out);
}

void    DestroyShell(Shell **shell) {

  Shell *aux = *shell;
  if(aux != NULL){
    if (aux->voxel    != NULL)  free(aux->voxel); 
    if (aux->pointer  != NULL)  free(aux->pointer);
    if (aux->normaltable  != NULL)  free(aux->normaltable);
    if (aux->body  != NULL)  free(aux->body);
    DestroyImage(&(aux->Myz));
    DestroyImage(&(aux->Mzx));
    free(aux);    
    *shell = NULL;
  }

}



Shell *ReadShell (char *filename) {

  FILE   *fp=NULL;
  Shell *shell;
  char type[10];

  shell=(Shell *)calloc(1, sizeof(Shell));

  fp = fopen(filename,"rb"); 
  if (fp == NULL) 
    Error(MSG2,"ReadShell");

  fscanf(fp,"%s\n",type);
  fscanf(fp,"%d %d %d\n",&shell->xsize,&shell->ysize,&shell->zsize);
  fscanf(fp,"%f %f %f\n",&shell->dx,&shell->dy,&shell->dz);
  fscanf(fp,"%d\n",&shell->nvoxels);
  shell->voxel = ReadVoxels (fp,shell->nvoxels);
  shell->pointer = ReadList (fp,shell->nvoxels);
  shell->Myz = ReadM(fp,shell->ysize,shell->zsize);
  shell->Mzx = ReadM(fp,shell->zsize,shell->xsize);
  shell->normaltable = CreateNormalTable();
  shell->body = NULL;
  GetShellMaximum(shell);
  fclose(fp);
  return(shell);
}

Shell *ReadBodyShell (char *filename) {

  FILE   *fp=NULL;
  Shell *shell;
  char type[10];

  shell=(Shell *)calloc(1, sizeof(Shell));

  fp = fopen(filename,"rb"); 
  if (fp == NULL) 
    Error(MSG2,"ReadBodyShell");

  fscanf(fp,"%s\n",type);
  fscanf(fp,"%d %d %d\n",&shell->xsize,&shell->ysize,&shell->zsize);
  fscanf(fp,"%f %f %f\n",&shell->dx,&shell->dy,&shell->dz);
  fscanf(fp,"%d\n",&shell->nvoxels);
  shell->voxel = ReadVoxels (fp,shell->nvoxels);
  shell->pointer = ReadList (fp,shell->nvoxels);
  shell->Myz = ReadM(fp,shell->ysize,shell->zsize);
  shell->Mzx = ReadM(fp,shell->zsize,shell->xsize);
  shell->body = ReadBody (fp,shell->nvoxels);
  shell->normaltable = CreateNormalTable();
  GetShellMaximum(shell);
  fclose(fp);
  return(shell);
}

Attrib *ReadVoxels (FILE *fp, int n) {

  int i;
  Attrib *voxel;
  uchar *data8= NULL;
  ushort *data16 =NULL;

  voxel=(Attrib *)calloc(n, sizeof(Attrib));

  data8 = AllocUCharArray(n);

  fread(data8,sizeof(uchar),n,fp);
  for (i=0; i < n; i++)
    voxel[i].obj = data8[i];
  fread(data8,sizeof(uchar),n,fp);
  for (i=0; i < n; i++)
    voxel[i].opac = data8[i];
  fread(data8,sizeof(uchar),n,fp);
  for (i=0; i < n; i++)
    voxel[i].visible = data8[i];

  free(data8);

  data16 = AllocUShortArray(n);

  fread(data16,sizeof(ushort),n,fp);
  for (i=0; i < n; i++)
    voxel[i].x = data16[i];

  fread(data16,sizeof(ushort),n,fp);
  for (i=0; i < n; i++)
    voxel[i].normal = data16[i];

  free(data16);

  return(voxel);
}

PAttrib *ReadList (FILE *fp, int n) {

  int i;
  PAttrib *list;
  ushort *data16=NULL;
  int *data32=NULL;

  list=(PAttrib *)calloc(n, sizeof(PAttrib));

  data16 = AllocUShortArray(n);

  fread(data16,sizeof(ushort),n,fp);
  for (i=0; i < n; i++)
    list[i].y = data16[i];

  free(data16);

  data32 = AllocIntArray(n);

  fread(data32,sizeof(int),n,fp);
  for (i=0; i < n; i++)
    list[i].i = data32[i];

  free(data32);

  return(list);
}

CAttrib *ReadBody (FILE *fp, int n) {

  int i;
  CAttrib *body;
  ushort *data16=NULL;
  int *data32=NULL;

  body=(CAttrib *)calloc(n, sizeof(CAttrib));

  data16 = AllocUShortArray(n);

  fread(data16,sizeof(ushort),n,fp);
  for (i=0; i < n; i++)
    body[i].normalmag = data16[i];

  free(data16);

  data32 = AllocIntArray(n);

  fread(data32,sizeof(int),n,fp);
  for (i=0; i < n; i++)
    body[i].val = data32[i];

  free(data32);

  return(body);
}

Image *ReadM(FILE *fp, int ncols, int nrows)
{
  int n;
  Image *img;

  img = CreateImage(ncols,nrows+1);
  n = ncols*(nrows+1);

  fread(img->val,sizeof(int),n,fp);

  return(img);
}

void WriteShell (Shell *shell, char *filename) {

  FILE   *fp=NULL;

  fp = fopen(filename,"wb"); 
  if (fp == NULL) 
    Error(MSG2,"WriteScene");

  fprintf(fp,"SH\n");
  fprintf(fp,"%d %d %d\n",shell->xsize,shell->ysize,shell->zsize);
  fprintf(fp,"%f %f %f\n",shell->dx,shell->dy,shell->dz);
  fprintf(fp,"%d\n",shell->nvoxels);
  WriteVoxels (fp,shell->voxel,shell->nvoxels);
  WriteList (fp,shell->pointer,shell->nvoxels);
  WriteM (fp,shell->Myz);
  WriteM (fp,shell->Mzx);
  fclose(fp);
}

void WriteBodyShell (Shell *shell, char *filename) {

  FILE   *fp=NULL;

  fp = fopen(filename,"wb"); 
  if (fp == NULL) 
    Error(MSG2,"WriteScene");

  fprintf(fp,"SH\n");
  fprintf(fp,"%d %d %d\n",shell->xsize,shell->ysize,shell->zsize);
  fprintf(fp,"%f %f %f\n",shell->dx,shell->dy,shell->dz);
  fprintf(fp,"%d\n",shell->nvoxels);
  WriteVoxels (fp,shell->voxel,shell->nvoxels);
  WriteList (fp,shell->pointer,shell->nvoxels);
  WriteM (fp,shell->Myz);
  WriteM (fp,shell->Mzx);
  WriteBody (fp,shell->body,shell->nvoxels);
  fclose(fp);
}

void WriteVoxels (FILE *fp, Attrib *voxel, int n) {

  int i;
  uchar  *data8 =NULL;
  ushort *data16=NULL;

  data8 = AllocUCharArray(n);

  for (i=0; i < n; i++)
    data8[i] = voxel[i].obj;
  fwrite(data8,sizeof(uchar),n,fp);

  for (i=0; i < n; i++)
    data8[i] = voxel[i].opac;
  fwrite(data8,sizeof(uchar),n,fp);

  for (i=0; i < n; i++)
    data8[i] = voxel[i].visible;
  fwrite(data8,sizeof(uchar),n,fp);

  free(data8);

  data16 = AllocUShortArray(n);

  for (i=0; i < n; i++)
    data16[i] = voxel[i].x;
  fwrite(data16,sizeof(ushort),n,fp);

  for (i=0; i < n; i++)
    data16[i] = voxel[i].normal;
  fwrite(data16,sizeof(ushort),n,fp);

  free(data16);

}

void WriteList (FILE *fp, PAttrib *list, int n) {

  int i;
  ushort *data16=NULL;
  int *data32 =NULL;

  data16 = AllocUShortArray(n);

  for (i=0; i < n; i++)
    data16[i] = list[i].y;
  fwrite(data16,sizeof(ushort),n,fp);

  free(data16);
  
  data32 = AllocIntArray(n);

  for (i=0; i < n; i++)
    data32[i] = list[i].i;
  fwrite(data32,sizeof(int),n,fp);

  free(data32);
}

void WriteBody (FILE *fp, CAttrib *body, int n) {

  int i;
  ushort *data16=NULL;
  int *data32 =NULL;

  data16 = AllocUShortArray(n);

  for (i=0; i < n; i++)
    data16[i] = body[i].normalmag;
  fwrite(data16,sizeof(ushort),n,fp);

  free(data16);
  
  data32 = AllocIntArray(n);

  for (i=0; i < n; i++)
    data32[i] = body[i].val;
  fwrite(data32,sizeof(int),n,fp);

  free(data32);
}

void WriteM(FILE *fp, Image *img)
{
  int n;

  n = img->ncols*img->nrows;
  fwrite(img->val,sizeof(int),n,fp);
}

Shell *NewShell (int xsize, int ysize, int zsize, int nvoxels) {

  Shell *shell=NULL;

  shell=(Shell *)calloc(1, sizeof(Shell));
  if (shell == NULL){
    Error(MSG1,"CreateShell");
  }

  shell->xsize = xsize;
  shell->ysize = ysize;
  shell->zsize = zsize;
  shell->nvoxels = nvoxels;
  shell->scn = NULL;


  shell->voxel=(Attrib *)calloc(shell->nvoxels, sizeof(Attrib));
  if (shell->voxel == NULL) {
    Error(MSG1,"NewShell");
  }

  shell->body = NULL;

  shell->pointer=(PAttrib *)calloc(shell->nvoxels, sizeof(PAttrib));
  if (shell->pointer == NULL) {
    Error(MSG1,"NewShell");
  }

  /* Myz and Mzx */

  shell->Myz=CreateImage(ysize, zsize+1);
  shell->Mzx=CreateImage(zsize, xsize+1);  

  SetImage(shell->Myz,-1);
  SetImage(shell->Mzx,-1);

  shell->Mzx->val[zsize*xsize] = shell->nvoxels;
  shell->Myz->val[zsize*ysize] = shell->nvoxels;

  shell->normaltable = CreateNormalTable();
  shell->nvoxels = nvoxels;
  shell->dx  = 0.0;
  shell->dy  = 0.0;
  shell->dz  = 0.0;  

  return(shell);
}

Shell *NewBodyShell (int xsize, int ysize, int zsize, int nvoxels) {

  Shell *shell=NULL;

  shell= NewShell (xsize,ysize,zsize,nvoxels);
  
  shell->body=(CAttrib *)calloc(shell->nvoxels, sizeof(CAttrib));
  if (shell->body == NULL) {
    Error(MSG1,"NewBodyShell");
  }
  return (shell);
}

Scene *InnerBorder(Scene *bin, int w) {

  int w2 = w*w;
  Scene *dist,*border;
  AdjRel3 *A = Spheric(1.8);

  dist = TDistTrans3(bin,A,BOTH,w2);
  border = Threshold3(dist,0,w2);  
  DestroyScene(&dist);
  DestroyAdjRel3(&A);
  return (border);
}


Shell *Object2Shell (Scene *scn, int w) {

  Shell *shell=NULL;
  int i,n,nvoxels,imax,w2;
  Scene *bin=NULL, *border=NULL, *dist=NULL;
  Curve *c,*l;
  AdjRel3 *A = Spheric(1.8);
  
  n = scn->xsize * scn->ysize * scn->zsize; 
  w2 = w*w;

  nvoxels=0;
  for (i=0;i<n;i++)  
    if (scn->data[i] != 0) 
      nvoxels++;

  c = CreateCurve(2);
  c->X[0] = 0.0; 
  c->Y[0] = 0.5;
  c->X[1] = (double)ROUND((float)w2);
  c->Y[1] = 1.0;

  border = Label2Border(scn,A,BOTH,w2);
  imax = MaximumValue3(border);
  shell = NewShell(scn->xsize,scn->ysize,scn->zsize,nvoxels);
  SetShellVoxels (shell,border);
  SetShellList (shell,border);

  l = ShellObjHistogram(shell);

  for(i=0;i<l->n;i++) {
    if (l->Y[i] > 0) {
      bin = Threshold3(border,i,i);
      dist = TDistTrans3(bin,A,BOTH,w2);
      DestroyScene(&bin);
      SetObjectNormal(shell,dist,DistGradient3,i);
      ClassifyObject(shell,dist,c,DistGradient3,i);
      DestroyScene(&dist);
    }
  }
  DestroyScene(&border);

  shell->dx  = scn->dx;
  shell->dy  = scn->dy;
  shell->dz  = scn->dz;
  shell->maxval = MaximumValue3(scn);
  shell->nobjs  = ShellNObjects(shell);
  DestroyCurve(&c);
  DestroyCurve(&l);
  DestroyAdjRel3(&A);
  return shell;
}

Shell *MergeShell(Shell *shell1, Shell *shell2) {

  Scene *scn,*scn2,*scn1;
  Shell *shell;

  scn1 = LabelScene(shell1);
  scn2 = LabelScene(shell2);
  scn = MergeLabels(scn1,scn2);
  DestroyScene(&scn1); 
  DestroyScene(&scn2); 
  shell = Object2Shell(scn,5);
  DestroyScene(&scn); 
    
  return(shell);
}

Scene *CreateAlpha (Scene *scn) {

  Scene *alpha=NULL;
  alpha = CreateScene(scn->xsize,scn->ysize,scn->zsize);
  SetScene(alpha,255);
  return(alpha);
}


Scene *ObjectAlpha (Scene *scn, int w) {

  int w2,imax,i;
  Curve *c;
  AdjRel3 *A;
  Scene *alpha,*dist,*border,*bin;

  w2 = w*w;
  A = Spheric(1.8);
  c = CreateCurve(2);
  c->X[0] = 0.0; 
  c->Y[0] = 0.5;
  c->X[1] = (double)ROUND((float)w2);
  c->Y[1] = 1.0;
  imax = MaximumValue3(scn);
  alpha = CreateAlpha(scn);
  for (i=1;i<=imax;i++) {
    fprintf(stderr,"Object %d: threshold...\n",i);
    bin = Threshold3(scn,i,i);
    fprintf(stderr,"Object %d: border...\n",i);
    border = InnerBorder(bin,w);
    DestroyScene(&bin);
    fprintf(stderr,"Object %d: edt...\n",i);
    dist = TDistTrans3(border,A,BOTH,w2);
    DestroyScene(&border);
    fprintf(stderr,"Object %d: classification...\n",i);
    ClassifyTDE(dist,alpha,scn,c,Intensity3,i);
    DestroyScene(&dist);
  }
  DestroyCurve(&c);
  DestroyAdjRel3(&A);
  return(alpha);
}

Scene *OpacityScene (Shell *shell) {

  Scene *scn;
  int i,i1,i2,j;
  Voxel v;

  scn = CreateScene(shell->xsize,shell->ysize,shell->zsize);
  for (v.z = 0; v.z != shell->zsize; v.z ++) 
    for (v.y = 0; v.y != shell->ysize; v.y ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {	  
	  v.x = shell->voxel[i].x;
          j = scn->tbz[v.z] + scn->tby[v.y] + v.x;
	  scn->data[j] = shell->voxel[i].opac;
	}
      }
    }
  return(scn);
}

Scene *NormalIndexScene (Shell *shell) {

  Scene *scn;
  int i,i1,i2,j;
  Voxel v;

  scn = CreateScene(shell->xsize,shell->ysize,shell->zsize);
  for (v.z = 0; v.z != shell->zsize; v.z ++) 
    for (v.y = 0; v.y != shell->ysize; v.y ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {	  
	  v.x = shell->voxel[i].x;
          j = scn->tbz[v.z] + scn->tby[v.y] + v.x;
	  scn->data[j] = shell->voxel[i].normal;
	}
      }
    }
  return(scn);
}

Scene *LabelScene (Shell *shell) {

  Scene *scn;
  int i,i1,i2,j;
  Voxel v;

  scn = CreateScene(shell->xsize,shell->ysize,shell->zsize);
  for (v.z = 0; v.z != shell->zsize; v.z ++) 
    for (v.y = 0; v.y != shell->ysize; v.y ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {	  
	  v.x = shell->voxel[i].x;
          j = scn->tbz[v.z] + scn->tby[v.y] + v.x;
	  scn->data[j] = shell->voxel[i].obj;
	}
      }
    }
  return(scn);
}

Scene *FilledLabelScene (Shell *shell) {

  Scene *scn;
  Image *img,*fimg;
  int i;

  scn = CreateScene(shell->xsize,shell->ysize,shell->zsize);
  for (i=0;i<shell->zsize;i++) {
    img = GetShellZSlice(shell,i);
    fimg = FillSlice(img);
    DestroyImage(&img);
    PutSlice(fimg,scn,i);
    DestroyImage(&fimg);
  }
  return(scn);
}

Scene *ValueScene (Shell *shell) {

  Scene *scn;
  int i,i1,i2,j;
  Voxel v;

  scn = CreateScene(shell->xsize,shell->ysize,shell->zsize);

  if (!shell->body) return (scn);
 
  for (v.z = 0; v.z != shell->zsize; v.z ++) 
    for (v.y = 0; v.y != shell->ysize; v.y ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {
 	  v.x = shell->voxel[i].x;
          j = scn->tbz[v.z] + scn->tby[v.y] + v.x;
	  scn->data[j] = shell->body[i].val;	  
	}
      }
    }
  return(scn);
}

Scene *ObjectScene (Shell *shell, int obj) {

  Scene *scn;
  int i,i1,i2,j;
  Voxel v;

  scn = CreateScene(shell->xsize,shell->ysize,shell->zsize);
  for (v.z = 0; v.z != shell->zsize; v.z ++) 
    for (v.y = 0; v.y != shell->ysize; v.y ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {
          if (shell->voxel[i].obj == obj) {
 	    v.x = shell->voxel[i].x;
            j = scn->tbz[v.z] + scn->tby[v.y] + v.x;
	    scn->data[j] = shell->voxel[i].obj;
	  }
	}
      }
    }
  return(scn);
}

Scene *RemoveVoxels (Shell *shell, float low, float hi) {

  AdjRel3 *A;
  Scene *scn,*tmp;
  Voxel v,q;
  int i,i1,i2,j,k,n;
  uchar a_l,a_h,a;
  a_l = (uchar)low/255.;
  a_h = (uchar)hi/255.;

  A = Spheric(1.8);
  scn = CreateScene(shell->xsize,shell->ysize,shell->zsize);
  tmp = OpacityScene(shell);
  
  for (v.z = 0; v.z != shell->zsize; v.z ++) 
    for (v.y = 0; v.y != shell->ysize; v.y ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {	  
	  v.x = shell->voxel[i].x;
	  a = shell->voxel[i].opac;
          j = scn->tbz[v.z] + scn->tby[v.y] + v.x;
          if (a > a_l) {
            scn->data[j] = shell->voxel[i].obj;  
            for (k=0;k<A->n;k++) {
              q.x = v.x + A->dx[k];
              q.y = v.y + A->dy[k];
              q.z = v.z + A->dz[k];
 	      if (ValidVoxel(scn, q.x, q.y, q.z)) {
                n = tmp->tbz[q.z] + tmp->tby[q.y] + q.x;
                if (tmp->data[n] < a_h) {
		}
	      }
	    }
	  }
	}
      }
    }
  DestroyAdjRel3(&A);
  return(scn);
}


Shell *Scene2Shell (Scene *scn) {

  Shell *shell=NULL;
  int i,n,nvoxels;
  
  shell=(Shell *)calloc(1, sizeof(Shell));
  if (shell == NULL){
    Error(MSG1,"CreateShell");
  }

  n = scn->xsize * scn->ysize * scn->zsize; 
  
  nvoxels=0;
  for (i=0;i<n;i++)  
    if (scn->data[i] != 0) 
      nvoxels++;

  shell = NewBodyShell(scn->xsize,scn->ysize,scn->zsize,nvoxels);
  
  SetShellVoxels(shell,scn);
  SetShellList(shell,scn);
  SetBodyShellNormal(shell,scn,Gradient3);
  SetBodyShellValue(shell,scn);

  shell->dx  = scn->dx;
  shell->dy  = scn->dy;
  shell->dz  = scn->dz;
  shell->maxval = MaximumValue3(scn);
  shell->nobjs = 0;
  return shell;
}

void SetShellVoxels (Shell *shell, Scene *scn) {
  
  int i,j,k;
  Voxel v;

  i=0;
  for(v.z=0;v.z<scn->zsize;v.z++)
    for(v.y=0;v.y<scn->ysize;v.y++)
      for(v.x=0;v.x<scn->xsize;v.x++) { 
	k = scn->tbz[v.z] + scn->tby[v.y] + v.x;
        if (scn->data[k] != 0) {
	  j = shell->Myz->tbrow[v.z] + v.y;
	  if (shell->Myz->val[j] < 0) {
	    shell->Myz->val[j]=i;
	  }
  	  shell->voxel[i].x = v.x;
	  shell->voxel[i].opac = 255;
	  shell->voxel[i].visible = 1;
	  if (shell->body)
	    shell->voxel[i].obj = 0;
	  else	    
	    shell->voxel[i].obj = (uchar)scn->data[k];
	  i++;
	}
      }
}

void SetShellNormalIndex (Shell *shell, Scene *nscn) {

  int i,i1,i2,j;
  Voxel v;

  for (v.z = 0; v.z != shell->zsize; v.z ++) 
    for (v.y = 0; v.y != shell->ysize; v.y ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {	  
	  v.x = shell->voxel[i].x;
	  j = nscn->tbz[v.z] + nscn->tby[v.y] + v.x;	  
	  shell->voxel[i].normal = (ushort)nscn->data[j];
	}        
      }
    }

}

void SetShellList (Shell *shell, Scene *scn) {

  int i,j,k;
  Voxel v;

  i=0;  
  for(v.x=0;v.x<scn->xsize;v.x++)
    for(v.z=0;v.z<scn->zsize;v.z++)
      for(v.y=0;v.y<scn->ysize;v.y++) { 
	k = scn->tbz[v.z] + scn->tby[v.y] + v.x;
        if (scn->data[k] != 0) {
	  j = shell->Mzx->tbrow[v.x] + v.z;
          if (shell->Mzx->val[j] < 0) {
            shell->Mzx->val[j]=i;
          }	  
	  shell->pointer[i].i = GetPointer(shell,&v);
	  shell->pointer[i].y = v.y;
	  i++;
	}
      }    
}


void SetShellLabel (Shell *shell, Scene *lscn) {

  int i,i1,i2,k;
  Voxel v;
  AdjRel3 *A = Spheric(1.8);

  for (v.z = 0; v.z != shell->zsize; v.z ++) 
    for (v.y = 0; v.y != shell->ysize; v.y ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {	  
	  v.x = shell->voxel[i].x;
	  k = lscn->tbz[v.z] + lscn->tby[v.y] + v.x;	  
	  shell->voxel[i].obj = (uchar)lscn->data[k];
	}        
      }
    }
  ShellNObjects(shell);
  DestroyAdjRel3(&A);
}

void SetShellOpacity (Shell *shell, Scene *alpha) {

  int i,i1,i2,k;
  Voxel v;

  for (v.z = 0; v.z != shell->zsize; v.z ++) 
    for (v.y = 0; v.y != shell->ysize; v.y ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {	  
	  v.x = shell->voxel[i].x;
	  k = alpha->tbz[v.z] + alpha->tby[v.y] + v.x;	  
	  shell->voxel[i].obj = (uchar)alpha->data[k];
	}        
      }
    }

}



void SetBodyShellValue (Shell *shell, Scene *scn) {

  int i,i1,i2,k;
  Voxel v;
  AdjRel3 *A = NULL;
  AdjVxl *V = NULL;

  A = Spheric(1.8);
  V = AdjVoxels(scn,A);

  for (v.z = 0; v.z != shell->zsize; v.z ++) 
    for (v.y = 0; v.y != shell->ysize; v.y ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {	  
	  v.x = shell->voxel[i].x;
	  k = scn->tbz[v.z] + scn->tby[v.y] + v.x;	  
	  shell->body[i].val = scn->data[k];
	}        
      }
    }
  DestroyAdjRel3(&A);
  DestroyAdjVxl(&V);
}

int GetPointer(Shell *shell, Voxel *v) {
 
  int low,hi,mid,i;

  i = shell->Myz->tbrow[v->z] + v->y;

  low = shell->Myz->val[i];
  do {
    i++;
  } while (shell->Myz->val[i] < 0);
  hi = shell->Myz->val[i]-1;

  /* Binary search for index using current coord x as key*/

  while (low <= hi) {
    mid = (low + hi)/2;
    if (v->x == shell->voxel[mid].x)
      return(mid);
    if (v->x < shell->voxel[mid].x)
      hi=mid-1;
    else 
      low=mid+1;
  }
  return(-1);
}


int VoxelExist(Shell *shell, Voxel *v) {

  int i = 0;
  int j = 0;

  if (v->x < 0) return -1;
  if (v->y < 0) return -1;
  if (v->z < 0) return -1;
  if (v->x >= shell->xsize) return -1;
  if (v->y >= shell->ysize) return -1;
  if (v->z >= shell->zsize) return -1;

  i = shell->Myz->tbrow[v->z] + v->y;
  if (shell->Myz->val[i] < 0) return -1;
  j = shell->Mzx->tbrow[v->x] + v->z;
  if (shell->Mzx->val[j] < 0) return -1;
  j  = GetPointer(shell,v);
  return (j);
}


Image *InverseWarp (Image *simg, Context *cxt) {

  Image *img = CreateImage(cxt->width,cxt->height);
  int uw,vw,i,i2,iw;
  float u,v,ut,vt,w[4];
  Pixel c;

  c.x = img->nrows/2; 
  c.y = img->ncols/2;
  
  ut = cxt->isize/2;
  vt = cxt->jsize/2;

  for (vw=0;vw<img->nrows-1;vw++)
    for (uw=0;uw<img->ncols;uw++) {      

      u = (cxt->IW[0][0] * (uw-c.x) + cxt->IW[0][1] * (vw-c.y)) + ut;
      v = (cxt->IW[1][0] * (uw-c.x) + cxt->IW[1][1] * (vw-c.y)) + vt;
       
      if (ValidPixel(simg,u,v)) {

	w[0] = u - (float)(int)u;
	w[1] = v - (float)(int)v;
	w[2] = (float)((int)u + 1) - u;
	w[3] = (float)((int)v + 1) - v;

	i = simg->tbrow[(int)v] + (int)u;
	i2 = img->tbrow[(int)v+1] + (int)u;
	iw = img->tbrow[vw] + uw;

        simg->val[iw] = ((simg->val[i]*w[0] + simg->val[i+1]*w[2]) * w[1] + \
			 (simg->val[i2]*w[0] + simg->val[i2+1]*w[2]) * w[3]);

      }
    }
  return(img);
}


Image *SWShellRendering(Shell *shell,Context *cxt) {

  Image *img=NULL;
  FBuffer *shear=NULL,*warp=NULL;
  Voxel p,q,c;
  Pixel d;
  AdjPxl *fprint=NULL;

  int u,v,ut,vt,uw,vw,is,iw,iw_p,i,i_p,i1,i2,j,n;
  float w,wt,amb,spec,diff,shading,idist,cos_a,cos_2a,pow,nopac[256],opac;
  uchar l;

  for(i=0;i<256;i++)
    nopac[i] = (float)i/255.;

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  shear = CreateFBuffer(cxt->isize, cxt->jsize);
  warp = CreateFBuffer(cxt->width, cxt->height);
  InitFBuffer(shear,1.0);
  InitFBuffer(warp,1.0);
  
  img=CreateImage(cxt->width, cxt->height);
  fprint = AdjPixels(img,cxt->footprint->adj);
    
  switch(cxt->PAxis) {

  case 'x':
    
    for (p.x = cxt->xi; p.x != cxt->xf; p.x += cxt->dx) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Mzx->tbrow[p.x] + p.z;
        
        if (shell->Mzx->val[i] >= 0) {
          
          if (cxt->dy == 1) {              
            i1 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i2 = shell->Mzx->val[i]-1;            
          } else {            
            i2 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i1 = shell->Mzx->val[i]-1;
	  }
	  i2 += cxt->dy;          
          for (i = i1; i != i2; i += cxt->dy) {

	    // shear
            p.y = shell->pointer[i].y;

	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;

	    u = (int) (q.y + cxt->Su[p.x]); 
	    v = (int) (q.z + cxt->Sv[p.x]); 

	    is = u + ut + shear->tbv[v + vt];

	    if (shear->val[is] > 0.05) {
	    
	      // normal
	      i_p = shell->pointer[i].i;
	      l = shell->voxel[i_p].obj;
	      
	      if (l) {
		n = shell->voxel[i_p].normal;
		
		cos_a = cxt->viewer.x * shell->normaltable[n].x +\
		  cxt->viewer.y * shell->normaltable[n].y +\
		  cxt->viewer.z * shell->normaltable[n].z;

		if (cos_a > 0.0) {

		  // shading

		  w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		  idist = 1.0 - w/(float)cxt->depth;

		  cos_2a = 2*cos_a*cos_a - 1.0;
	      
		  if (cos_2a < 0.) {
		    pow = 0.;
		    spec = 0.;
		  } else {
		    pow = 1.;
		    for (j=0; j < cxt->obj[l].ns; j++) 
		      pow = pow * cos_2a;
		    spec = cxt->obj[l].spec * pow;
		  }

		  opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		  amb  = cxt->obj[l].amb;
		  diff = cxt->obj[l].diff * cos_a;

		  shading = (float)255. * opac * (amb + idist * (diff + spec));

		  //warp	      
		  uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
	      
		  vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);

		  iw = warp->tbv[vw + d.y] + uw + d.x;
	      
		  // splatting
		  for (j=0; j < fprint->n; j++){		
		    iw_p = iw + fprint->dp[j];
		    if (warp->val[iw_p] > .05) {                
		      img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->footprint->val[j]);
		      warp->val[iw_p] *= (1.0- (opac * cxt->footprint->val[j]));
		    }
		  }
		  shear->val[is]=warp->val[iw];
		}
	      }
	    }	    
	  }
	}
      }

    break;
    
  case 'y': 
    
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
            p.x = shell->voxel[i].x;
	   
	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;
	    
	    u = (int) (q.z + cxt->Su[p.y]); 
	    v = (int) (q.x + cxt->Sv[p.y]); 

	    is = u + ut+ shear->tbv[v + vt];

	    if (shear->val[is] > 0.05) {
	      
	      // normal
	      i_p = i;
	      l = shell->voxel[i_p].obj;
	      if (l) {
		n = shell->voxel[i_p].normal;

		cos_a = cxt->viewer.x * shell->normaltable[n].x +\
		  cxt->viewer.y * shell->normaltable[n].y +\
		  cxt->viewer.z * shell->normaltable[n].z;

		if (cos_a > 0.0) {

		  // shading

		  w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		  idist = 1.0 - w/(float)cxt->depth;

		  cos_2a = 2*cos_a*cos_a - 1.0;
		
		  if (cos_2a < 0.) {
		    pow = 0.;
		    spec = 0.;
		  } else {
		    pow = 1.;
		    for (j=0; j < cxt->obj[l].ns; j++) 
		      pow = pow * cos_2a;
		    spec = cxt->obj[l].spec * pow;
		  }

		  opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		  amb  = cxt->obj[l].amb;
		  diff = cxt->obj[l].diff * cos_a;
		
		  shading = (float)255. * opac * (amb + idist * (diff + spec));
		
		  // warp	      
		  uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		  vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		
		  iw = warp->tbv[vw + d.y] + uw + d.x;
		
		  // splatting
		  for (j=0; j < fprint->n; j++){		
		    iw_p = iw + fprint->dp[j];
		    if (warp->val[iw_p] > .05) {                
		      img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->footprint->val[j]);
		      warp->val[iw_p] *= (1.0- (opac * cxt->footprint->val[j]));
		    }
		  }
		  shear->val[is]=warp->val[iw];
		}
	      }
	    }
	  }
	}
      }
    break;

  case 'z': 
    
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) 
      for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
            p.x = shell->voxel[i].x;

	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z; 

	    u = (int) (q.x + cxt->Su[p.z]); 
	    v = (int) (q.y + cxt->Sv[p.z]); 

	    is = u + ut + shear->tbv[v + vt];
	    
	    if (shear->val[is] > 0.05) {
	      
	      // normal
	      i_p = i;
	      l = shell->voxel[i_p].obj;
	      if (l) {

		n = shell->voxel[i_p].normal;

		cos_a = cxt->viewer.x * shell->normaltable[n].x +\
		  cxt->viewer.y * shell->normaltable[n].y +\
		  cxt->viewer.z * shell->normaltable[n].z;

		if (cos_a > 0.0) {

                    	       		  
		  // shading
		  
		  w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		  idist = 1.0 - w/(float)cxt->depth;
		  
		  cos_2a = 2*cos_a*cos_a - 1.0;
		  
		  if (cos_2a < 0.) {
		    pow = 0.;
		    spec = 0.;
		  } else {
		    pow = 1.;
		    for (j=0; j < cxt->obj[l].ns; j++) 
		      pow = pow * cos_2a;
		    spec = cxt->obj[l].spec * pow;
		  }
		  
		  opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		  amb  = cxt->obj[l].amb;
		  diff = cxt->obj[l].diff * cos_a;
		  
		  shading = (float)255. * opac * (amb + idist * (diff + spec));
		  
		  // warp
		  uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		  
		  vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		
		  iw = warp->tbv[vw + d.y] + uw + d.x;
		  
		  // splatting
		  
		  for (j=0; j < fprint->n; j++){		
		    iw_p = iw + fprint->dp[j];
		    if (warp->val[iw_p] > .05) {                
		      img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->footprint->val[j]);
		      warp->val[iw_p] *= (1.0- (opac * cxt->footprint->val[j]));
		    }
		  }	      
		  shear->val[is]=warp->val[iw];
		}
	      }
	    }
	  }
	}
      }
    break;
    
  default: 
    Error(MSG1,"SWShellRendering");
    break;    
  }			
  DestroyFBuffer(&shear);
  DestroyFBuffer(&warp);
  DestroyAdjPxl(&fprint);
  return(img);
}
		
Image *ShellRendering (Shell *shell, Context *cxt) {

  Image *img=NULL;
  FBuffer *buff=NULL;
  Voxel c,p,q;
  Vector viewer;
  AdjPxl *fprint=NULL;

  int u,v,i1,i2,i,i_p,is,j,n,ut,vt;
  float w,wt,amb,spec,diff,shading,idist,cos_a,cos_2a,pow,nopac[256],opac;
  uchar l;

  for(i=0;i<256;i++)
    nopac[i] = (float)i/255.;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // image translation
  ut = cxt->width/2; 
  vt = cxt->height/2;
  wt = (float)cxt->depth/2;

  buff = CreateFBuffer(cxt->width, cxt->height);
  InitFBuffer(buff,1.0);
 
  img = CreateImage(cxt->width, cxt->height);
  fprint = AdjPixels(img,cxt->footprint->adj);

  viewer.x = -cxt->IR[0][2];
  viewer.y = -cxt->IR[1][2];
  viewer.z = -cxt->IR[2][2];
    
  for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) 
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
        
      i = shell->Myz->tbrow[p.z] + p.y;
        
      if (shell->Myz->val[i] >= 0) {
	
	if (cxt->dx == 1) {              
	  i1 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Myz->val[i]-1;            
	} else {            
	  i2 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Myz->val[i]-1;
	}
	i2 += cxt->dx;

	for (i = i1; i != i2; i += cxt->dx) {
	  l = shell->voxel[i].obj;
	  if (l) {
	    p.x = shell->voxel[i].x;

	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;
	  
	    u = (int)((cxt->R[0][0]*q.x) + (cxt->R[0][1]*q.y) + (cxt->R[0][2]*q.z) + ut);
	    v = (int)((cxt->R[1][0]*q.x) + (cxt->R[1][1]*q.y) + (cxt->R[1][2]*q.z) + vt);

	    i_p = u + buff->tbv[v];
	  
	    if (buff->val[i_p] > 0.05){

	      // normal
	      n = shell->voxel[i].normal;
	    
	      cos_a = viewer.x * shell->normaltable[n].x +\
		viewer.y * shell->normaltable[n].y +\
		viewer.z * shell->normaltable[n].z;
	    
	      if (cos_a > 0) {
	      
		// shading
		w = (cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z)+ wt;
		idist = 1.0 - (w / (float)cxt->depth);

		cos_2a = 2*cos_a*cos_a - 1.0;
	      
		if (cos_2a < 0.) {
		  pow = 0.;
		  spec = 0.;
		} else {
		  pow = 1.;
		  for (j=0; j < cxt->obj[l].ns; j++) 
		    pow = pow * cos_2a;
		  spec = cxt->obj[l].spec * pow;
		}
		opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		amb  = cxt->obj[l].amb;
		diff = cxt->obj[l].diff * cos_a;
	      
		shading =  255.* opac * (amb + idist * (diff + spec));

		/* Splatting */
		for (j=0; j < fprint->n; j++){		
		  is = i_p + fprint->dp[j];
		  if (buff->val[is] > .05) {                
		    img->val[is] += (int)(shading * buff->val[is] * cxt->footprint->val[j]);
		    buff->val[is] *= (1.0- (opac * cxt->footprint->val[j]));
		  }
		}	
	      }  
	    }
	  }
	}
      }
    }

  DestroyFBuffer(&buff);
  DestroyAdjPxl(&fprint);
  
  return(img);
}


Image *ISWShellRendering(Shell *shell,Context *cxt) 
{
  Image *tmpimg=NULL;
 

  return(tmpimg);
}

Image *DirectVolumeRendering(Shell *shell,Context *cxt) {

  Image *img=NULL;
  FBuffer *shear=NULL,*warp=NULL;
  Voxel p,q,c;
  Pixel d;
  Vector viewer;
  AdjPxl *fprint=NULL;

  int u,v,ut,vt,uw,vw,is,iw,iw_p,i,i_p,i1,i2,j,n;
  float w,wt,amb,spec,diff,shading,idist,cos_a,cos_2a,pow,nopac[256],opac;
  uchar l;

  for(i=0;i<256;i++)
    nopac[i] = (float)i/255.;

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  shear = CreateFBuffer(cxt->isize, cxt->jsize);
  warp = CreateFBuffer(cxt->width, cxt->height);
  InitFBuffer(shear,1.0);
  InitFBuffer(warp,1.0);
  
  img=CreateImage(cxt->width, cxt->height);
  fprint = AdjPixels(img,cxt->footprint->adj);

  viewer.x = -cxt->IR[0][2];
  viewer.y = -cxt->IR[1][2];
  viewer.z = -cxt->IR[2][2];
    
  switch(cxt->PAxis) {

  case 'x':
    
    for (p.x = cxt->xi; p.x != cxt->xf; p.x += cxt->dx) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Mzx->tbrow[p.x] + p.z;
        
        if (shell->Mzx->val[i] >= 0) {
          
          if (cxt->dy == 1) {              
            i1 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i2 = shell->Mzx->val[i]-1;            
          } else {            
            i2 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i1 = shell->Mzx->val[i]-1;
	  }
	  i2 += cxt->dy;          
          for (i = i1; i != i2; i += cxt->dy) {

	    // shear

	    i_p = shell->pointer[i].i;

            if (shell->voxel[i_p].opac > 0.05) {
 
	      p.y = shell->pointer[i].y;

	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;

	      u = (int) (q.y + cxt->Su[p.x]); 
	      v = (int) (q.z + cxt->Sv[p.x]); 

	      is = u + ut + shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {
	    
		// normal

		n = shell->voxel[i_p].normal;

		cos_a = fabs(viewer.x * shell->normaltable[n].x +\
			     viewer.y * shell->normaltable[n].y +\
			     viewer.z * shell->normaltable[n].z);
	      

		// shading
		l = shell->voxel[i_p].obj;
		w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		idist = 1.0 - w/(float)cxt->depth;
	      
		cos_2a = 2*cos_a*cos_a - 1.0;
	      
		if (cos_2a < 0.) {
		  pow = 0.;
		  spec = 0.;
		} else {
		  pow = 1.;
		  for (j=0; j < cxt->obj[l].ns; j++) 
		    pow = pow * cos_2a;
		  spec = cxt->obj[l].spec * pow;
		}

		opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		amb  = cxt->obj[l].amb;
		diff = cxt->obj[l].diff * cos_a;

		shading =  255. * opac * (amb + idist * (diff + spec));

		//warp	      
		uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
	      
		vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);

		iw = warp->tbv[vw + d.y] + uw + d.x;
	      
		// splatting
		for (j=0; j < fprint->n; j++){		
		  iw_p = iw + fprint->dp[j];
		  if (warp->val[iw_p] > .05) {                
		    img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->footprint->val[j]);
		    warp->val[iw_p] *= (1.0- (opac * cxt->footprint->val[j]));
		  }
		}
		shear->val[is]=warp->val[iw];
	      }
	    }
	  }
	}
      }
  

    break;
    
  case 'y': 
    
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
	    i_p = i;

            if (shell->voxel[i_p].opac > 0.05) {

	      p.x = shell->voxel[i].x;
	   
	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	    
	      u = (int) (q.z + cxt->Su[p.y]); 
	      v = (int) (q.x + cxt->Sv[p.y]); 

	      is = u + ut+ shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {
	      
		// normal
		n = shell->voxel[i_p].normal;

		cos_a = fabs(viewer.x * shell->normaltable[n].x +\
			     viewer.y * shell->normaltable[n].y +\
			     viewer.z * shell->normaltable[n].z);

		// shading
		l = shell->voxel[i_p].obj;
		w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		idist = 1.0 - w/(float)cxt->depth;

		cos_2a = 2*cos_a*cos_a - 1.0;
		
		if (cos_2a < 0.) {
		  pow = 0.;
		  spec = 0.;
		} else {
		  pow = 1.;
		  for (j=0; j < cxt->obj[l].ns; j++) 
		    pow = pow * cos_2a;
		  spec = cxt->obj[l].spec * pow;
		}

		opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		amb  = cxt->obj[l].amb;
		diff = cxt->obj[l].diff * cos_a;
		
		shading =  opac * (amb + idist * (diff + spec));
		
		// warp	      
		uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		
		iw = warp->tbv[vw + d.y] + uw + d.x;
		
		// splatting
		for (j=0; j < fprint->n; j++){		
		  iw_p = iw + fprint->dp[j];
		  if (warp->val[iw_p] > .05) {                
		    img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->footprint->val[j]);
		    warp->val[iw_p] *= (1.0- (opac * cxt->footprint->val[j]));
		  }
		}
		shear->val[is]=warp->val[iw];
	      }
	    }
	  }
	}
      }

    break;

  case 'z': 
    
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) 
      for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
	    i_p = i;

            if (shell->voxel[i_p].opac > 0.05) {

	      p.x = shell->voxel[i].x;

	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z; 

	      u = (int) (q.x + cxt->Su[p.z]); 
	      v = (int) (q.y + cxt->Sv[p.z]); 

	      is = u + ut + shear->tbv[v + vt];
	    
	      if (shear->val[is] > 0.05) {
	      
		// normal
		n = shell->voxel[i_p].normal;

		cos_a = fabs(viewer.x * shell->normaltable[n].x +\
			     viewer.y * shell->normaltable[n].y +\
			     viewer.z * shell->normaltable[n].z);


		// shading
		l = shell->voxel[i_p].obj;
		w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		idist = 1.0 - w/(float)cxt->depth;

		cos_2a = 2*cos_a*cos_a - 1.0;
		
		if (cos_2a < 0.) {
		  pow = 0.;
		  spec = 0.;
		} else {
		  pow = 1.;
		  for (j=0; j < cxt->obj[l].ns; j++) 
		    pow = pow * cos_2a;
		  spec = cxt->obj[l].spec * pow;
		}

		opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		amb  = cxt->obj[l].amb;
		diff = cxt->obj[l].diff * cos_a;
		
		shading =  opac * (amb + idist * (diff + spec));
		
		// warp
		uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		
		iw = warp->tbv[vw + d.y] + uw + d.x;
		
		// splatting
		
		for (j=0; j < fprint->n; j++){		
		  iw_p = iw + fprint->dp[j];
		  if (warp->val[iw_p] > .05) {                
		    img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->footprint->val[j]);
		    warp->val[iw_p] *= (1.0- (opac * cxt->footprint->val[j]));
		  }
		}	      
		shear->val[is]=warp->val[iw];
	      }
	    }
	  }
	}
      }

    break;
      
  default: 
    Error(MSG1,"DirectVolumeRendering");
    break;
    
  }			
  DestroyFBuffer(&shear);
  DestroyFBuffer(&warp);
  DestroyAdjPxl(&fprint);
  return(img);
}


void EWAKernel(Kernel *K,float vx, float vy, float E, float R, float s, float f)
{
  float z,e,r_xy,R2,r2,z2,e2;
  int i;

  R2 = R*R;
  for (i=0;i<K->adj->n;i++) {
    z = (-K->adj->dx[i] * vx) + (-K->adj->dy[i] * vy);
    r2 = K->adj->dx[i] * K->adj->dx[i] + K->adj->dy[i] * K->adj->dy[i];
    z2 = z*z;    
    r_xy = r2 - z2;
    e = r_xy/E;
    e2 = e*e;
    K->val[i] = s*exp (-f*(e2 + z2)/R2);
  }
}

Image *EWASWShellRendering(Shell *shell,Context *cxt) {

  Image *img=NULL;
  FBuffer *shear=NULL,*warp=NULL;
  Voxel p,q,c;
  Pixel d;
  Vector viewer;
  AdjPxl *fprint=NULL;

  int u,v,ut,vt,uw,vw,is,iw,iw_p,i,i_p,i1,i2,j,n;
  float w,wt,amb,spec,diff,shading,idist,cos_a,cos_2a,pow,nopac[256],opac;
  uchar l;

  for(i=0;i<256;i++)
    nopac[i] = (float)i/255.;

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  shear = CreateFBuffer(cxt->isize, cxt->jsize);
  warp = CreateFBuffer(cxt->width, cxt->height);
  InitFBuffer(shear,1.0);
  InitFBuffer(warp,1.0);

  img=CreateImage(cxt->width, cxt->height);
  fprint = AdjPixels(img,cxt->footprint->adj);

  viewer.x = -cxt->IR[0][2];
  viewer.y = -cxt->IR[1][2];
  viewer.z = -cxt->IR[2][2];
    
  switch(cxt->PAxis) {

  case 'x':
    
    for (p.x = cxt->xi; p.x != cxt->xf; p.x += cxt->dx) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Mzx->tbrow[p.x] + p.z;
        
        if (shell->Mzx->val[i] >= 0) {
          
          if (cxt->dy == 1) {              
            i1 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i2 = shell->Mzx->val[i]-1;            
          } else {            
            i2 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i1 = shell->Mzx->val[i]-1;
	  }
	  i2 += cxt->dy;          
          for (i = i1; i != i2; i += cxt->dy) {

	    // shear
            p.y = shell->pointer[i].y;

	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;

	    u = (int) (q.y + cxt->Su[p.x]); 
	    v = (int) (q.z + cxt->Sv[p.x]); 

	    is = u + ut + shear->tbv[v + vt];

	    if (shear->val[is] > 0.05) {
	    
	      // normal
	      i_p = shell->pointer[i].i;
	      n = shell->voxel[i_p].normal;

	      cos_a = viewer.x * shell->normaltable[n].x +\
		viewer.y * shell->normaltable[n].y +\
		viewer.z * shell->normaltable[n].z;

	      if (cos_a > 0) {

		// shading
		l = shell->voxel[i_p].obj;
		w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		idist = 1.0 - w/(float)cxt->depth;

		cos_2a = 2*cos_a*cos_a - 1.0;
	      
		if (cos_2a < 0.) {
		  pow = 0.;
		  spec = 0.;
		} else {
		  pow = 1.;
		  for (j=0; j < cxt->obj[l].ns; j++) 
		    pow = pow * cos_2a;
		  spec = cxt->obj[l].spec * pow;
		}

		opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		amb  = cxt->obj[l].amb;
		diff = cxt->obj[l].diff * cos_a;

		shading =  opac * (amb + idist * (diff + spec));

		//warp	      
		uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
	      
		vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);

		iw = warp->tbv[vw + d.y] + uw + d.x;
	      
		// splatting
		EWAKernel(cxt->footprint,shell->normaltable[n].z,shell->normaltable[n].y, shell->normaltable[n].x, 2.5, 1.0,1.0);
		for (j=0; j < fprint->n; j++){		
		  iw_p = iw + fprint->dp[j];
		  if (warp->val[iw_p] > .05) {                
		    img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->footprint->val[j]);
		    warp->val[iw_p] *= (1.0- (opac * cxt->footprint->val[j]));
		  }
		}
		shear->val[is]=warp->val[iw];
	      }
	    }
	  }
	}
      }

    break;
    
  case 'y': 
    
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
            p.x = shell->voxel[i].x;
	   
	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;
	    
	    u = (int) (q.z + cxt->Su[p.y]); 
	    v = (int) (q.x + cxt->Sv[p.y]); 

	    is = u + ut+ shear->tbv[v + vt];

	    if (shear->val[is] > 0.05) {
	      
	      // normal
	      i_p = i;
	      n = shell->voxel[i_p].normal;

	      cos_a = viewer.x * shell->normaltable[n].x +\
		viewer.y * shell->normaltable[n].y +\
		viewer.z * shell->normaltable[n].z;

	      if (cos_a > 0) {

		// shading
		l = shell->voxel[i_p].obj;
		w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		idist = 1.0 - w/(float)cxt->depth;

		cos_2a = 2*cos_a*cos_a - 1.0;
		
		if (cos_2a < 0.) {
		  pow = 0.;
		  spec = 0.;
		} else {
		  pow = 1.;
		  for (j=0; j < cxt->obj[l].ns; j++) 
		    pow = pow * cos_2a;
		  spec = cxt->obj[l].spec * pow;
		}

		opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		amb  = cxt->obj[l].amb;
		diff = cxt->obj[l].diff * cos_a;
		
		shading =  opac * (amb + idist * (diff + spec));
		
		// warp	      
		uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		
		iw = warp->tbv[vw + d.y] + uw + d.x;
		
		// splatting
		EWAKernel(cxt->footprint,shell->normaltable[n].y,shell->normaltable[n].z, shell->normaltable[n].x, 2.5, 1.0,1.0);
		for (j=0; j < fprint->n; j++){		
		  iw_p = iw + fprint->dp[j];
		  if (warp->val[iw_p] > .05) {                
		    img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->footprint->val[j]);
 		    warp->val[iw_p] *= (1.0- (opac * cxt->footprint->val[j]));
		  }
		}
		shear->val[is]=warp->val[iw];
	      }
	    }
	  }
	}
      }
    break;

  case 'z': 
    
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) 
      for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
            p.x = shell->voxel[i].x;

	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z; 

	    u = (int) (q.x + cxt->Su[p.z]); 
	    v = (int) (q.y + cxt->Sv[p.z]); 

	    is = u + ut + shear->tbv[v + vt];
	    
	    if (shear->val[is] > 0.05) {
	      
	      // normal
	      i_p = i;
	      n = shell->voxel[i_p].normal;

	      cos_a = viewer.x * shell->normaltable[n].x +\
		viewer.y * shell->normaltable[n].y +\
		viewer.z * shell->normaltable[n].z;

	      if (cos_a > 0) {

		// shading
		l = shell->voxel[i_p].obj;
		w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		idist = 1.0 - w/(float)cxt->depth;

		cos_2a = 2*cos_a*cos_a - 1.0;
		
		if (cos_2a < 0.) {
		  pow = 0.;
		  spec = 0.;
		} else {
		  pow = 1.;
		  for (j=0; j < cxt->obj[l].ns; j++) 
		    pow = pow * cos_2a;
		  spec = cxt->obj[l].spec * pow;
		}
		
		opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		amb  = cxt->obj[l].amb;
		diff = cxt->obj[l].diff * cos_a;
		
		shading =  opac * (amb + idist * (diff + spec));
		
		// warp
		uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		
		iw = warp->tbv[vw + d.y] + uw + d.x;
		
		// splatting
		EWAKernel(cxt->footprint,shell->normaltable[n].x,shell->normaltable[n].y, shell->normaltable[n].z, 2.5, 1.0,1.0);
		for (j=0; j < fprint->n; j++){		
		  iw_p = iw + fprint->dp[j];
		  if (warp->val[iw_p] > .05) {                
		    img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->footprint->val[j]);
		    warp->val[iw_p] *= (1.0- (opac * cxt->footprint->val[j]));
		  }
		}	      
		shear->val[is]=warp->val[iw];
	      }
	    }
	  }
	}
      }
    break;
      
  default: 
    Error(MSG1,"SWShellRendering");
    break;
    
  }			
  DestroyFBuffer(&shear);
  DestroyFBuffer(&warp);
  DestroyAdjPxl(&fprint);
  return(img);
}

Image *MIPShell(Shell *shell, Context *cxt, Curve *cs) {

  Image *img=NULL,*tmp=NULL;
  Voxel p,q,c;
  AdjPxl *fprint=NULL;

  int u,v,ut,vt,iw,iw_p,i,i_p,i1,i2,j,val;
  float w,wt,k;
  uchar l;
  int max=0;


  // image translation
  ut = cxt->width/2; 
  vt = cxt->height/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  img=CreateImage(cxt->width, cxt->height);
  
  if (!shell->body) return(img);

  InitZBuffer(cxt->zbuff);
  
  fprint = AdjPixels(img,cxt->footprint->adj);

  switch(cxt->PAxis) {

  case 'x':
    
    for (p.x = cxt->xi; p.x != cxt->xf; p.x += cxt->dx) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Mzx->tbrow[p.x] + p.z;
        
        if (shell->Mzx->val[i] >= 0) {
          
          if (cxt->dy == 1) {              
            i1 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i2 = shell->Mzx->val[i]-1;            
          } else {            
            i2 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i1 = shell->Mzx->val[i]-1;
	  }
	  i2 += cxt->dy;          
          for (i = i1; i != i2; i += cxt->dy) {
	    
	    // projection
            p.y = shell->pointer[i].y;
	    i_p = shell->pointer[i].i;

	    if (shell->voxel[i_p].visible) {

	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;
	    
	    u = (int)((cxt->R[0][0]*q.x) + (cxt->R[0][1]*q.y) + (cxt->R[0][2]*q.z) + ut);
	    v = (int)((cxt->R[1][0]*q.x) + (cxt->R[1][1]*q.y) + (cxt->R[1][2]*q.z) + vt);
	    
	    iw = u + img->tbrow[v];

	    // splatting
	    for (j=0; j < fprint->n; j++){		
	      iw_p = iw + fprint->dp[j];
	      val = shell->body[i_p].val * cxt->footprint->val[j];
	      if (val > img->val[iw_p]) {
		img->val[iw_p] = val;
		max = MAX(max,val);
		w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		l = shell->voxel[i_p].obj;
                k = cxt->depth - w;
		cxt->zbuff->voxel[iw_p] = i_p;
		cxt->zbuff->object[iw_p] = l;
		if (cxt->zbuff->dist[iw_p] > k)
		  cxt->zbuff->dist[iw_p] = k;
	      }
	    }
	    }
	  }
	}
      }
    break;
    
  case 'y': 
    
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // projection
            p.x = shell->voxel[i].x;
	    i_p = i;

	    if (shell->voxel[i_p].visible) {

	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;
	    
	    u = (int)((cxt->R[0][0]*q.x) + (cxt->R[0][1]*q.y) + (cxt->R[0][2]*q.z) + ut);
	    v = (int)((cxt->R[1][0]*q.x) + (cxt->R[1][1]*q.y) + (cxt->R[1][2]*q.z) + vt);
	    
	    iw = u + img->tbrow[v];
	    // splatting
	    for (j=0; j < fprint->n; j++){		
	      iw_p = iw + fprint->dp[j];
	      val = shell->body[i_p].val * cxt->footprint->val[j];
	      if (val > img->val[iw_p]) {
		img->val[iw_p] = val;
		max = MAX(max,val);
		w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		l = shell->voxel[i_p].obj;
                k = cxt->depth - w;
		cxt->zbuff->voxel[iw_p] = i_p;
		cxt->zbuff->object[iw_p] = l;
		if (cxt->zbuff->dist[iw_p] > k)
		  cxt->zbuff->dist[iw_p] = k;
	      }
	    }
	    }
	  }
	}
      }

    break;

  case 'z': 
    
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) 
      for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {
	    // projection
            p.x = shell->voxel[i].x;
	    i_p = i;

	    if (shell->voxel[i_p].visible) {

	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;
	    
	    u = (int)((cxt->R[0][0]*q.x) + (cxt->R[0][1]*q.y) + (cxt->R[0][2]*q.z) + ut);
	    v = (int)((cxt->R[1][0]*q.x) + (cxt->R[1][1]*q.y) + (cxt->R[1][2]*q.z) + vt);
	    
	    iw = u + img->tbrow[v];
	    // splatting	    
	    for (j=0; j < fprint->n; j++){		
	      iw_p = iw + fprint->dp[j];
	      val = shell->body[i_p].val * cxt->footprint->val[j];
	      if (val > img->val[iw_p]) {
		img->val[iw_p] = val;
		max = MAX(max,val);
		w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		l = shell->voxel[i_p].obj;
                k = cxt->depth - w;
		cxt->zbuff->voxel[iw_p] = i_p;
		cxt->zbuff->object[iw_p] = l;
		if (cxt->zbuff->dist[iw_p] > k)
		  cxt->zbuff->dist[iw_p] = k;
	      }	    
	    }
	    }
	  }	  
	}
      }
    break;
      
  default: 
    Error(MSG1,"MIPShell");
    break;
    
  }			
  DestroyAdjPxl(&fprint);

  if (max > 255) {
    tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
    DestroyImage(&img);
    img = tmp;
  }
  return(img);
}

CImage *CMIPShell(Shell *shell, Context *cxt, Curve *cs) {

  CImage *cimg=NULL;
  Image *img=NULL;

  img = MIPShell(shell,cxt,cs);
  cimg = Colorize(cxt,img);
  DestroyImage(&img);
  return(cimg);
}
  
CImage *GMIPShell(Shell *shell, Context *cxt, Curve *cs) {

  CImage *cimg=NULL;
  Image *img=NULL;

  img = MIPShell(shell,cxt,cs);
  cimg = (CImage*)calloc(1,sizeof(CImage));
  cimg->C[0] = CopyImage(img);
  cimg->C[1] = CopyImage(img);
  cimg->C[2] = CopyImage(img);
  DestroyImage(&img);
  return(cimg);
}

CImage *ICSWShellRendering(Shell *shell,Context *cxt) {


  CImage *cimg=NULL;
  CImage *out=NULL; 
  FBuffer *shear=NULL;
  ZBuffer *zbuff=NULL;
  Voxel p,q,c;
  Pixel d,min,max;
  Vector viewer;
  AdjPxl *fprint=NULL;

  int u,v,ut,vt,uw,vw,is,iw,i,i_p,i1,i2,j,n;
  float w,wt,amb,spec,diff,shading,idist,cos_a,cos_2a,pow,alpha,opac,nopac[256],k; 
  uchar l;

  for(i=0;i<256;i++)
    nopac[i] = (float)i/255.;

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  shear = CreateFBuffer(cxt->isize, cxt->jsize);
  zbuff = CreateZBuffer(cxt->isize, cxt->jsize);
  InitFBuffer(shear,1.0);
  InitZBuffer(cxt->zbuff);
  InitZBuffer(zbuff);

  out=CreateCImage(cxt->width, cxt->height);
  cimg =CreateCImage(cxt->isize, cxt->jsize);
  fprint = AdjPixels(cimg->C[0],cxt->footprint->adj);
    
  viewer.x = -cxt->IR[0][2];
  viewer.y = -cxt->IR[1][2];
  viewer.z = -cxt->IR[2][2];

  max.x = max.y = INT_MIN;
  min.x = min.y = INT_MAX;
    
  switch(cxt->PAxis) {

  case 'x':

    for (p.x = cxt->ki; p.x != cxt->kf; p.x += cxt->dx) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Mzx->tbrow[p.x] + p.z;
        
        if (shell->Mzx->val[i] >= 0) {
          
          if (cxt->dy == 1) {              
            i1 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i2 = shell->Mzx->val[i]-1;            
          } else {            
            i2 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i1 = shell->Mzx->val[i]-1;
	  }
	  i2 += cxt->dy;          
          for (i = i1; i != i2; i += cxt->dy) {
	    // shear
            p.y = shell->pointer[i].y;

	    if (cxt->ymin <= p.y && p.y <= cxt->ymax) {

	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	      
	      u = ROUND (q.y + cxt->Su[p.x]); 
	      v = ROUND (q.z + cxt->Sv[p.x]); 
	    
	      is = u + ut + shear->tbv[v + vt];
	    
	      if (shear->val[is] > 0.05) {
		
		// normal
		i_p = shell->pointer[i].i;
		
		if (shell->voxel[i_p].visible) {		
		
		  l = shell->voxel[i_p].obj;
		  if (l) {

		    n = shell->voxel[i_p].normal;	      
		    cos_a = viewer.x * shell->normaltable[n].x +\
		      viewer.y * shell->normaltable[n].y +\
		      viewer.z * shell->normaltable[n].z;
		  
		    if (cos_a > 0 || shell->body) {
		    
		      // shading
		    
		      w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
                      k = cxt->depth - w;
		      idist = 1.0 - w/(float)cxt->depth;
		    
		      cos_2a = 2*cos_a*cos_a - 1.0;
		    
		      if (cos_2a < 0.) {
			pow = 0.;
			spec = 0.;
		      } else {
			pow = 1.;
			for (j=0; j < cxt->obj[l].ns; j++) 
			  pow = pow * cos_2a;
			spec = cxt->obj[l].spec * pow;
		      }
		    
		      opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		      amb  = cxt->obj[l].amb;
		      diff = cxt->obj[l].diff * cos_a;
		    
		      shading = (amb + idist * (diff + spec));
		    

		      alpha = opac;
		      AccVoxelColor(cimg,cxt,is,shading,shear->val[is]*alpha,l);
		      shear->val[is] *= (1.0-alpha);
		      if (zbuff->voxel[is] == NIL) {
			    zbuff->voxel[is] = i_p;
			    zbuff->object[is] = l;
			    if (zbuff->dist[is] > k)
			      zbuff->dist[is] = k;
		      }
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    break;
    
  case 'y': 
    
    for (p.y = cxt->ki; p.y != cxt->kf; p.y += cxt->dy) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
            p.x = shell->voxel[i].x;

	    if (cxt->xmin <= p.x && p.x <= cxt->xmax) {

	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	    
	      u = ROUND (q.z + cxt->Su[p.y]); 
	      v = ROUND (q.x + cxt->Sv[p.y]); 

	      is = u + ut+ shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {
	      
		// normal
		i_p = i;

		if (shell->voxel[i_p].visible) {
		  l = shell->voxel[i_p].obj;
		  if (l) {
		    n = shell->voxel[i_p].normal;

		    cos_a = viewer.x * shell->normaltable[n].x +\
		      viewer.y * shell->normaltable[n].y +\
		      viewer.z * shell->normaltable[n].z;

		    if (cos_a > 0  || shell->body) {

		      // shading

		      w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
                      k = cxt->depth - w;
		      idist = 1.0 - w/(float)cxt->depth;

		      cos_2a = 2*cos_a*cos_a - 1.0;
		
		      if (cos_2a < 0.) {
			pow = 0.;
			spec = 0.;
		      } else {
			pow = 1.;
			for (j=0; j < cxt->obj[l].ns; j++) 
			  pow = pow * cos_2a;
			spec = cxt->obj[l].spec * pow;
		      }

		      opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		      amb  = cxt->obj[l].amb;
		      diff = cxt->obj[l].diff * cos_a;
		
		      shading =  (amb + idist * (diff + spec));
		
		      // splatting

		      alpha = opac;
		      AccVoxelColor(cimg,cxt,is,shading,shear->val[is]*alpha,l);		      
		      shear->val[is] *= (1.0-alpha);
		      if (zbuff->voxel[is] == NIL) {
			    zbuff->voxel[is] = i_p;
			    zbuff->object[is] = l;
			    if (zbuff->dist[is] > k)
			      zbuff->dist[is] = k;			    
		      }
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    break;

  case 'z': 

    for (p.z = cxt->ki; p.z != cxt->kf; p.z += cxt->dz) 
      for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
            p.x = shell->voxel[i].x;

	    if (cxt->xmin <= p.x && p.x <= cxt->xmax) {

	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z; 

	      u = ROUND (q.x + cxt->Su[p.z]); 
	      v = ROUND (q.y + cxt->Sv[p.z]); 

	      
	      is = u + ut + shear->tbv[v + vt];
	      
	      if (shear->val[is] > 0.05) {
	      
		// normal
		i_p = i;

		if (shell->voxel[i_p].visible) {
		  l = shell->voxel[i_p].obj;
		  if (l) {
		    n = shell->voxel[i_p].normal;

		    cos_a = viewer.x * shell->normaltable[n].x +\
		      viewer.y * shell->normaltable[n].y +\
		      viewer.z * shell->normaltable[n].z;

		    if (cos_a > 0  || shell->body) {

		      // shading

		      w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		      k = cxt->depth - w;
		      idist = 1.0 - w/(float)cxt->depth;

		      cos_2a = 2*cos_a*cos_a - 1.0;
		
		      if (cos_2a < 0.) {
			pow = 0.;
			spec = 0.;
		      } else {
			pow = 1.;
			for (j=0; j < cxt->obj[l].ns; j++) 
			  pow = pow * cos_2a;
			spec = cxt->obj[l].spec * pow;
		      }
		
		      opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac; 
		      amb  = cxt->obj[l].amb;
		      diff = cxt->obj[l].diff * cos_a;
		
		      shading =  (amb + idist * (diff + spec));
		
		      alpha = opac;
		      AccVoxelColor(cimg,cxt,is,shading,shear->val[is]*alpha,l);
		      shear->val[is] *= (1.0-alpha);
		      if (zbuff->voxel[is] == NIL) {
			    zbuff->voxel[is] = i_p;
			    zbuff->object[is] = l;
			    if (zbuff->dist[is] > k)
			      zbuff->dist[is] = k;
		      }
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    break;    
      
  default: 
    Error(MSG1,"SWShellRendering");
    break;
    
  }
  for (v =0;v<cxt->height;v++)
    for (u =0;u<cxt->width;u++) {
      uw = u - d.x;
      vw = v - d.y;
      p.x = cxt->IW[0][0] * uw + cxt->IW[0][1] * vw + ut;
      p.y = cxt->IW[1][0] * uw + cxt->IW[1][1] * vw + vt;
      if (ValidPixel(cimg->C[0],p.x,p.y)) {
	iw = u + cxt->zbuff->tbv[v];
	is = p.x + zbuff->tbv[p.y];
	out->C[0]->val[iw] = cimg->C[0]->val[is];
	out->C[1]->val[iw] = cimg->C[1]->val[is];
	out->C[2]->val[iw] = cimg->C[2]->val[is];
	cxt->zbuff->object[iw] = zbuff->object[is];
	cxt->zbuff->voxel[iw] = zbuff->voxel[is];
	cxt->zbuff->dist[iw] = zbuff->dist[is];
      }
    }
  DestroyCImage(&cimg);
  DestroyFBuffer(&shear);
  DestroyZBuffer(&zbuff);
  DestroyAdjPxl(&fprint);
  return(out);
}


CImage *CSWShellRendering(Shell *shell,Context *cxt) {

  CImage *cimg=NULL;
  FBuffer *shear=NULL,*warp=NULL;
  Voxel p,q,c;
  Pixel d;
  Vector viewer;
  AdjPxl *fprint=NULL;

  int u,v,ut,vt,uw,vw,is,iw,iw_p,i,i_p,i1,i2,j,n;
  float w,wt,amb,spec,diff,shading,idist,cos_a,cos_2a,pow,alpha,opac,nopac[256],k; 
  uchar l;

  for(i=0;i<256;i++)
    nopac[i] = (float)i/255.;

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  shear = CreateFBuffer(cxt->isize, cxt->jsize);
  warp = CreateFBuffer(cxt->width, cxt->height);
  InitFBuffer(shear,1.0);
  InitFBuffer(warp,1.0);
  InitZBuffer(cxt->zbuff);

  cimg=CreateCImage(cxt->width, cxt->height);
  fprint = AdjPixels(cimg->C[0],cxt->footprint->adj);

  viewer.x = -cxt->IR[0][2];
  viewer.y = -cxt->IR[1][2];
  viewer.z = -cxt->IR[2][2];
    
  switch(cxt->PAxis) {

  case 'x':
    
    for (p.x = cxt->xi; p.x != cxt->xf; p.x += cxt->dx) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Mzx->tbrow[p.x] + p.z;
        
        if (shell->Mzx->val[i] >= 0) {
          
          if (cxt->dy == 1) {              
            i1 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i2 = shell->Mzx->val[i]-1;            
          } else {            
            i2 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i1 = shell->Mzx->val[i]-1;
	  }
	  i2 += cxt->dy;          
          for (i = i1; i != i2; i += cxt->dy) {
	    // shear
            p.y = shell->pointer[i].y;

	    if (cxt->ymin <= p.y && p.y <= cxt->ymax) {

	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	      
	      u = (int) (q.y + cxt->Su[p.x]); 
	      v = (int) (q.z + cxt->Sv[p.x]); 
	    
	      is = u + ut + shear->tbv[v + vt];
	    
	      if (shear->val[is] > 0.05) {
		
		// normal
		i_p = shell->pointer[i].i;
		
		if (shell->voxel[i_p].visible) {		
		
		  l = shell->voxel[i_p].obj;
		  if (l) {

		    n = shell->voxel[i_p].normal;	      
		    cos_a = viewer.x * shell->normaltable[n].x +\
		      viewer.y * shell->normaltable[n].y +\
		      viewer.z * shell->normaltable[n].z;
		  
		    if (cos_a > 0) {
		    
		      // shading
		    
		      w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt; k = cxt->depth - w;

		      idist = 1.0 - w/(float)cxt->depth;
		    
		      cos_2a = 2*cos_a*cos_a - 1.0;
		    
		      if (cos_2a < 0.) {
			pow = 0.;
			spec = 0.;
		      } else {
			pow = 1.;
			for (j=0; j < cxt->obj[l].ns; j++) 
			  pow = pow * cos_2a;
			spec = cxt->obj[l].spec * pow;
		      }
		    
		      opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		      amb  = cxt->obj[l].amb;
		      diff = cxt->obj[l].diff * cos_a;
		    
		      shading = (amb + idist * (diff + spec));
		    
		      //warp	      
		      uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		    
		      vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		    
		      iw = warp->tbv[vw + d.y] + uw + d.x;
		    
		      // splatting
		      for (j=0; j < fprint->n; j++){		
			iw_p = iw + fprint->dp[j];
			if (warp->val[iw_p] > .05) {
			  alpha = cxt->footprint->val[j] * opac;
			  AccVoxelColor(cimg,cxt,iw_p,shading,warp->val[iw_p]*alpha,l);
			  warp->val[iw_p] *= (1.0-alpha);
			  if (cxt->zbuff->voxel[iw_p] == NIL) {
			    cxt->zbuff->voxel[iw_p] = i_p;
			    cxt->zbuff->object[iw_p] = l;

			    if (cxt->zbuff->dist[iw_p] > k)
			      cxt->zbuff->dist[iw_p] = k;
			  }
			}
		      }
		      shear->val[is]=warp->val[iw];
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    break;
    
  case 'y': 
    
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
            p.x = shell->voxel[i].x;

	    if (cxt->xmin <= p.x && p.x <= cxt->xmax) {

	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	    
	      u = (int) (q.z + cxt->Su[p.y]); 
	      v = (int) (q.x + cxt->Sv[p.y]); 

	      is = u + ut+ shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {
	      
		// normal
		i_p = i;

		if (shell->voxel[i_p].visible) {
		  l = shell->voxel[i_p].obj;
		  if (l) {
		    n = shell->voxel[i_p].normal;

		    cos_a = viewer.x * shell->normaltable[n].x +\
		      viewer.y * shell->normaltable[n].y +\
		      viewer.z * shell->normaltable[n].z;

		    if (cos_a > 0) {

		      // shading

		      w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt; k = cxt->depth - w;
		      idist = 1.0 - w/(float)cxt->depth;

		      cos_2a = 2*cos_a*cos_a - 1.0;
		
		      if (cos_2a < 0.) {
			pow = 0.;
			spec = 0.;
		      } else {
			pow = 1.;
			for (j=0; j < cxt->obj[l].ns; j++) 
			  pow = pow * cos_2a;
			spec = cxt->obj[l].spec * pow;
		      }

		      opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		      amb  = cxt->obj[l].amb;
		      diff = cxt->obj[l].diff * cos_a;
		
		      shading =  (amb + idist * (diff + spec));
		
		      // warp	      
		      uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		      vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		
		      iw = warp->tbv[vw + d.y] + uw + d.x;
		
		      // splatting
		      for (j=0; j < fprint->n; j++){		
			iw_p = iw + fprint->dp[j];
			if (warp->val[iw_p] > .05) {
			  alpha = cxt->footprint->val[j] * opac;
			  AccVoxelColor(cimg,cxt,iw_p,shading,warp->val[iw_p]*alpha,l);
			  warp->val[iw_p] *= (1.0-alpha);
			  if (cxt->zbuff->voxel[iw_p] == NIL) {
			    cxt->zbuff->voxel[iw_p] = i_p;
			    cxt->zbuff->object[iw_p] = l;
			    if (cxt->zbuff->dist[iw_p] > k)
		              cxt->zbuff->dist[iw_p] = k;
			  }
			}
		      }
		      shear->val[is]=warp->val[iw];
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    break;

  case 'z': 
    
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) 
      for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
            p.x = shell->voxel[i].x;

	    if (cxt->xmin <= p.x && p.x <= cxt->xmax) {

	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z; 

	      u = (int) (q.x + cxt->Su[p.z]); 
	      v = (int) (q.y + cxt->Sv[p.z]); 

	      is = u + ut + shear->tbv[v + vt];
	    
	      if (shear->val[is] > 0.05) {
	      
		// normal
		i_p = i;

		if (shell->voxel[i_p].visible) {
		  l = shell->voxel[i_p].obj;
		  if (l) {
		    n = shell->voxel[i_p].normal;

		    cos_a = viewer.x * shell->normaltable[n].x +\
		      viewer.y * shell->normaltable[n].y +\
		      viewer.z * shell->normaltable[n].z;

		    if (cos_a > 0) {

		      // shading

		      w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt; k = cxt->depth - w;
		      idist = 1.0 - w/(float)cxt->depth;

		      cos_2a = 2*cos_a*cos_a - 1.0;
		
		      if (cos_2a < 0.) {
			pow = 0.;
			spec = 0.;
		      } else {
			pow = 1.;
			for (j=0; j < cxt->obj[l].ns; j++) 
			  pow = pow * cos_2a;
			spec = cxt->obj[l].spec * pow;
		      }
		
		      opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac; 
		      amb  = cxt->obj[l].amb;
		      diff = cxt->obj[l].diff * cos_a;
		
		      shading =  (amb + idist * (diff + spec));
		
		      // warp
		      uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		      vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		
		      iw = warp->tbv[vw + d.y] + uw + d.x;
		
		      // splatting
		
		      for (j=0; j < fprint->n; j++){		
			iw_p = iw + fprint->dp[j];
			if (warp->val[iw_p] > .05) {
			  alpha = cxt->footprint->val[j] * opac;
			  AccVoxelColor(cimg,cxt,iw_p,shading,warp->val[iw_p]*alpha,l);
			  warp->val[iw_p] *= (1.0-alpha);
			  if (cxt->zbuff->voxel[iw_p] == NIL) {
			    cxt->zbuff->voxel[iw_p] = i_p;
			    cxt->zbuff->object[iw_p] = l;
			    if (cxt->zbuff->dist[iw_p] > k)
		              cxt->zbuff->dist[iw_p] = k;
			  }
			}
		      }	      
		      shear->val[is]=warp->val[iw];
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    break;

      
  default: 
    Error(MSG1,"CSWShellRendering");
    break;
    
  }			
  DestroyFBuffer(&shear);
  DestroyFBuffer(&warp);
  DestroyAdjPxl(&fprint);
  return(cimg);
}

void    ShellRenderingDrawCut(Image *img, Shell *shell,Context *cxt, FBuffer *cumopac, char axis)
{

  int ut,vt,u,v,ww,iw,iw_p,i,i_p,i1,i2,j;
  float w,wt,k; 
  uchar l;

  Voxel p,q,c;
  Pixel d;
  AdjPxl *fprint=NULL;
  fprint = AdjPixels(img,cxt->footprint->adj);    

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  switch(axis) {

  case 'x':
    
    p.x = cxt->xi;
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
      i = shell->Mzx->tbrow[p.x] + p.z;
      
      if (shell->Mzx->val[i] >= 0) {
	
	if (cxt->dy == 1) {              
	  i1 = shell->Mzx->val[i];
	  i++;
	  while (shell->Mzx->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Mzx->val[i]-1;            
	} else {            
	  i2 = shell->Mzx->val[i];
	  i++;
	  while (shell->Mzx->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Mzx->val[i]-1;
	}
	i2 += cxt->dy;          
	for (i = i1; i != i2; i += cxt->dy) {
	  
	  p.y = shell->pointer[i].y;

	  if (cxt->ymin <= p.y && p.y <= cxt->ymax) {

	    i_p = shell->pointer[i].i;	    

	    if (shell->voxel[i_p].visible) {

	      q.x = p.x - c.x;	    
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	        	      
	      l = shell->voxel[i_p].obj;

	      if (l) {

		u=(int)(cxt->R[0][0]*q.x + cxt->R[0][1]*q.y + cxt->R[0][2]*q.z);
		v=(int)(cxt->R[1][0]*q.x + cxt->R[1][1]*q.y + cxt->R[1][2]*q.z);
		iw = cxt->zbuff->tbv[v + d.y] + u + d.x;	     	      
		ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
		w = ww + wt;k = cxt->depth - w;
		// splatting
		iw = cxt->zbuff->tbv[v + d.y] + u + d.x;
		for (j=0; j < fprint->n; j++){		
		  iw_p = iw + fprint->dp[j];

		  if (cxt->zbuff->dist[iw_p] > k) {
		    cumopac->val[iw_p] = 0.0;
		    img->val[iw_p] = shell->body[i_p].val;
		    cxt->zbuff->voxel[iw_p] = i_p;
		    cxt->zbuff->object[iw_p] = l;
		    cxt->zbuff->dist[iw_p] = k;
		  }
		}
	      }
	    }
	  }
	}
      }
    }
 
    break;

  case 'y': 
    
    p.y = cxt->yi;
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
      i = shell->Myz->tbrow[p.z] + p.y;
        
      if (shell->Myz->val[i] >= 0) {
          
	if (cxt->dx == 1) {              
	  i1 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Myz->val[i]-1;            
	} else {            
	  i2 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Myz->val[i]-1;
	}
	i2 += cxt->dx;          
	for (i = i1; i != i2; i += cxt->dx) {

	  // shear
	  p.x = shell->voxel[i].x;

	  if (cxt->xmin <= p.x && p.x <= cxt->xmax) {

	    i_p = i;	      

	    if (shell->voxel[i_p].visible) {

	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	    

	      l = shell->voxel[i_p].obj;

	      if (l) {
	      
		u=(int)(cxt->R[0][0]*q.x + cxt->R[0][1]*q.y + cxt->R[0][2]*q.z);
		v=(int)(cxt->R[1][0]*q.x + cxt->R[1][1]*q.y + cxt->R[1][2]*q.z);
		iw = cxt->zbuff->tbv[v + d.y] + u + d.x;	     	      
		ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
		w = ww + wt;k = cxt->depth - w;

		// splatting
		iw = cxt->zbuff->tbv[v + d.y] + u + d.x;
		for (j=0; j < fprint->n; j++){		
		  iw_p = iw + fprint->dp[j];

		  if (cxt->zbuff->dist[iw_p] > k) {
		    cumopac->val[iw_p] = 0.0;
		    img->val[iw_p] = shell->body[i_p].val;
		    cxt->zbuff->voxel[iw_p] = i_p;
		    cxt->zbuff->object[iw_p] = l;
		    cxt->zbuff->dist[iw_p] = k;
		  }
		}
	      }
	    }
	  }
	}
      }
    }
  
    break;

  case 'z':
    
    p.z = cxt->zi;
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
      
      i = shell->Myz->tbrow[p.z] + p.y;
      
      if (shell->Myz->val[i] >= 0) {
	
	if (cxt->dx == 1) {              
	  i1 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Myz->val[i]-1;            
	} else {            
	  i2 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Myz->val[i]-1;
	}
	i2 += cxt->dx;          
	for (i = i1; i != i2; i += cxt->dx) {
	  
	  p.x = shell->voxel[i].x;
	  
	  if (cxt->xmin <= p.x && p.x <= cxt->xmax) {        	   

	    i_p = i;
	    
	    if (shell->voxel[i_p].visible) {
	      
	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z; 	      

	      l = shell->voxel[i_p].obj;
	      
	      if (l) {
		
		u=(int)(cxt->R[0][0]*q.x + cxt->R[0][1]*q.y + cxt->R[0][2]*q.z);
		v=(int)(cxt->R[1][0]*q.x + cxt->R[1][1]*q.y + cxt->R[1][2]*q.z);
		iw = cxt->zbuff->tbv[v + d.y] + u + d.x;	     	      
		ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
		w = ww + wt;k = cxt->depth - w;

		// splatting
		iw = cxt->zbuff->tbv[v + d.y] + u + d.x;
		for (j=0; j < fprint->n; j++){		
		  iw_p = iw + fprint->dp[j];

		  if (cxt->zbuff->dist[iw_p] > k) {
		    cumopac->val[iw_p] = 0.0;
		    img->val[iw_p] = shell->body[i_p].val;
		    cxt->zbuff->voxel[iw_p] = i_p;
		    cxt->zbuff->object[iw_p] = l;
		    cxt->zbuff->dist[iw_p] = k;
		  }
		}
	      }
	    }
	  }
	}
      }
    }
    break;

  default: 
    Error(MSG1,"ShellRenderingDrawCut");
    break;

  }  
  DestroyAdjPxl(&fprint);
}

void    ShellRenderingDrawCuts(Image *img, Shell *shell,Context *cxt, FBuffer *cumopac, char axis)
{
}


void SWShellRenderingDrawCut(Image *img, Shell *shell,Context *cxt, FBuffer *shear, FBuffer *warp, char axis) 
{

  int u,v,ut,vt,uw,vw,ww,is,iw,iw_p,i,i_p,i1,i2,j;
  float w,wt,k; 
  uchar l;

  Voxel p,q,c;
  Pixel d;
  AdjPxl *fprint=NULL;
  fprint = AdjPixels(img,cxt->footprint->adj);    

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  switch(axis) {

  case 'x':
    
    p.x = cxt->xi;
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
      i = shell->Mzx->tbrow[p.x] + p.z;
      
      if (shell->Mzx->val[i] >= 0) {
	
	if (cxt->dy == 1) {              
	  i1 = shell->Mzx->val[i];
	  i++;
	  while (shell->Mzx->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Mzx->val[i]-1;            
	} else {            
	  i2 = shell->Mzx->val[i];
	  i++;
	  while (shell->Mzx->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Mzx->val[i]-1;
	}
	i2 += cxt->dy;          
	for (i = i1; i != i2; i += cxt->dy) {
	  
	  p.y = shell->pointer[i].y;
	  if (cxt->ymin <= p.y && p.y <= cxt->ymax) {

	    i_p = shell->pointer[i].i;

	    if (shell->voxel[i_p].visible) {

	      // shear
	    
	      q.x = p.x - c.x;	    
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	    
	      u = (int) (q.y + cxt->Su[p.x]); 
	      v = (int) (q.z + cxt->Sv[p.x]); 
	    	    
	      is = u + ut+ shear->tbv[v + vt];
	    
	      if (shear->val[is] > 0.05) {
	      
		l = shell->voxel[i_p].obj;

		if (l) {

		  // warp
		  uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		  vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
	      
		  iw = cxt->zbuff->tbv[vw + d.y] + uw + d.x;	     
	      
		  ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
	      
		  w = ww + wt;k = cxt->depth - w;
		  // splatting
		  iw = cxt->zbuff->tbv[vw + d.y] + uw + d.x;		
		  for (j=0; j < fprint->n; j++){		
		    iw_p = iw + fprint->dp[j];
		    if (cxt->zbuff->dist[iw_p] > k) {
		      warp->val[iw_p] = 0.0;
		      img->val[iw_p] = shell->body[i_p].val;
		      cxt->zbuff->voxel[iw_p] = i_p;
		      cxt->zbuff->object[iw_p] = l;
		      cxt->zbuff->dist[iw_p] = k;
		    }
		  }
		  shear->val[is]=warp->val[iw];
		}      
	      }
	    }
	  }
	}
      }
    }
    break;

  case 'y': 
    
    p.y = cxt->yi;
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
      i = shell->Myz->tbrow[p.z] + p.y;
        
      if (shell->Myz->val[i] >= 0) {
          
	if (cxt->dx == 1) {              
	  i1 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Myz->val[i]-1;            
	} else {            
	  i2 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Myz->val[i]-1;
	}
	i2 += cxt->dx;          
	for (i = i1; i != i2; i += cxt->dx) {

	  p.x = shell->voxel[i].x;

	  if (cxt->xmin <= p.x && p.x <= cxt->xmax) {

	    i_p = i;
	  
	    if (shell->voxel[i_p].visible) {

	      // shear	    
	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	    
	      u = (int) (q.z + cxt->Su[p.y]); 
	      v = (int) (q.x + cxt->Sv[p.y]); 

	      is = u + ut+ shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {

		l = shell->voxel[i_p].obj;

		if (l) {

		  // warp
		  uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		  vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
	       
		  iw = cxt->zbuff->tbv[vw + d.y] + uw + d.x;	     
	       
		  ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
	       
		  w = ww + wt;k = cxt->depth - w;

		  // splatting
		  iw = cxt->zbuff->tbv[vw + d.y] + uw + d.x;		
		  for (j=0; j < fprint->n; j++){		
		    iw_p = iw + fprint->dp[j];
		    if (cxt->zbuff->dist[iw_p] > k) {
		      warp->val[iw_p] = 0.0;
		      img->val[iw_p] = shell->body[i_p].val;
		      cxt->zbuff->voxel[iw_p] = i_p;
		      cxt->zbuff->object[iw_p] = l;		      
		      cxt->zbuff->dist[iw_p] = k;
		    }
		  }
		  shear->val[is]=warp->val[iw];
		}      
	      }
	    }
	  }
	}
      }
    }
    break;

  case 'z':
   
    p.z = cxt->zi;
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
      i = shell->Myz->tbrow[p.z] + p.y;
      
      if (shell->Myz->val[i] >= 0) {
	
	if (cxt->dx == 1) {              
	  i1 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Myz->val[i]-1;            
	} else {            
	  i2 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Myz->val[i]-1;
	}
	i2 += cxt->dx;          
	for (i = i1; i != i2; i += cxt->dx) {
	  
	  p.x = shell->voxel[i].x;

	  if (cxt->xmin <= p.x && p.x <= cxt->xmax) {        	   

	    i_p = i;
	  
	    if (shell->voxel[i_p].visible) {

	      // shear
	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z; 

	      u = (int) (q.x + cxt->Su[p.z]); 
	      v = (int) (q.y + cxt->Sv[p.z]); 

	      is = u + ut+ shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {
	      

		l = shell->voxel[i_p].obj;

		if (l) {

		  // warp
		  uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		  vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
	      
		  iw = cxt->zbuff->tbv[vw + d.y] + uw + d.x;	     
	      
		  ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
	      
		  w = ww + wt;k = cxt->depth - w;
		  // splatting
		  iw = cxt->zbuff->tbv[vw + d.y] + uw + d.x;		
		  for (j=0; j < fprint->n; j++){		
		    iw_p = iw + fprint->dp[j];
		    if (cxt->zbuff->dist[iw_p] > k) {
		      warp->val[iw_p] = 0.0;
		      img->val[iw_p] = shell->body[i_p].val;
		      cxt->zbuff->voxel[iw_p] = i_p;
		      cxt->zbuff->object[iw_p] = l;
		      cxt->zbuff->dist[iw_p] = k;
		    }
		  }
		  shear->val[is]=warp->val[iw];
		}      
	      }
	    }
	  }
	}
      }
    }
    break;

  default: 
    Error(MSG1,"CSWShellRenderingDrawCut");
    break;

  }  
  DestroyAdjPxl(&fprint);
}

void ShellRenderingDrawCutPlane(Image *img, Shell *shell,Context *cxt, FBuffer *cumopac) 
{
  int i,j,n,u,v,ut,vt,l;
  float w,wt;
  Voxel s,c;
  Pixel p;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  ut = cxt->width/2;
  vt = cxt->height/2;
  wt = (float)cxt->depth/2.;

  n = cxt->width * cxt->height;
  for (p.y=0;p.y<cxt->height;p.y++) {
    for (p.x=0;p.x<cxt->width;p.x++) {
      u = p.x - ut;
      v = p.y - vt;      
      i = cxt->zbuff->tbv[p.y] + p.x;
      w = wt - cxt->zbuff->dist[i];
      s.x = (int) (cxt->IR[0][0] * u + cxt->IR[0][1] * v + cxt->IR[0][2] * w) + c.x;
      s.y = (int) (cxt->IR[1][0] * u + cxt->IR[1][1] * v + cxt->IR[1][2] * w) + c.y;
      s.z = (int) (cxt->IR[2][0] * u + cxt->IR[2][1] * v + cxt->IR[2][2] * w) + c.z;
      if (cxt->xmin <= s.x && s.x <= cxt->xmax && \
	  cxt->zmin <= s.z && s.z <= cxt->zmax && \
	  cxt->ymin <= s.y && s.y <= cxt->ymax) {
	j = VoxelExist(shell,&s);
	if (j>0) {
	  l = shell->voxel[j].obj;
	  if (l) {
	    img->val[i] = shell->body[j].val;
	    cxt->zbuff->voxel[i] = j;
	    cxt->zbuff->object[i] = l;
	    cumopac->val[i] = 0.0;
	  }
	}
      }
    }
  }
}

void    ShellRenderingDrawSceneCutPlane(Image *img, Shell *shell,Context *cxt, FBuffer *cumopac) {

  int i,j,n,u,v,ut,vt,l;
  float w,wt;
  Voxel s,c;
  Pixel p;
  Image *label=NULL,*tmp=NULL;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  ut = cxt->width/2;
  vt = cxt->height/2;
  wt = (float)cxt->depth/2.;

  tmp = CreateImage(cxt->width,cxt->height);

  n = cxt->width * cxt->height;
  for (p.y=0;p.y<cxt->height;p.y++) {
    for (p.x=0;p.x<cxt->width;p.x++) {
      u = p.x - ut;
      v = p.y - vt;      
      i = cxt->zbuff->tbv[p.y] + p.x;
      w = wt - cxt->zbuff->dist[i];
      s.x = (int) (cxt->IR[0][0] * u + cxt->IR[0][1] * v + cxt->IR[0][2] * w) + c.x;
      s.y = (int) (cxt->IR[1][0] * u + cxt->IR[1][1] * v + cxt->IR[1][2] * w) + c.y;
      s.z = (int) (cxt->IR[2][0] * u + cxt->IR[2][1] * v + cxt->IR[2][2] * w) + c.z;

      if (cxt->xmin <= s.x && s.x <= cxt->xmax && \
	  cxt->zmin <= s.z && s.z <= cxt->zmax && \
	  cxt->ymin <= s.y && s.y <= cxt->ymax) {

	j = shell->scn->tbz[s.z] + shell->scn->tby[s.y] + s.x;
	l = shell->scn->data[j];
	if (l) {
	  img->val[i] = l;
	  cxt->zbuff->voxel[i] = j;
	}
      }
      
      j = VoxelExist(shell,&s);
      if (j>0) {
	l = shell->voxel[j].obj;
	if (l && shell->voxel[j].visible) {
	  tmp->val[i] = shell->voxel[j].obj;
	}
      }      
    }
  }
  label = FillSlice(tmp);
  DestroyImage(&tmp);
  for (i=0;i<n;i++) {
    if (img->val[i]) {
      cxt->zbuff->object[i] = label->val[i];
    }
    if (!label->val[i]) {
      cxt->zbuff->voxel[i] = NIL;
    } else {
      cumopac->val[i] = 0.0;
    }

      
  }
  DestroyImage(&label);
}


Image *ShellRenderingDrawObjectCut(Shell *shell,Context *cxt,char axis) 
{

  int ut,vt,u,v,iw,iw_p,i,i_p,i1,i2,j;
  int xi,yi,zi,xf,yf,zf;
  float w,wt; 
  uchar l;
  Image *img=NULL,*label=NULL;
  Voxel p,q,c;
  Pixel d;
  AdjPxl *fprint=NULL;


  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  if (cxt->dx > 0) {xi = 0;xf = cxt->xsize-1;} else {xf = 0;xi = cxt->xsize-1;}
  if (cxt->dy > 0) {yi = 0;yf = cxt->ysize-1;} else {yf = 0;yi = cxt->ysize-1;}
  if (cxt->dz > 0) {zi = 0;zf = cxt->zsize-1;} else {zf = 0;zi = cxt->zsize-1;}

  xf += cxt->dx;
  yf += cxt->dy;
  zf += cxt->dz;

  img = CreateImage(cxt->width,cxt->height);
  fprint = AdjPixels(img,cxt->footprint->adj);    
  
  switch(axis) {

  case 'x':
    
    p.x = cxt->xi;
    for (p.z = zi; p.z != zf; p.z += cxt->dz) {
      i = shell->Mzx->tbrow[p.x] + p.z;
      
      if (shell->Mzx->val[i] >= 0) {
	
	if (cxt->dy == 1) {              
	  i1 = shell->Mzx->val[i];
	  i++;
	  while (shell->Mzx->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Mzx->val[i]-1;            
	} else {            
	  i2 = shell->Mzx->val[i];
	  i++;
	  while (shell->Mzx->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Mzx->val[i]-1;
	}
	i2 += cxt->dy;          
	for (i = i1; i != i2; i += cxt->dy) {
	  
	  p.y = shell->pointer[i].y;

	  i_p = shell->pointer[i].i;	    

	  if (shell->voxel[i_p].visible) {
	    
	    q.x = p.x - c.x;	    
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;
	    
	    l = shell->voxel[i_p].obj;
	    
	    if (l) {
	      
	      u=(int)(cxt->R[0][0]*q.x + cxt->R[0][1]*q.y + cxt->R[0][2]*q.z);
	      v=(int)(cxt->R[1][0]*q.x + cxt->R[1][1]*q.y + cxt->R[1][2]*q.z);
	      w=(cxt->R[1][0]*q.x + cxt->R[1][1]*q.y + cxt->R[1][2]*q.z);
	      iw = cxt->zbuff->tbv[v + d.y] + u + d.x;	     	      
	      // splatting
	      for (j=0; j < fprint->n; j++){		
		iw_p = iw + fprint->dp[j];
		if (cxt->zbuff->dist[iw_p] > cxt->depth - w) {
		  img->val[iw_p] = l;
		}
	      }
	    }
	  }
	}
      }
    }
    break;

  case 'y': 
    
    p.y = cxt->yi;
    for (p.z = zi; p.z != zf; p.z += cxt->dz) {
      i = shell->Myz->tbrow[p.z] + p.y;
        
      if (shell->Myz->val[i] >= 0) {
          
	if (cxt->dx == 1) {              
	  i1 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Myz->val[i]-1;            
	} else {            
	  i2 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Myz->val[i]-1;
	}
	i2 += cxt->dx;          
	for (i = i1; i != i2; i += cxt->dx) {

	  // shear
	  p.x = shell->voxel[i].x;

	  i_p = i;	      
	  
	  if (shell->voxel[i_p].visible) {
	    
	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;
	    	    
	    l = shell->voxel[i_p].obj;
	    
	    if (l) {
	      
	      u=(int)(cxt->R[0][0]*q.x + cxt->R[0][1]*q.y + cxt->R[0][2]*q.z);
	      v=(int)(cxt->R[1][0]*q.x + cxt->R[1][1]*q.y + cxt->R[1][2]*q.z);
	      w=(cxt->R[1][0]*q.x + cxt->R[1][1]*q.y + cxt->R[1][2]*q.z);
	      iw = cxt->zbuff->tbv[v + d.y] + u + d.x;
	      
	      // splatting
	      for (j=0; j < fprint->n; j++){		
		iw_p = iw + fprint->dp[j];
		if (cxt->zbuff->dist[iw_p] > cxt->depth - w) {
		  img->val[iw_p] = l;
		}
	      }
	    }
	  }
	}
      }
    }
  
    break;

  case 'z':
    
    p.z = cxt->zi;
    for (p.y = yi; p.y != yf; p.y += cxt->dy) {
      
      i = shell->Myz->tbrow[p.z] + p.y;
      
      if (shell->Myz->val[i] >= 0) {
	
	if (cxt->dx == 1) {              
	  i1 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Myz->val[i]-1;            
	} else {            
	  i2 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Myz->val[i]-1;
	}
	i2 += cxt->dx;          
	for (i = i1; i != i2; i += cxt->dx) {
	  
	  p.x = shell->voxel[i].x;
	  
	  i_p = i;
	  
	  if (shell->voxel[i_p].visible) {
	    
	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z; 	      
	    
	    l = shell->voxel[i_p].obj;
	    
	    if (l) {
	      
	      u=(int)(cxt->R[0][0]*q.x + cxt->R[0][1]*q.y + cxt->R[0][2]*q.z);
	      v=(int)(cxt->R[1][0]*q.x + cxt->R[1][1]*q.y + cxt->R[1][2]*q.z);
	      w=(cxt->R[1][0]*q.x + cxt->R[1][1]*q.y + cxt->R[1][2]*q.z);
	      iw = cxt->zbuff->tbv[v + d.y] + u + d.x;
	      // splatting
	      
	      for (j=0; j < fprint->n; j++){		
		iw_p = iw + fprint->dp[j];
		if (cxt->zbuff->dist[iw_p] > cxt->depth - w) {
		  img->val[iw_p] = l;
		}
	      }
	    }
	  }
	}
      }
    }
    break;

  default: 
    Error(MSG1,"ShellRenderingDrawCut");
    break;

  }  
  label = FillSlice(img);
  DestroyImage(&img);
  DestroyAdjPxl(&fprint);
  return(label);
}

void ISWShellRenderingDrawSceneCut(Image *img, Shell *shell,Context *cxt, FBuffer *shear, FBuffer *warp, char axis) 
{

  int u,v,ut,vt,uw,vw,i,j,k;
  float wt,Su,Sv; 
  Image *lx=NULL,*ly=NULL,*lz=NULL;
  Voxel p,q,c;
  Pixel d;

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  lx = ShellRenderingDrawObjectCut(shell,cxt,'x');
  ly = ShellRenderingDrawObjectCut(shell,cxt,'y');
  lz = ShellRenderingDrawObjectCut(shell,cxt,'z');

  switch(cxt->PAxis) {

  case 'x':

    Su = fabs(cxt->ISu[cxt->ki]);
    Sv = fabs(cxt->ISv[cxt->ki]);

    for (v=0; v < cxt->zbuff->vsize; v++)
      for (u=0; u < cxt->zbuff->usize; u++){
	j   = u+cxt->zbuff->tbv[v];
	uw = u - d.x;
	vw = v - d.y;
	q.x = uw*cxt->IW[0][0] + vw*cxt->IW[0][1] + c.y;
	q.y = uw*cxt->IW[1][0] + vw*cxt->IW[1][1] + c.z;	
	for (k=cxt->ki; k != cxt->kf; k += cxt->dk) {
	  p.y = ROUND(q.x + cxt->ISu[k]); 
	  p.z = ROUND(q.y + cxt->ISv[k]);
	  p.x = k;	    
	  if (ValidVoxel(shell->scn,p.x,p.y,p.z)) {
	    i   = p.x + shell->scn->tby[p.y] + shell->scn->tbz[p.z];
	    if (lz->val[j]) {
	      if ((p.x >= cxt->xmin)&&(p.x < cxt->xmax)&&
		  (p.y >= cxt->ymin)&&(p.y < cxt->ymax)&&
		  (p.z == cxt->zi)){
		img->val[j] = shell->scn->data[i];
		cxt->zbuff->object[j] = (uchar)lz->val[j];
		cxt->zbuff->voxel[j] = i;
		warp->val[j] = 0.0;
	      }
	    }
	    if (lx->val[j]) {
	      if ((p.z >= cxt->zmin)&&(p.z < cxt->zmax)&&
		  (p.y >= cxt->ymin)&&(p.y < cxt->ymax)&&
		  (p.x == cxt->xi)){
		img->val[j] = shell->scn->data[i];
		cxt->zbuff->object[j] = (uchar)lx->val[j];
		cxt->zbuff->voxel[j] = i;
		warp->val[j] = 0.0;
	      }
	    }
	    if (ly->val[j]) {
	      if ((p.z >= cxt->zmin)&&(p.z < cxt->zmax)&&
		  (p.x >= cxt->xmin)&&(p.x < cxt->xmax)&&
		  (p.y == cxt->yi)){
		img->val[j] = shell->scn->data[i];
		cxt->zbuff->object[j] = (uchar)ly->val[j];
		cxt->zbuff->voxel[j] = i;
		warp->val[j] = 0.0;
	      }
	    }
	  }
	}
      }
    break;

  case 'y': 

    Su = fabs(cxt->ISu[cxt->ki]);
    Sv = fabs(cxt->ISv[cxt->ki]);

    for (v=0; v < cxt->zbuff->vsize; v++)
      for (u=0; u < cxt->zbuff->usize; u++){
	j   = u+cxt->zbuff->tbv[v];
	uw = u - d.x;
	vw = v - d.y;
	q.x = uw*cxt->IW[0][0] + vw*cxt->IW[0][1] + c.z;
	q.y = uw*cxt->IW[1][0] + vw*cxt->IW[1][1] + c.x;
	for (k=cxt->ki; k != cxt->kf; k += cxt->dk) {
	  p.z = ROUND(q.x + cxt->ISu[k]); 
	  p.x = ROUND(q.y + cxt->ISv[k]); 
	  p.y = k;
	  if (ValidVoxel(shell->scn,p.x,p.y,p.z)) {
	    i   = p.x + shell->scn->tby[p.y] + shell->scn->tbz[p.z];
	    if (lz->val[j]) {
	      if ((p.x >= cxt->xmin)&&(p.x < cxt->xmax)&&
		  (p.y >= cxt->ymin)&&(p.y < cxt->ymax)&&
		  (p.z == cxt->zi)){
		img->val[j] = shell->scn->data[i];
		cxt->zbuff->object[j] = (uchar)lz->val[j];
		cxt->zbuff->voxel[j] = i;
		warp->val[j] = 0.0;
	      }
	    }
	    if (lx->val[j]) {
	      if ((p.z >= cxt->zmin)&&(p.z < cxt->zmax)&&
		  (p.y >= cxt->ymin)&&(p.y < cxt->ymax)&&
		  (p.x == cxt->xi)){
		img->val[j] = shell->scn->data[i];
		cxt->zbuff->object[j] = (uchar)lx->val[j];
		cxt->zbuff->voxel[j] = i;
		warp->val[j] = 0.0;	       
	      }
	    }
	    if (ly->val[j]) {
	      if ((p.z >= cxt->zmin)&&(p.z < cxt->zmax)&&
		  (p.x >= cxt->xmin)&&(p.x < cxt->xmax)&&
		  (p.y == cxt->yi)){
		  img->val[j] = shell->scn->data[i];
		  cxt->zbuff->object[j] = (uchar)ly->val[j];
		  cxt->zbuff->voxel[j] = i;
		  warp->val[j] = 0.0;
	      }
	    }
	  }
	}
      }
    break;

  case 'z':

    Su = fabs(cxt->ISu[cxt->ki]);
    Sv = fabs(cxt->ISv[cxt->ki]);

    for (v=0; v < cxt->zbuff->vsize; v++)
      for (u=0; u < cxt->zbuff->usize; u++){
	j   = u+cxt->zbuff->tbv[v];
	uw = u - d.x;
	vw = v - d.y;
	q.x = uw*cxt->IW[0][0] + vw*cxt->IW[0][1] + c.x;
	q.y = uw*cxt->IW[1][0] + vw*cxt->IW[1][1] + c.y;	
	for (k=cxt->ki; k != cxt->kf; k += cxt->dk) {
	  p.x = ROUND(q.x + cxt->ISu[k]); 
	  p.y = ROUND(q.y + cxt->ISv[k]); 
	  p.z = k;
	  if (ValidVoxel(shell->scn,p.x,p.y,p.z)) {
	    i   = p.x + shell->scn->tby[p.y] + shell->scn->tbz[p.z];
	    if (lz->val[j]) {
	      if ((p.x >= cxt->xmin)&&(p.x < cxt->xmax)&&\
		  (p.y >= cxt->ymin)&&(p.y < cxt->ymax)&&\
		  (p.z == cxt->zi)){
		img->val[j] = shell->scn->data[i];
		cxt->zbuff->object[j] = (uchar)lz->val[j];
		cxt->zbuff->voxel[j] = i;
		warp->val[j] = 0.0;
	      } 
	    }
	    if (lx->val[j]) {
	      if ((p.z >= cxt->zmin)&&(p.z < cxt->zmax)&&\
		  (p.y >= cxt->ymin)&&(p.y < cxt->ymax)&&\
		  (p.x == cxt->xi)){
		img->val[j] = shell->scn->data[i];
 		cxt->zbuff->object[j] = (uchar)lx->val[j];
		cxt->zbuff->voxel[j] = i;
		warp->val[j] = 0.0;
	      }
	    }
	    if (ly->val[j]) {
	      if ((p.z >= cxt->zmin)&&(p.z < cxt->zmax)&&\
		  (p.x >= cxt->xmin)&&(p.x < cxt->xmax)&&\
		  (p.y == cxt->yi)){
		img->val[j] = shell->scn->data[i];
		cxt->zbuff->object[j] = (uchar)ly->val[j];
		cxt->zbuff->voxel[j] = i;
		warp->val[j] = 0.0;
	      }
	    }
	  }
	}
      }    
    break;
    
  default: 
    Error(MSG1,"CSWShellRenderingDrawSceneCut");
    break;

  }
  DestroyImage(&lx);
  DestroyImage(&ly);
  DestroyImage(&lz);
}

void RaycastSceneCut(Image *img, Scene *scn, Context *cxt, FBuffer *cumopac)
{
  int i,j,u,v,u1,v1,k1,d;
  int umax,vmax,umin,vmin;
  Point p,p0;
  Vector n;
  float dx=0.,dy=0.,dz=0.,advance_factor,aux;
  Voxel w,w1;
  bool in;

  k1  = -cxt->zbuff->usize/2;
  n.x = cxt->IR[0][2];
  n.y = cxt->IR[1][2];
  n.z = cxt->IR[2][2];
  switch (cxt->PAxis) {
  case 'x':
    if (n.x > 0) 
      dx = 1.;
    else
      dx = -1.;
    dy = dx*(n.y/n.x); /* correcao */
    dz = dx*(n.z/n.x);
    break;
  case 'y':
    if (n.y > 0) 
      dy = 1.;
    else
      dy = -1.;
    dx = dy*(n.x/n.y);
    dz = dy*(n.z/n.y);
    break;
  case 'z':
    if (n.z > 0) 
      dz = 1.;
    else
      dz = -1.;
    dx = dz*(n.x/n.z);
    dy = dz*(n.y/n.z);
    break;
  }

  
  umax = vmax = 0;
  umin =  cxt->width -1;
  vmin =  cxt->height -1;
  for (i=0;i<8;i++) {
    u = (int)(cxt->R[0][0]*cxt->fr->vert[i].x + \
	      cxt->R[0][1]*cxt->fr->vert[i].y + \
	      cxt->R[0][2]*cxt->fr->vert[i].z + \
	      cxt->zbuff->usize/2);
    v = (int)(cxt->R[1][0]*cxt->fr->vert[i].x + \
	      cxt->R[1][1]*cxt->fr->vert[i].y + \
	      cxt->R[1][2]*cxt->fr->vert[i].z + \
	      cxt->zbuff->usize/2);
    
    umax = MAX(u,umax);
    umin = MIN(u,umin);
    vmax = MAX(v,vmax);
    vmin = MIN(v,vmin);
    
  }
  
  for (v=vmin; v <= vmax; v++)
    for (u=umin; u <= umax; u++){
      j   = u+cxt->zbuff->tbv[v];
      cxt->zbuff->object[j] = 0;
      cxt->zbuff->voxel[j]  = NIL;
      cxt->zbuff->dist[j]   = cxt->zbuff->usize;
      u1 = u - cxt->zbuff->usize/2;
      v1 = v - cxt->zbuff->vsize/2;     
      p.x = u1*cxt->IR[0][0] + v1*cxt->IR[0][1] + k1*cxt->IR[0][2]; 
      p.y = u1*cxt->IR[1][0] + v1*cxt->IR[1][1] + k1*cxt->IR[1][2];
      p.z = u1*cxt->IR[2][0] + v1*cxt->IR[2][1] + k1*cxt->IR[2][2];

      p0.x = p.x;
      p0.y = p.y;
      p0.z = p.z;
      /* p0 pertence ao view plane */

      /* procura-se p, o ponto de intersec�ao com a cena */
      advance_factor = 0.;

      if ((n.x > Epsilon) || (n.x < -Epsilon)) {
	if (p0.x > cxt->xsize/2 - 1) {
	  p.x = cxt->xsize/2 - 1; 
	  advance_factor  = (p.x - p0.x)/n.x;
	  }
	else
	  if (p0.x < -cxt->xsize/2) {
	    p.x = -cxt->xsize/2;
	    advance_factor  = (p.x - p0.x)/n.x;
	  }
      } else {
	if ((p0.x > cxt->xsize/2-1)||(p0.x < -cxt->xsize/2))
	  goto caifora;
      } 

      if ((n.y > Epsilon) || (n.y < -Epsilon)) {
	if (p0.y > cxt->ysize/2 - 1) {
	  p.y = cxt->ysize/2 - 1;
	  aux = (p.y - p0.y)/n.y;
	  if (advance_factor < aux)
	    advance_factor = aux;
	}
	else
	  if (p0.y < -cxt->ysize/2) {
	    p.y = -cxt->ysize/2;
	    aux = (p.y - p0.y)/n.y;	    
	    if (advance_factor < aux)
	      advance_factor = aux;
	  }
      } else {
	if ((p0.y > cxt->ysize/2-1)||(p0.y < -cxt->ysize/2))
	  goto caifora;
      } 
      
      if ((n.z > Epsilon) || (n.z < -Epsilon)) {
      	if (p0.z > cxt->zsize/2 - 1) {
	  p.z = cxt->zsize/2 - 1; /* cuidado com dim. impares */
	  aux = (p.z - p0.z)/n.z;
	  if (advance_factor < aux )
	    advance_factor = aux;
	}
	else
	  if (p0.z < -cxt->zsize/2) {
	    p.z = -cxt->zsize/2; 
	    aux = (p.z - p0.z)/n.z;   
	    if (advance_factor < aux)
	      advance_factor = aux;
	  }
      } else {
	if ((p0.z > cxt->zsize/2-1)||(p0.z < -cxt->zsize/2))
	  goto caifora;
      } 

      p.x = p0.x + advance_factor * n.x;
      p.y = p0.y + advance_factor * n.y;
      p.z = p0.z + advance_factor * n.z;

      w1.x = ROUND(p.x); /* o (ROUND) seria melhor que o (int) */
      w1.y = ROUND(p.y);
      w1.z = ROUND(p.z);
      w.x  = w1.x + cxt->xsize/2;
      w.y  = w1.y + cxt->ysize/2;
      w.z  = w1.z + cxt->zsize/2;

      in = 1;
      d =0;
      while (in) {
	if  ((w.x >= cxt->xmin)&&(w.x <= cxt->xmax)&& 
	     (w.y >= cxt->ymin)&&(w.y <= cxt->ymax)&& 
	     (w.z >= cxt->zmin)&&(w.z <= cxt->zmax)) {
		  
	  i = w.x + scn->tby[w.y] + scn->tbz[w.z];

	  cxt->zbuff->dist[j] = sqrt((w1.x-p0.x)*(w1.x-p0.x) +
				     (w1.y-p0.y)*(w1.y-p0.y) +
				     (w1.z-p0.z)*(w1.z-p0.z));
	  cxt->zbuff->voxel[j] = i;
	  img->val[j] = scn->data[i];
	  cumopac->val[j] = 0.0;
	  in =0;
	  break;
	} else {
	  p.x += dx; 
	  p.y += dy;
	  p.z += dz;
	  w1.x = (int)p.x;
	  w1.y = (int)p.y;
	  w1.z = (int)p.z;
	  w.x  = w1.x + cxt->xsize/2;
	  w.y  = w1.y + cxt->ysize/2;
	  w.z  = w1.z + cxt->zsize/2;
	  d++;
	  if (d >= cxt->depth)
	    in =0;	    
	}
      }
    caifora:
      ;
    } /* end for u */
} 

void SWShellRenderingDrawSceneCut(Image *img, Shell *shell,Context *cxt, FBuffer *shear, FBuffer *warp, char axis) 
{

  int u,v,ut,vt,uw,vw,ww,is,iw,iw_p,i,i_p,i1,i2,j,index;
  float w,wt; 
  uchar l;

  Voxel p,q,c;
  Pixel d,e;
  AdjPxl *fprint=NULL;
  fprint = AdjPixels(img,cxt->footprint->adj);    

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  switch(axis) {

  case 'x':
    
    p.x = cxt->xi;
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
      i = shell->Mzx->tbrow[p.x] + p.z;
      
      if (shell->Mzx->val[i] >= 0) {
	
	if (cxt->dy == 1) {              
	  i1 = shell->Mzx->val[i];
	  i++;
	  while (shell->Mzx->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Mzx->val[i]-1;            
	} else {            
	  i2 = shell->Mzx->val[i];
	  i++;
	  while (shell->Mzx->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Mzx->val[i]-1;
	}
	i = i1;
	i_p = shell->pointer[i].i;
	e.y = shell->pointer[i2].y + cxt->dy;
	for (p.y = shell->pointer[i1].y; p.y != e.y; p.y += cxt->dy) {
	  index = shell->scn->tbz[p.z] + shell->scn->tby[p.y] + p.x;	  
	  if (cxt->ymin <= p.y && p.y < cxt->ymax) {
	    if (shell->scn->data[index]) {
	      i_p = shell->pointer[i].i;
	      if (shell->pointer[i].y == p.y)
		i += cxt->dy;
	    }
	    if (shell->voxel[i_p].visible) {

	      // shear
	    
	      q.x = p.x - c.x;	    
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	    
	      u = (int) (q.y + cxt->Su[p.x]); 
	      v = (int) (q.z + cxt->Sv[p.x]); 
	    	    
	      is = u + ut+ shear->tbv[v + vt];
	    
	      if (shear->val[is] > 0.05) {
	      
		l = shell->voxel[i_p].obj;

		if (l) {

		  // warp
		  uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		  vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
	      
		  iw = cxt->zbuff->tbv[vw + d.y] + uw + d.x;	     
	      
		  ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
	      
		  w = ww + wt;
		  // splatting
		  iw = cxt->zbuff->tbv[vw + d.y] + uw + d.x;		
		  for (j=0; j < fprint->n; j++){		
		    iw_p = iw + fprint->dp[j];
		    if (cxt->zbuff->dist[iw_p] > cxt->depth - w) {
		      warp->val[iw_p] = 0.0;		      
		      img->val[iw_p] = shell->scn->data[index];
		      cxt->zbuff->voxel[iw_p] = i_p;
		      cxt->zbuff->object[iw_p] = l;
		      cxt->zbuff->dist[iw_p] = cxt->depth - w;
		    }
		  }
		  shear->val[is]=warp->val[iw];
		}      
     	      }
	    }
	  }
	}
      }
    }
    break;

  case 'y': 
    
    p.y = cxt->yi;
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
      i = shell->Myz->tbrow[p.z] + p.y;
        
      if (shell->Myz->val[i] >= 0) {
          
	if (cxt->dx == 1) {              
	  i1 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Myz->val[i]-1;            
	} else {            
	  i2 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Myz->val[i]-1;
	}
	i = i1;
	i_p = i;
	e.x = shell->voxel[i2].x + cxt->dx;
	for (p.x = shell->voxel[i1].x; p.x != e.x; p.x += cxt->dx) {
	  index = shell->scn->tbz[p.z] + shell->scn->tby[p.y] + p.x;	  
	  if (cxt->xmin <= p.x && p.x < cxt->xmax) {
	    if (shell->scn->data[index]) {
	      i_p = i;
	      if (shell->voxel[i].x == p.x)
		i += cxt->dx;
	    }
	    if (shell->voxel[i_p].visible) {

	      // shear	    
	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	    
	      u = (int) (q.z + cxt->Su[p.y]); 
	      v = (int) (q.x + cxt->Sv[p.y]); 

	      is = u + ut+ shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {

		l = shell->voxel[i_p].obj;

		if (l) {

		  // warp
		  uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		  vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
	       
		  iw = cxt->zbuff->tbv[vw + d.y] + uw + d.x;	     
	       
		  ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
	       
		  w = ww + wt;

		  // splatting
		  iw = cxt->zbuff->tbv[vw + d.y] + uw + d.x;		
		  for (j=0; j < fprint->n; j++){		
		    iw_p = iw + fprint->dp[j];
		    
		    if (cxt->zbuff->dist[iw_p] > cxt->depth - w) {
		      warp->val[iw_p] = 0.0;		      
		      img->val[iw_p] = shell->scn->data[index];
		      cxt->zbuff->voxel[iw_p] = i_p;
		      cxt->zbuff->object[iw_p] = l;		      
		      cxt->zbuff->dist[iw_p] = cxt->depth - w;
		    }
		  }
		  shear->val[is]=warp->val[iw];
		}      
	      }
	    }
	  }
	}
      }
    }
    break;

  case 'z':
   
    p.z = cxt->zi;
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
      i = shell->Myz->tbrow[p.z] + p.y;
      
      if (shell->Myz->val[i] >= 0) {
	
	if (cxt->dx == 1) {              
	  i1 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Myz->val[i]-1;            
	} else {            
	  i2 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Myz->val[i]-1;
	}
	i = i1;
	i_p = i;
	e.x = shell->voxel[i2].x + cxt->dx;
	for (p.x = shell->voxel[i1].x; p.x != e.x; p.x += cxt->dx) {
	  index = shell->scn->tbz[p.z] + shell->scn->tby[p.y] + p.x;	  
	  if (cxt->xmin <= p.x && p.x < cxt->xmax) {
	    if (shell->scn->data[index]){
	      i_p = i;
	      if (shell->voxel[i].x == p.x)
		i += cxt->dx;
	    }

	    if (shell->voxel[i_p].visible) {

	      // shear
	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z; 

	      u = (int) (q.x + cxt->Su[p.z]); 
	      v = (int) (q.y + cxt->Sv[p.z]); 

	      is = u + ut+ shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {
	      
		l = shell->voxel[i_p].obj;

		if (l) {

		  // warp
		  uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		  vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
	      
		  iw = cxt->zbuff->tbv[vw + d.y] + uw + d.x;	     
	      
		  ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
	      
		  w = ww + wt;
		  // splatting
		  iw = cxt->zbuff->tbv[vw + d.y] + uw + d.x;		
		  for (j=0; j < fprint->n; j++){		
		    iw_p = iw + fprint->dp[j];
		    if (cxt->zbuff->dist[iw_p] > cxt->depth - w) {
		      warp->val[iw_p] = 0.0;
		      img->val[iw_p] = shell->scn->data[index];
		      cxt->zbuff->voxel[iw_p] = i_p;
		      cxt->zbuff->object[iw_p] = l;
		      cxt->zbuff->dist[iw_p] = cxt->depth - w;
		    }
		  }
		  shear->val[is]=warp->val[iw];
		}      
	      }
	    }
	  }
	}
      }
    }
    break;

  default: 
    Error(MSG1,"CSWShellRenderingDrawCut");
    break;
  }  

  
  DestroyAdjPxl(&fprint);
}


void ShellRenderingDrawSceneCut(Image *img, Shell *shell,Context *cxt, FBuffer *cumopac, char axis)
{
  
  int ut,vt,u,v,ww,iw,iw_p,i,i_p,i1,i2,j,index;
  float w,wt; 
  uchar l;

  Voxel p,q,c;
  Pixel d,e;
  AdjPxl *fprint=NULL;
  fprint = AdjPixels(img,cxt->footprint->adj);    

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  switch(axis) {

  case 'x':
    
    p.x = cxt->xi;
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
      i = shell->Mzx->tbrow[p.x] + p.z;
      
      if (shell->Mzx->val[i] >= 0) {
	
	if (cxt->dy == 1) {              
	  i1 = shell->Mzx->val[i];
	  i++;
	  while (shell->Mzx->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Mzx->val[i]-1;            
	} else {            
	  i2 = shell->Mzx->val[i];
	  i++;
	  while (shell->Mzx->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Mzx->val[i]-1;
	}
	i = i1;
	e.y = shell->pointer[i2].y + cxt->dy;
	for (p.y = shell->pointer[i1].y; p.y != e.y; p.y += cxt->dy) {
	  index = shell->scn->tbz[p.z] + shell->scn->tby[p.y] + p.x;	  
	  if (cxt->ymin <= p.y && p.y <= cxt->ymax && shell->scn->data[index]){
	    i_p = shell->pointer[i].i;
/* 	    if (shell->pointer[i].y == p.y)  */
/* 	      i += cxt->dy; */

/* 	    if (shell->voxel[i_p].visible) { */

	      q.x = p.x - c.x;	    
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	        	      
	      l = shell->voxel[i_p].obj;

	      if (l) {

		u=(int)(cxt->R[0][0]*q.x + cxt->R[0][1]*q.y + cxt->R[0][2]*q.z);
		v=(int)(cxt->R[1][0]*q.x + cxt->R[1][1]*q.y + cxt->R[1][2]*q.z);
		iw = cxt->zbuff->tbv[v + d.y] + u + d.x;	     	      
		ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
		w = ww + wt;
		// splatting
		iw = cxt->zbuff->tbv[v + d.y] + u + d.x;
		for (j=0; j < fprint->n; j++){		
		  iw_p = iw + fprint->dp[j];
		  if (cxt->zbuff->dist[iw_p] > cxt->depth - w) {
		    cumopac->val[iw_p] = 0.0; 
		    img->val[iw_p] = shell->scn->data[index];
		    cxt->zbuff->voxel[iw_p] = i_p;
		    cxt->zbuff->object[iw_p] = l;
              	    cxt->zbuff->dist[iw_p] = cxt->depth - w;		  
		  }
		}
		// }
	    }
	  }
	}
      }
    }
 
    break;

  case 'y': 
    
    p.y = cxt->yi;
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
      i = shell->Myz->tbrow[p.z] + p.y;
        
      if (shell->Myz->val[i] >= 0) {
          
	if (cxt->dx == 1) {              
	  i1 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Myz->val[i]-1;            
	} else {            
	  i2 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Myz->val[i]-1;
	}
	i = i1;
	e.x = shell->voxel[i2].x + cxt->dx;
	for (p.x = shell->voxel[i1].x; p.x != e.x; p.x += cxt->dx) {
	  index = shell->scn->tbz[p.z] + shell->scn->tby[p.y] + p.x;	  
	  if (cxt->xmin <= p.x && p.x <= cxt->xmax && shell->scn->data[index]){
	    i_p = i;
/* 	    if (shell->voxel[i].x == p.x)  */
/* 	      i += cxt->dx; */

/* 	    if (shell->voxel[i_p].visible) { */

	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	    
	      l = shell->voxel[i_p].obj;

	      if (l) {
	      
		u=(int)(cxt->R[0][0]*q.x + cxt->R[0][1]*q.y + cxt->R[0][2]*q.z);
		v=(int)(cxt->R[1][0]*q.x + cxt->R[1][1]*q.y + cxt->R[1][2]*q.z);
		iw = cxt->zbuff->tbv[v + d.y] + u + d.x;	     	      
		ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
		w = ww + wt;

		// splatting
		iw = cxt->zbuff->tbv[v + d.y] + u + d.x;
		for (j=0; j < fprint->n; j++){		
		  iw_p = iw + fprint->dp[j];
		  if (cxt->zbuff->dist[iw_p] > cxt->depth - w) {
		    cumopac->val[iw_p] = 0.0;
		    img->val[iw_p] = shell->scn->data[index];
		    cxt->zbuff->voxel[iw_p] = i_p;
		    cxt->zbuff->object[iw_p] = l;
		    cxt->zbuff->dist[iw_p] = cxt->depth - w;		  
		  }
		}
		// }
	    }
	  }
	}
      }
    }
  
    break;

  case 'z':
    
    p.z = cxt->zi;
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
      
      i = shell->Myz->tbrow[p.z] + p.y;
      
      if (shell->Myz->val[i] >= 0) {
	
	if (cxt->dx == 1) {              
	  i1 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Myz->val[i]-1;            
	} else {            
	  i2 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Myz->val[i]-1;
	}
	i = i1;
	e.x = shell->voxel[i2].x + cxt->dx;
	for (p.x = shell->voxel[i1].x; p.x != e.x; p.x += cxt->dx) {
	  index = shell->scn->tbz[p.z] + shell->scn->tby[p.y] + p.x;
	  if (cxt->xmin <= p.x && p.x <= cxt->xmax && shell->scn->data[index]){
	    i_p = i;
/* 	    if (shell->voxel[i].x == p.x)  */
/* 	      i += cxt->dx; */

/* 	    if (shell->voxel[i_p].visible) { */
	      
	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z; 	      

	      l = shell->voxel[i_p].obj;

	      if (l) {
		
		u=(int)(cxt->R[0][0]*q.x + cxt->R[0][1]*q.y + cxt->R[0][2]*q.z);
		v=(int)(cxt->R[1][0]*q.x + cxt->R[1][1]*q.y + cxt->R[1][2]*q.z);
		iw = cxt->zbuff->tbv[v + d.y] + u + d.x;	     	      
		ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
		w = ww + wt;

		// splatting
		iw = cxt->zbuff->tbv[v + d.y] + u + d.x;
		for (j=0; j < fprint->n; j++){		
		  iw_p = iw + fprint->dp[j];
		  if (cxt->zbuff->dist[iw_p] > cxt->depth - w){
		    cumopac->val[iw_p] = 0.0;
		    img->val[iw_p] = shell->scn->data[index];
		    cxt->zbuff->voxel[iw_p] = i_p;
		    cxt->zbuff->object[iw_p] = l;
		    cxt->zbuff->dist[iw_p] = cxt->depth - w;		 
		  }
		}
		//}
	    }
	  }
	}
      }
    }
    break;

  default: 
    Error(MSG1,"ShellRenderingDrawCut");
    break;

  }  
  DestroyAdjPxl(&fprint);
}

Image *SWShellRenderingCut(Shell *shell,Context *cxt, Curve *cs) {

  Image *img=NULL,*tmp=NULL;
  FBuffer *shear=NULL,*warp=NULL;
  Voxel p,q,c;
  Pixel d;
  Vector viewer;
  AdjPxl *fprint=NULL;

  int u,v,ut,vt,uw,vw,is,iw,iw_p,i,i_p,i1,i2,j,n;
  float w,wt,amb,spec,diff,shading,idist,cos_a,cos_2a,pow,nopac[256],opac,k;
  uchar l;

  for(i=0;i<256;i++)
    nopac[i] = (float)i/255.;

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  shear = CreateFBuffer(cxt->isize, cxt->jsize);
  warp = CreateFBuffer(cxt->width, cxt->height);
  InitFBuffer(shear,1.0);
  InitFBuffer(warp,1.0);
  InitZBuffer(cxt->zbuff);
  
  img=CreateImage(cxt->width, cxt->height);
  fprint = AdjPixels(img,cxt->footprint->adj);

  viewer.x = -cxt->IR[0][2];
  viewer.y = -cxt->IR[1][2];
  viewer.z = -cxt->IR[2][2];
    
  switch(cxt->PAxis) {

  case 'x':

    if (shell->body) {
      SWShellRenderingDrawCut(img,shell,cxt,shear,warp,'x');
      ShellRenderingDrawCut(img,shell,cxt,warp,'y');
      ShellRenderingDrawCut(img,shell,cxt,warp,'z');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      DestroyImage(&img);
      img = tmp;
    } else if (shell->scn) {
      SWShellRenderingDrawSceneCut(img,shell,cxt,shear,warp,'x');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'y');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'z');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      DestroyImage(&img);
      img = tmp;
    }
    
    for (p.x = cxt->xi; p.x != cxt->xf; p.x += cxt->dx) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Mzx->tbrow[p.x] + p.z;
        
        if (shell->Mzx->val[i] >= 0) {
          
          if (cxt->dy == 1) {              
            i1 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i2 = shell->Mzx->val[i]-1;            
          } else {            
            i2 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i1 = shell->Mzx->val[i]-1;
	  }
	  i2 += cxt->dy;          
          for (i = i1; i != i2; i += cxt->dy) {

	    // shear
	    i_p = shell->pointer[i].i;
	    l = shell->voxel[i_p].obj;

	    if (l && shell->voxel[i_p].visible) {

	      p.y = shell->pointer[i].y;
	      if (cxt->ymin <= p.y && p.y <= cxt->ymax) {
		q.x = p.x - c.x;
		q.y = p.y - c.y;
		q.z = p.z - c.z;

		u = (int) (q.y + cxt->Su[p.x]); 
		v = (int) (q.z + cxt->Sv[p.x]); 

		is = u + ut + shear->tbv[v + vt];

		if (shear->val[is] > 0.05) {
	    
		  // normal

		  n = shell->voxel[i_p].normal;

		  cos_a = viewer.x * shell->normaltable[n].x +\
		    viewer.y * shell->normaltable[n].y +\
		    viewer.z * shell->normaltable[n].z;

		  if (cos_a > 0.0) {

		    // shading


		    w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
                    k = cxt->depth - w;
		    idist = 1.0 - w/(float)cxt->depth;

		    cos_2a = 2*cos_a*cos_a - 1.0;
	      
		    if (cos_2a < 0.) {
		      pow = 0.;
		      spec = 0.;
		    } else {
		      pow = 1.;
		      for (j=0; j < cxt->obj[l].ns; j++) 
			pow = pow * cos_2a;
		      spec = cxt->obj[l].spec * pow;
		    }

		    opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac; 
		    amb  = cxt->obj[l].amb;
		    diff = cxt->obj[l].diff * cos_a;

		    shading =  (float)255.* opac * (amb + idist * (diff + spec));

		    //warp	      
		    uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
	      
		    vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);

		    iw = warp->tbv[vw + d.y] + uw + d.x;
	      
		    // splatting
		    for (j=0; j < fprint->n; j++){		
		      iw_p = iw + fprint->dp[j];
		      if (warp->val[iw_p] > .05) {
			if (cxt->zbuff->dist[iw_p] > k) {
			  img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->footprint->val[j]);
			  warp->val[iw_p] *= (1.0- (opac * cxt->footprint->val[j]));
			  if (cxt->zbuff->voxel[iw_p] == NIL) {
			    cxt->zbuff->voxel[iw_p] = i_p;
			    cxt->zbuff->object[iw_p] = l;
			    cxt->zbuff->dist[iw_p] = k;
			  }
			}
		      }
		    }
		    shear->val[is]=warp->val[iw];
		  }
		}
	      }
	    }
	  }	 	 
	}
      }

    break;
    
  case 'y': 

    if (shell->body) {
      SWShellRenderingDrawCut(img,shell,cxt,shear,warp,'y');
      ShellRenderingDrawCut(img,shell,cxt,warp,'z');
      ShellRenderingDrawCut(img,shell,cxt,warp,'x');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      DestroyImage(&img);
      img = tmp;
    } else if (shell->scn) {
      SWShellRenderingDrawSceneCut(img,shell,cxt,shear,warp,'y');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'z');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'x');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      DestroyImage(&img);
      img = tmp;
    }
    
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
	    i_p = i;
	    l = shell->voxel[i_p].obj;

	    if (l && shell->voxel[i_p].visible) {

	      p.x = shell->voxel[i].x;
	      if (cxt->xmin <= p.x && p.x <= cxt->xmax) { 	   
		q.x = p.x - c.x;
		q.y = p.y - c.y;
		q.z = p.z - c.z;
	    
		u = (int) (q.z + cxt->Su[p.y]); 
		v = (int) (q.x + cxt->Sv[p.y]); 

		is = u + ut+ shear->tbv[v + vt];

		if (shear->val[is] > 0.05) {
	      
		  // normal

		  n = shell->voxel[i_p].normal;

		  cos_a = viewer.x * shell->normaltable[n].x +\
		    viewer.y * shell->normaltable[n].y +\
		    viewer.z * shell->normaltable[n].z;

		  if (cos_a > 0.0) {

		    // shading

		    w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
                    k = cxt->depth - w;
		    idist = 1.0 - w/(float)cxt->depth;

		    cos_2a = 2*cos_a*cos_a - 1.0;
		
		    if (cos_2a < 0.) {
		      pow = 0.;
		      spec = 0.;
		    } else {
		      pow = 1.;
		      for (j=0; j < cxt->obj[l].ns; j++) 
			pow = pow * cos_2a;
		      spec = cxt->obj[l].spec * pow;
		    }

		    opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		    amb  = cxt->obj[l].amb;
		    diff = cxt->obj[l].diff * cos_a;
		
		    shading = (float)255.* opac * (amb + idist * (diff + spec));
		
		    // warp	      
		    uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		    vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		
		    iw = warp->tbv[vw + d.y] + uw + d.x;
		
		    // splatting
		    for (j=0; j < fprint->n; j++){		
		      iw_p = iw + fprint->dp[j];
		      if (warp->val[iw_p] > .05) {
			if (cxt->zbuff->dist[iw_p] > k) {
			  img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->footprint->val[j]);
			  warp->val[iw_p] *= (1.0- (opac * cxt->footprint->val[j]));
			  if (cxt->zbuff->voxel[iw_p] == NIL) {
			    cxt->zbuff->voxel[iw_p] = i_p;
			    cxt->zbuff->object[iw_p] = l;
			    cxt->zbuff->dist[iw_p] = k;
			  }
			}
		      }
		    }
		    shear->val[is]=warp->val[iw];
		  }
		}
	      }
	    }
	  }
	}
      }
    break;

  case 'z': 

    if (shell->body) {
      SWShellRenderingDrawCut(img,shell,cxt,shear,warp,'z');
      ShellRenderingDrawCut(img,shell,cxt,warp,'x');
      ShellRenderingDrawCut(img,shell,cxt,warp,'y');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      DestroyImage(&img);
      img = tmp;
    } else if (shell->scn) {
      SWShellRenderingDrawSceneCut(img,shell,cxt,shear,warp,'z');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'x');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'y');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      DestroyImage(&img);
      img = tmp;
    }
    
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) 
      for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
	    i_p = i;
	    l = shell->voxel[i_p].obj;

	    if (l && shell->voxel[i_p].visible) {

	      p.x = shell->voxel[i].x;
	      if (cxt->xmin <= p.x && p.x <= cxt->xmax) { 
		q.x = p.x - c.x;
		q.y = p.y - c.y;
		q.z = p.z - c.z; 

		u = (int) (q.x + cxt->Su[p.z]); 
		v = (int) (q.y + cxt->Sv[p.z]); 

		is = u + ut + shear->tbv[v + vt];
	    
		if (shear->val[is] > 0.05) {
	      
		  // normal
		  n = shell->voxel[i_p].normal;

		  cos_a = viewer.x * shell->normaltable[n].x +\
		    viewer.y * shell->normaltable[n].y +\
		    viewer.z * shell->normaltable[n].z;

		  if (cos_a > 0.0) {

		    // shading

		    w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
                    k = cxt->depth - w;
		    idist = 1.0 - w/(float)cxt->depth;

		    cos_2a = 2*cos_a*cos_a - 1.0;
		
		    if (cos_2a < 0.) {
		      pow = 0.;
		      spec = 0.;
		    } else {
		      pow = 1.;
		      for (j=0; j < cxt->obj[l].ns; j++) 
			pow = pow * cos_2a;
		      spec = cxt->obj[l].spec * pow;
		    }
		
		    opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		    amb  = cxt->obj[l].amb;
		    diff = cxt->obj[l].diff * cos_a;
		
		    shading =  (float)255.* opac * (amb + idist * (diff + spec));
		
		    // warp
		    uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		    vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		
		    iw = warp->tbv[vw + d.y] + uw + d.x;
		
		    // splatting
		
		    for (j=0; j < fprint->n; j++){		
		      iw_p = iw + fprint->dp[j];
		      if (warp->val[iw_p] > .05) {
			if (cxt->zbuff->dist[iw_p] > k) {
			  img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->footprint->val[j]);
			  warp->val[iw_p] *= (1.0- (opac * cxt->footprint->val[j]));
			  if (cxt->zbuff->voxel[iw_p] == NIL) {
			    cxt->zbuff->voxel[iw_p] = i_p;
			    cxt->zbuff->object[iw_p] = l;
			    cxt->zbuff->dist[iw_p] = k;
			  }
			}
		      }
		    }	      
		    shear->val[is]=warp->val[iw];
		  }
		}
	      }
	    }
	  }
	}
      }
    break;
      
  default: 
    Error(MSG1,"SWShellRendering");
    break;
    
  }			
  DestroyFBuffer(&shear);
  DestroyFBuffer(&warp);
  DestroyAdjPxl(&fprint);
  return(img);
}

CImage *CSWShellRenderingCut(Shell *shell,Context *cxt, Curve *cs) 
{

  CImage *cimg=NULL;
  Image *img=NULL,*tmp=NULL;
  FBuffer *shear=NULL,*warp=NULL;
  Voxel p,q,c;
  Pixel d;
  Vector viewer;
  AdjPxl *fprint=NULL;


  int u,v,ut,vt,uw,vw,ww,is,iw,iw_p,i,i_p,i1,i2,j,n;
  float w,wt,amb,spec,diff,shading,idist,cos_a,cos_2a,pow,alpha,nopac[256],opac,k; 
  uchar l;

  for(i=0;i<256;i++)
    nopac[i] = (float)i/255.;

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  shear = CreateFBuffer(cxt->isize, cxt->jsize);
  warp = CreateFBuffer(cxt->width, cxt->height);

  InitFBuffer(shear,1.0);
  InitFBuffer(warp,1.0);
  InitZBuffer(cxt->zbuff);

  img = CreateImage(cxt->width,cxt->height);
  fprint = AdjPixels(img,cxt->footprint->adj);

  viewer.x = -cxt->IR[0][2];
  viewer.y = -cxt->IR[1][2];
  viewer.z = -cxt->IR[2][2];
    
  switch(cxt->PAxis) {

  case 'x':


    if (shell->body) {
      SWShellRenderingDrawCut(img,shell,cxt,shear,warp,'x');
      ShellRenderingDrawCut(img,shell,cxt,warp,'y');
      ShellRenderingDrawCut(img,shell,cxt,warp,'z');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,tmp);
    } else if (shell->scn) {
      ISWShellRenderingDrawSceneCut(img,shell,cxt,shear,warp,'x');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,img);
    } else {
      cimg = CreateCImage(cxt->width,cxt->height);
    } 
      
    for (p.x = cxt->xi; p.x != cxt->xf; p.x += cxt->dx) {
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
	i = shell->Mzx->tbrow[p.x] + p.z;
        
	if (shell->Mzx->val[i] >= 0) {
          
	  if (cxt->dy == 1) {              
	    i1 = shell->Mzx->val[i];
	    i++;
	    while (shell->Mzx->val[i] < 0) {
	      i++;
	    } 
	    i2 = shell->Mzx->val[i]-1;            
	  } else {            
	    i2 = shell->Mzx->val[i];
	    i++;
	    while (shell->Mzx->val[i] < 0) {
	      i++;
	    } 
	    i1 = shell->Mzx->val[i]-1;
	  }
	  i2 += cxt->dy;          
	  for (i = i1; i != i2; i += cxt->dy) {

	    // shear
	    p.y = shell->pointer[i].y;
	    if (cxt->ymin <= p.y && p.y <= cxt->ymax) {
		  
	      q.x = p.x - c.x;	    
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;

	      u = (int) (q.y + cxt->Su[p.x]); 
	      v = (int) (q.z + cxt->Sv[p.x]); 

	      is = u + ut + shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {
		
		// normal
		i_p = shell->pointer[i].i;
		
		if (shell->voxel[i_p].visible) {		
		
		  l = shell->voxel[i_p].obj;

		  if (l) {

		  n = shell->voxel[i_p].normal;
		  
		  cos_a = viewer.x * shell->normaltable[n].x +\
		    viewer.y * shell->normaltable[n].y +\
		    viewer.z * shell->normaltable[n].z;
		  
		  if (cos_a > 0) {
		       
		    //warp	      
		    uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		    
		    vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);

		    iw = warp->tbv[vw + d.y] + uw + d.x;

		    ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;		  
		    w = ww + wt;k = cxt->depth - w;

		    // shading

		    idist = 1.0 - w/(float)cxt->depth;
		    
		    cos_2a = 2*cos_a*cos_a - 1.0;
		    
		    if (cos_2a < 0.) {
		      pow = 0.;
		      spec = 0.;
		    } else {
		      pow = 1.;
		      for (j=0; j < cxt->obj[l].ns; j++) 
			pow = pow * cos_2a;
		      spec = cxt->obj[l].spec * pow;
		    }
		    
		    opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		    amb  = cxt->obj[l].amb;
		    diff = cxt->obj[l].diff * cos_a;
		    
		    shading = (amb + idist * (diff + spec));
		    
		    // splatting
		    
		    for (j=0; j < fprint->n; j++){		
		      iw_p = iw + fprint->dp[j];
		      if (warp->val[iw_p] > .05) {
			alpha = cxt->footprint->val[j] * opac;
			AccVoxelColor(cimg,cxt,iw_p,shading,warp->val[iw_p]*alpha,l);
			warp->val[iw_p] *= (1.0-alpha);
			if (cxt->zbuff->voxel[iw_p] == NIL) {
			  cxt->zbuff->voxel[iw_p] = i_p;
			  cxt->zbuff->object[iw_p] = l;
			  if (cxt->zbuff->dist[iw_p] > k)
 		            cxt->zbuff->dist[iw_p] = k;
			}
		      }
		    }
		    shear->val[is]=warp->val[iw];
		  }
		} 		     
	      }
	    }
	  }
	}
      }
    }
    }
    break;
    
  case 'y': 


    if (shell->body) {
      SWShellRenderingDrawCut(img,shell,cxt,shear,warp,'y');
      ShellRenderingDrawCut(img,shell,cxt,warp,'z');
      ShellRenderingDrawCut(img,shell,cxt,warp,'x');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,tmp);
    } else if (shell->scn) {
      ISWShellRenderingDrawSceneCut(img,shell,cxt,shear,warp,'y');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,img);
    } else {
      cimg = CreateCImage(cxt->width,cxt->height);
    }
    
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
	i = shell->Myz->tbrow[p.z] + p.y;
        
	if (shell->Myz->val[i] >= 0) {
          
	  if (cxt->dx == 1) {              
	    i1 = shell->Myz->val[i];
	    i++;
	    while (shell->Myz->val[i] < 0) {
	      i++;
	    } 
	    i2 = shell->Myz->val[i]-1;            
	  } else {            
	    i2 = shell->Myz->val[i];
	    i++;
	    while (shell->Myz->val[i] < 0) {
	      i++;
	    } 
	    i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
	  for (i = i1; i != i2; i += cxt->dx) {

	    // shear
	    p.x = shell->voxel[i].x;
	    if (cxt->xmin <= p.x && p.x <= cxt->xmax) {        	   
	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	    
	      u = (int) (q.z + cxt->Su[p.y]); 
	      v = (int) (q.x + cxt->Sv[p.y]); 

	      is = u + ut+ shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {
	      
		// normal
		i_p = i;

		if (shell->voxel[i_p].visible) {

		  l = shell->voxel[i_p].obj;

		  if (l) {

		  n = shell->voxel[i_p].normal;

		  cos_a = viewer.x * shell->normaltable[n].x +\
		    viewer.y * shell->normaltable[n].y +\
		    viewer.z * shell->normaltable[n].z;

		  if (cos_a > 0) {
		    
		    // warp	      
		    uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		    vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);

		    iw = warp->tbv[vw + d.y] + uw + d.x;
		  
		    ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;

		    w = ww + wt;k = cxt->depth - w;

		    // shading
		   
		    idist = 1.0 - w/(float)cxt->depth;

		    cos_2a = 2*cos_a*cos_a - 1.0;
		
		    if (cos_2a < 0.) {
		      pow = 0.;
		      spec = 0.;
		    } else {
		      pow = 1.;
		      for (j=0; j < cxt->obj[l].ns; j++) 
			pow = pow * cos_2a;
		      spec = cxt->obj[l].spec * pow;
		    }

		    opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		    amb  = cxt->obj[l].amb;
		    diff = cxt->obj[l].diff * cos_a;
		
		    shading =  (amb + idist * (diff + spec));
		
		    // splatting
		    for (j=0; j < fprint->n; j++){		
		      iw_p = iw + fprint->dp[j];
		      if (warp->val[iw_p] > .05) {
			alpha = cxt->footprint->val[j] * opac;
			AccVoxelColor(cimg,cxt,iw_p,shading,warp->val[iw_p]*alpha,l);
			warp->val[iw_p] *= (1.0-alpha);
			if (cxt->zbuff->voxel[iw_p] == NIL) {
			  cxt->zbuff->voxel[iw_p] = i_p;
			  cxt->zbuff->object[iw_p] = l;
			  if (cxt->zbuff->dist[iw_p] > k)
		            cxt->zbuff->dist[iw_p] = k;
			}
		      }
		    }
		    shear->val[is]=warp->val[iw];
		  }
		}
	      }
	    }
	  }
	}
	}
      }
    }
    break;
    
  case 'z': 

    if (shell->body) {
      SWShellRenderingDrawCut(img,shell,cxt,shear,warp,'z');
      ShellRenderingDrawCut(img,shell,cxt,warp,'x');
      ShellRenderingDrawCut(img,shell,cxt,warp,'y');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,img);
    } else if (shell->scn) {
      ISWShellRenderingDrawSceneCut(img,shell,cxt,shear,warp,'z');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,tmp);
    } else {
      cimg = CreateCImage(cxt->width,cxt->height);
    }

    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
      for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
	i = shell->Myz->tbrow[p.z] + p.y;
        
	if (shell->Myz->val[i] >= 0) {
          
	  if (cxt->dx == 1) {              
	    i1 = shell->Myz->val[i];
	    i++;
	    while (shell->Myz->val[i] < 0) {
	      i++;
	    } 
	    i2 = shell->Myz->val[i]-1;            
	  } else {            
	    i2 = shell->Myz->val[i];
	    i++;
	    while (shell->Myz->val[i] < 0) {
	      i++;
	    } 
	    i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
	  for (i = i1; i != i2; i += cxt->dx) {

	    // shear
	    p.x = shell->voxel[i].x;
	    if (cxt->xmin <= p.x && p.x <= cxt->xmax) {        	   
	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z; 

	      u = (int) (q.x + cxt->Su[p.z]); 
	      v = (int) (q.y + cxt->Sv[p.z]); 

	      is = u + ut + shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {
	      
		// normal
		i_p = i;

		if (shell->voxel[i_p].visible) {

		  l = shell->voxel[i_p].obj;

		  if (l) {

		  n = shell->voxel[i_p].normal;

		  cos_a = viewer.x * shell->normaltable[n].x +\
		    viewer.y * shell->normaltable[n].y +\
		    viewer.z * shell->normaltable[n].z;

		  if (cos_a > 0) {

		    // warp
		    uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		    vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);

		    iw = warp->tbv[vw + d.y] + uw + d.x;

		    ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
		  
		    w = ww + wt;k = cxt->depth - w;

		    // shading

		    idist = 1.0 - w/(float)cxt->depth;

		    cos_2a = 2*cos_a*cos_a - 1.0;
		
		    if (cos_2a < 0.) {
		      pow = 0.;
		      spec = 0.;
		    } else {
		      pow = 1.;
		      for (j=0; j < cxt->obj[l].ns; j++) 
			pow = pow * cos_2a;
		      spec = cxt->obj[l].spec * pow;
		    }
		
		    opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		    amb  = cxt->obj[l].amb;
		    diff = cxt->obj[l].diff * cos_a;
		
		    shading =  (amb + idist * (diff + spec));
				
		    // splatting
		    iw = warp->tbv[vw + d.y] + uw + d.x;		
		    for (j=0; j < fprint->n; j++){		
		      iw_p = iw + fprint->dp[j];
		      if (warp->val[iw_p] > .05) {
			alpha = cxt->footprint->val[j] * opac;
			AccVoxelColor(cimg,cxt,iw_p,shading,warp->val[iw_p]*alpha,l);
			warp->val[iw_p] *= (1.0-alpha);
			if (cxt->zbuff->voxel[iw_p] == NIL) {
			  cxt->zbuff->voxel[iw_p] = i_p;
			  cxt->zbuff->object[iw_p] = l;
			  if (cxt->zbuff->dist[iw_p] > k)
		            cxt->zbuff->dist[iw_p] = k;
			}
		      }
		    }	      
		    shear->val[is]=warp->val[iw];
		  } 
		}
	      }
	    }
	  }
	}
      }
    }
    }
    break;
      
  default: 
    Error(MSG1,"CSWShellRenderingCut");
    break;
  }		
  DestroyImage(&img);  
  DestroyImage(&tmp);
  DestroyFBuffer(&shear);
  DestroyFBuffer(&warp);
  DestroyAdjPxl(&fprint);
  return(cimg);
}

CImage *FastCSWShellRenderingCut(Shell *shell,Context *cxt, Curve *cs) 
{

  CImage *cimg=NULL;
  Image *img=NULL,*tmp=NULL;
  FBuffer *shear=NULL,*warp=NULL;
  Voxel p,q,c;
  Pixel d;
  Vector viewer;
  AdjPxl *fprint=NULL;


  int u,v,ut,vt,uw,vw,ww,is,iw,iw_p,i,i_p,i1,i2,j,n;
  float w,wt,amb,spec,diff,shading,idist,cos_a,cos_2a,pow,alpha,nopac[256],opac,k; 
  uchar l;

  for(i=0;i<256;i++)
    nopac[i] = (float)i/255.;

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  shear = CreateFBuffer(cxt->isize, cxt->jsize);
  warp = CreateFBuffer(cxt->width, cxt->height);

  InitFBuffer(shear,1.0);
  InitFBuffer(warp,1.0);
  InitZBuffer(cxt->zbuff);

  img = CreateImage(cxt->width,cxt->height);
  fprint = AdjPixels(img,cxt->footprint->adj);

  viewer.x = -cxt->IR[0][2];
  viewer.y = -cxt->IR[1][2];
  viewer.z = -cxt->IR[2][2];
    
  switch(cxt->PAxis) {

  case 'x':


    if (shell->body) {
      SWShellRenderingDrawCut(img,shell,cxt,shear,warp,'x');
      ShellRenderingDrawCut(img,shell,cxt,warp,'y');
      ShellRenderingDrawCut(img,shell,cxt,warp,'z');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,tmp);
    } else if (shell->scn) {
      SWShellRenderingDrawSceneCut(img,shell,cxt,shear,warp,'x');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'y');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'z');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,tmp);
    } else {
      cimg = CreateCImage(cxt->width,cxt->height);
    } 
      
    for (p.x = cxt->xi; p.x != cxt->xf; p.x += cxt->dx) {
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
	i = shell->Mzx->tbrow[p.x] + p.z;
        
	if (shell->Mzx->val[i] >= 0) {
          
	  if (cxt->dy == 1) {              
	    i1 = shell->Mzx->val[i];
	    i++;
	    while (shell->Mzx->val[i] < 0) {
	      i++;
	    } 
	    i2 = shell->Mzx->val[i]-1;            
	  } else {            
	    i2 = shell->Mzx->val[i];
	    i++;
	    while (shell->Mzx->val[i] < 0) {
	      i++;
	    } 
	    i1 = shell->Mzx->val[i]-1;
	  }
	  i2 += cxt->dy;          
	  for (i = i1; i != i2; i += cxt->dy) {

	    // shear
	    p.y = shell->pointer[i].y;
	    if (cxt->ymin <= p.y && p.y <= cxt->ymax) {
		  
	      q.x = p.x - c.x;	    
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;

	      u = (int) (q.y + cxt->Su[p.x]); 
	      v = (int) (q.z + cxt->Sv[p.x]); 

	      is = u + ut + shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {
		
		// normal
		i_p = shell->pointer[i].i;
		
		if (shell->voxel[i_p].visible) {		
		
		  l = shell->voxel[i_p].obj;

		  if (l) {

		  n = shell->voxel[i_p].normal;
		  
		  cos_a = viewer.x * shell->normaltable[n].x +\
		    viewer.y * shell->normaltable[n].y +\
		    viewer.z * shell->normaltable[n].z;
		  
		  if (cos_a > 0) {
		       
		    //warp	      
		    uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		    
		    vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);

		    iw = warp->tbv[vw + d.y] + uw + d.x;

		    ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;		  
		    w = ww + wt;k = cxt->depth - w;

		    // shading

		    idist = 1.0 - w/(float)cxt->depth;
		    
		    cos_2a = 2*cos_a*cos_a - 1.0;
		    
		    if (cos_2a < 0.) {
		      pow = 0.;
		      spec = 0.;
		    } else {
		      pow = 1.;
		      for (j=0; j < cxt->obj[l].ns; j++) 
			pow = pow * cos_2a;
		      spec = cxt->obj[l].spec * pow;
		    }
		    
		    opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		    amb  = cxt->obj[l].amb;
		    diff = cxt->obj[l].diff * cos_a;
		    
		    shading = (amb + idist * (diff + spec));
		    
		    // splatting
		    
		    for (j=0; j < fprint->n; j++){		
		      iw_p = iw + fprint->dp[j];
		      if (warp->val[iw_p] > .05) {
			alpha = cxt->footprint->val[j] * opac;
			AccVoxelColor(cimg,cxt,iw_p,shading,warp->val[iw_p]*alpha,l);
			warp->val[iw_p] *= (1.0-alpha);
			if (cxt->zbuff->voxel[iw_p] == NIL) {
			  cxt->zbuff->voxel[iw_p] = i_p;
			  cxt->zbuff->object[iw_p] = l;
			  if (cxt->zbuff->dist[iw_p] > k)
		  cxt->zbuff->dist[iw_p] = k;
			}
		      }
		    }
		    shear->val[is]=warp->val[iw];
		  }
		} 		     
	      }
	    }
	  }
	}
      }
    }
    }
    break;
    
  case 'y': 


    if (shell->body) {
      SWShellRenderingDrawCut(img,shell,cxt,shear,warp,'y');
      ShellRenderingDrawCut(img,shell,cxt,warp,'z');
      ShellRenderingDrawCut(img,shell,cxt,warp,'x');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,tmp);
    } else if (shell->scn) {
      SWShellRenderingDrawSceneCut(img,shell,cxt,shear,warp,'y');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'z');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'x');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,tmp);
    } else {
      cimg = CreateCImage(cxt->width,cxt->height);
    }
    
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
	i = shell->Myz->tbrow[p.z] + p.y;
        
	if (shell->Myz->val[i] >= 0) {
          
	  if (cxt->dx == 1) {              
	    i1 = shell->Myz->val[i];
	    i++;
	    while (shell->Myz->val[i] < 0) {
	      i++;
	    } 
	    i2 = shell->Myz->val[i]-1;            
	  } else {            
	    i2 = shell->Myz->val[i];
	    i++;
	    while (shell->Myz->val[i] < 0) {
	      i++;
	    } 
	    i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
	  for (i = i1; i != i2; i += cxt->dx) {

	    // shear
	    p.x = shell->voxel[i].x;
	    if (cxt->xmin <= p.x && p.x <= cxt->xmax) {        	   
	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	    
	      u = (int) (q.z + cxt->Su[p.y]); 
	      v = (int) (q.x + cxt->Sv[p.y]); 

	      is = u + ut+ shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {
	      
		// normal
		i_p = i;

		if (shell->voxel[i_p].visible) {

		  l = shell->voxel[i_p].obj;

		  if (l) {

		  n = shell->voxel[i_p].normal;

		  cos_a = viewer.x * shell->normaltable[n].x +\
		    viewer.y * shell->normaltable[n].y +\
		    viewer.z * shell->normaltable[n].z;

		  if (cos_a > 0) {
		    
		    // warp	      
		    uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		    vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);

		    iw = warp->tbv[vw + d.y] + uw + d.x;
		  
		    ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;

		    w = ww + wt;k = cxt->depth - w;

		    // shading
		   
		    idist = 1.0 - w/(float)cxt->depth;

		    cos_2a = 2*cos_a*cos_a - 1.0;
		
		    if (cos_2a < 0.) {
		      pow = 0.;
		      spec = 0.;
		    } else {
		      pow = 1.;
		      for (j=0; j < cxt->obj[l].ns; j++) 
			pow = pow * cos_2a;
		      spec = cxt->obj[l].spec * pow;
		    }

		    opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		    amb  = cxt->obj[l].amb;
		    diff = cxt->obj[l].diff * cos_a;
		
		    shading =  (amb + idist * (diff + spec));
		
		    // splatting
		    for (j=0; j < fprint->n; j++){		
		      iw_p = iw + fprint->dp[j];
		      if (warp->val[iw_p] > .05) {
			alpha = cxt->footprint->val[j] * opac;
			AccVoxelColor(cimg,cxt,iw_p,shading,warp->val[iw_p]*alpha,l);
			warp->val[iw_p] *= (1.0-alpha);
			if (cxt->zbuff->voxel[iw_p] == NIL) {
			  cxt->zbuff->voxel[iw_p] = i_p;
			  cxt->zbuff->object[iw_p] = l;
			  if (cxt->zbuff->dist[iw_p] > k)
		  cxt->zbuff->dist[iw_p] = k;
			}
		      }
		    }
		    shear->val[is]=warp->val[iw];
		  }
		}
	      }
	    }
	  }
	}
	}
      }
    }
    break;
    
  case 'z': 

    if (shell->body) {
      SWShellRenderingDrawCut(img,shell,cxt,shear,warp,'z');
      ShellRenderingDrawCut(img,shell,cxt,warp,'x');
      ShellRenderingDrawCut(img,shell,cxt,warp,'y');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,tmp);
    } else if (shell->scn) {
      SWShellRenderingDrawSceneCut(img,shell,cxt,shear,warp,'z');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'x');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'y');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,tmp);
    } else {
      cimg = CreateCImage(cxt->width,cxt->height);
    }

    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
      for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
	i = shell->Myz->tbrow[p.z] + p.y;
        
	if (shell->Myz->val[i] >= 0) {
          
	  if (cxt->dx == 1) {              
	    i1 = shell->Myz->val[i];
	    i++;
	    while (shell->Myz->val[i] < 0) {
	      i++;
	    } 
	    i2 = shell->Myz->val[i]-1;            
	  } else {            
	    i2 = shell->Myz->val[i];
	    i++;
	    while (shell->Myz->val[i] < 0) {
	      i++;
	    } 
	    i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
	  for (i = i1; i != i2; i += cxt->dx) {

	    // shear
	    p.x = shell->voxel[i].x;
	    if (cxt->xmin <= p.x && p.x <= cxt->xmax) {        	   
	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z; 

	      u = (int) (q.x + cxt->Su[p.z]); 
	      v = (int) (q.y + cxt->Sv[p.z]); 

	      is = u + ut + shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {
	      
		// normal
		i_p = i;

		if (shell->voxel[i_p].visible) {

		  l = shell->voxel[i_p].obj;

		  if (l) {

		  n = shell->voxel[i_p].normal;

		  cos_a = viewer.x * shell->normaltable[n].x +\
		    viewer.y * shell->normaltable[n].y +\
		    viewer.z * shell->normaltable[n].z;

		  if (cos_a > 0) {

		    // warp
		    uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		    vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);

		    iw = warp->tbv[vw + d.y] + uw + d.x;

		    ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
		  
		    w = ww + wt;k = cxt->depth - w;

		    // shading

		    idist = 1.0 - w/(float)cxt->depth;

		    cos_2a = 2*cos_a*cos_a - 1.0;
		
		    if (cos_2a < 0.) {
		      pow = 0.;
		      spec = 0.;
		    } else {
		      pow = 1.;
		      for (j=0; j < cxt->obj[l].ns; j++) 
			pow = pow * cos_2a;
		      spec = cxt->obj[l].spec * pow;
		    }
		
		    opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
		    amb  = cxt->obj[l].amb;
		    diff = cxt->obj[l].diff * cos_a;
		
		    shading =  (amb + idist * (diff + spec));
				
		    // splatting
		    iw = warp->tbv[vw + d.y] + uw + d.x;		
		    for (j=0; j < fprint->n; j++){		
		      iw_p = iw + fprint->dp[j];
		      if (warp->val[iw_p] > .05) {
			alpha = cxt->footprint->val[j] * opac;
			AccVoxelColor(cimg,cxt,iw_p,shading,warp->val[iw_p]*alpha,l);
			warp->val[iw_p] *= (1.0-alpha);
			if (cxt->zbuff->voxel[iw_p] == NIL) {
			  cxt->zbuff->voxel[iw_p] = i_p;
			  cxt->zbuff->object[iw_p] = l;
			  if (cxt->zbuff->dist[iw_p] > k)
		  cxt->zbuff->dist[iw_p] = k;
			}
		      }
		    }	      
		    shear->val[is]=warp->val[iw];
		  } 
		}
	      }
	    }
	  }
	}
      }
    }
    }
    break;
      
  default: 
    Error(MSG1,"CSWShellRenderingCut");
    break;
  }		
  DestroyImage(&img);  
  DestroyImage(&tmp);
  DestroyFBuffer(&shear);
  DestroyFBuffer(&warp);
  DestroyAdjPxl(&fprint);
  return(cimg);
}

CImage *CSWShellRenderingCutPlane (Shell *shell,Context *cxt, Curve *cs, Plane *pl) 
{

  CImage *cimg=NULL;
  Image *img=NULL,*tmp=NULL;
  FBuffer *shear=NULL,*warp=NULL;
  Voxel p,q,c;
  Pixel d;
  Vector viewer;
  AdjPxl *fprint=NULL;

  int u,v,ut,vt,uw,vw,ww,is,iw,iw_p,i,i_p,i1,i2,j,n;
  float w,wt,amb,spec,diff,shading,idist,cos_a,cos_2a,pow,alpha,nopac[256],opac,k; 
  uchar l;

  for(i=0;i<256;i++)
    nopac[i] = (float)i/255.;

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  shear = CreateFBuffer(cxt->isize, cxt->jsize);
  warp = CreateFBuffer(cxt->width, cxt->height);

  InitFBuffer(shear,1.0);
  InitFBuffer(warp,1.0);
  InitZBuffer(cxt->zbuff);

  SetPlaneZBuffer(cxt->zbuff, pl);

  img = CreateImage(cxt->width,cxt->height);
  fprint = AdjPixels(img,cxt->footprint->adj);

  viewer.x = -cxt->IR[0][2];
  viewer.y = -cxt->IR[1][2];
  viewer.z = -cxt->IR[2][2];
    
  switch(cxt->PAxis) {

  case 'x':

    if (shell->body) {
      ShellRenderingDrawCutPlane(img,shell,cxt,warp);
      SWShellRenderingDrawCut(img,shell,cxt,shear,warp,'x');
      ShellRenderingDrawCut(img,shell,cxt,warp,'y');
      ShellRenderingDrawCut(img,shell,cxt,warp,'z');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,tmp);
    } else if (shell->scn) {
      SWShellRenderingDrawSceneCut(img,shell,cxt,shear,warp,'x');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'y');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'z');
      ShellRenderingDrawSceneCutPlane(img,shell,cxt,warp);
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,tmp);
    } else {
      cimg = CreateCImage(cxt->width,cxt->height);
    }
      
    for (p.x = cxt->xi; p.x != cxt->xf; p.x += cxt->dx) {
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
	i = shell->Mzx->tbrow[p.x] + p.z;
        
	if (shell->Mzx->val[i] >= 0) {
          
	  if (cxt->dy == 1) {              
	    i1 = shell->Mzx->val[i];
	    i++;
	    while (shell->Mzx->val[i] < 0) {
	      i++;
	    } 
	    i2 = shell->Mzx->val[i]-1;            
	  } else {            
	    i2 = shell->Mzx->val[i];
	    i++;
	    while (shell->Mzx->val[i] < 0) {
	      i++;
	    } 
	    i1 = shell->Mzx->val[i]-1;
	  }
	  i2 += cxt->dy;          
	  for (i = i1; i != i2; i += cxt->dy) {

	    // shear
	    p.y = shell->pointer[i].y;
	    if (cxt->ymin <= p.y && p.y <= cxt->ymax) {
		  
	      q.x = p.x - c.x;	    
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;

	      u = (int) (q.y + cxt->Su[p.x]); 
	      v = (int) (q.z + cxt->Sv[p.x]); 

	      is = u + ut + shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {
		
		// normal
		i_p = shell->pointer[i].i;
		
		if (shell->voxel[i_p].visible) {		
		
		  l = shell->voxel[i_p].obj;

		  if (l) {

		    n = shell->voxel[i_p].normal;
		    
		    cos_a = viewer.x * shell->normaltable[n].x +\
		      viewer.y * shell->normaltable[n].y +\
		      viewer.z * shell->normaltable[n].z;		    
		    
		    if (cos_a > 0) {
		      
		      //warp	      
		      uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		      
		      vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		      
		      iw = warp->tbv[vw + d.y] + uw + d.x;
		      
		      ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;		  
		      w = ww + wt;k = cxt->depth - w;
		      
		      if (cxt->zbuff->dist[iw] > k) {

			// shading
			
			idist = 1.0 - w/(float)cxt->depth;
			
			cos_2a = 2*cos_a*cos_a - 1.0;
			
			if (cos_2a < 0.) {
			  pow = 0.;
			  spec = 0.;
			} else {
			  pow = 1.;
			  for (j=0; j < cxt->obj[l].ns; j++) 
			    pow = pow * cos_2a;
			  spec = cxt->obj[l].spec * pow;
			}
			
			opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
			amb  = cxt->obj[l].amb;
			diff = cxt->obj[l].diff * cos_a;
		    
			shading = (amb + idist * (diff + spec));
			
			// splatting
			
			for (j=0; j < fprint->n; j++){		
			  iw_p = iw + fprint->dp[j];
			  if (warp->val[iw_p] > .05) {
			    if (cxt->zbuff->dist[iw_p] > k) {
			      alpha = cxt->footprint->val[j] * opac;
			      AccVoxelColor(cimg,cxt,iw_p,shading,warp->val[iw_p]*alpha,l);
			      warp->val[iw_p] *= (1.0-alpha);
			      if (cxt->zbuff->voxel[iw_p] == NIL) {
				cxt->zbuff->voxel[iw_p] = i_p;
				cxt->zbuff->object[iw_p] = l;
				cxt->zbuff->dist[iw_p] = k;
			      }
			    }
			  }
			}			  
			shear->val[is]=warp->val[iw];		      
		      } 
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    }
    break;
    
  case 'y': 

    if (shell->body) {
      ShellRenderingDrawCutPlane(img,shell,cxt,warp);
      SWShellRenderingDrawCut(img,shell,cxt,shear,warp,'y');
      ShellRenderingDrawCut(img,shell,cxt,warp,'z');
      ShellRenderingDrawCut(img,shell,cxt,warp,'x');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,tmp);
    } else if (shell->scn) {
      SWShellRenderingDrawSceneCut(img,shell,cxt,shear,warp,'y');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'z');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'x');
      ShellRenderingDrawSceneCutPlane(img,shell,cxt,warp);
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,tmp);
    } else {
      cimg = CreateCImage(cxt->width,cxt->height);
    }
    
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
	i = shell->Myz->tbrow[p.z] + p.y;
        
	if (shell->Myz->val[i] >= 0) {
          
	  if (cxt->dx == 1) {              
	    i1 = shell->Myz->val[i];
	    i++;
	    while (shell->Myz->val[i] < 0) {
	      i++;
	    } 
	    i2 = shell->Myz->val[i]-1;            
	  } else {            
	    i2 = shell->Myz->val[i];
	    i++;
	    while (shell->Myz->val[i] < 0) {
	      i++;
	    } 
	    i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
	  for (i = i1; i != i2; i += cxt->dx) {
	    
	    // shear
	    p.x = shell->voxel[i].x;
	    if (cxt->xmin <= p.x && p.x <= cxt->xmax) {        	   
	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z;
	      
	      u = (int) (q.z + cxt->Su[p.y]); 
	      v = (int) (q.x + cxt->Sv[p.y]); 
	      
	      is = u + ut+ shear->tbv[v + vt];
	      
	      if (shear->val[is] > 0.05) {
		
		// normal
		i_p = i;
		
		if (shell->voxel[i_p].visible) {
		  
		  l = shell->voxel[i_p].obj;
		  
		  if (l) {
		    
		    n = shell->voxel[i_p].normal;
		    
		    cos_a = viewer.x * shell->normaltable[n].x +\
		      viewer.y * shell->normaltable[n].y +\
		      viewer.z * shell->normaltable[n].z;
		      
		    if (cos_a > 0) {
			
		      // warp	      
			uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		      
		      vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		      
		      iw = warp->tbv[vw + d.y] + uw + d.x;
		      
		      ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
		      
		      w = ww + wt;k = cxt->depth - w;

		      if (cxt->zbuff->dist[iw] > k) {

			// shading
			
			idist = 1.0 - w/(float)cxt->depth;
			
			cos_2a = 2*cos_a*cos_a - 1.0;
			
			if (cos_2a < 0.) {
			  pow = 0.;
			  spec = 0.;
			} else {
			  pow = 1.;
			  for (j=0; j < cxt->obj[l].ns; j++) 
			    pow = pow * cos_2a;
			  spec = cxt->obj[l].spec * pow;
			}
			
			opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
			amb  = cxt->obj[l].amb;
			diff = cxt->obj[l].diff * cos_a;
			
			shading =  (amb + idist * (diff + spec));
			
			// splatting
			for (j=0; j < fprint->n; j++){		
			  iw_p = iw + fprint->dp[j];
			  if (warp->val[iw_p] > .05) {
  			    if (cxt->zbuff->dist[iw_p] > k) {
			      alpha = cxt->footprint->val[j] * opac;
			      AccVoxelColor(cimg,cxt,iw_p,shading,warp->val[iw_p]*alpha,l);
			      warp->val[iw_p] *= (1.0-alpha);

			      if (cxt->zbuff->voxel[iw_p] == NIL) {
				cxt->zbuff->voxel[iw_p] = i_p;
				cxt->zbuff->object[iw_p] = l;
				cxt->zbuff->dist[iw_p] = k;
			      }
			    }
			  }
			}
			shear->val[is]=warp->val[iw];
		      }
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    }
    break;
    
  case 'z': 

    if (shell->body) {
      ShellRenderingDrawCutPlane(img,shell,cxt,warp);
      SWShellRenderingDrawCut(img,shell,cxt,shear,warp,'z');
      ShellRenderingDrawCut(img,shell,cxt,warp,'x');
      ShellRenderingDrawCut(img,shell,cxt,warp,'y');
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,tmp);
    } else if (shell->scn) {
      SWShellRenderingDrawSceneCut(img,shell,cxt,shear,warp,'z');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'x');
      ShellRenderingDrawSceneCut(img,shell,cxt,warp,'y');
      ShellRenderingDrawSceneCutPlane(img,shell,cxt,warp);
      tmp =  LinearStretch(img,(int)cs->X[0],(int)cs->X[1],(int)cs->Y[0],(int)cs->Y[1]);
      cimg = Colorize(cxt,tmp);
    } else {
      cimg = CreateCImage(cxt->width,cxt->height);
    }

    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
      for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
	i = shell->Myz->tbrow[p.z] + p.y;
        
	if (shell->Myz->val[i] >= 0) {
          
	  if (cxt->dx == 1) {              
	    i1 = shell->Myz->val[i];
	    i++;
	    while (shell->Myz->val[i] < 0) {
	      i++;
	    } 
	    i2 = shell->Myz->val[i]-1;            
	  } else {            
	    i2 = shell->Myz->val[i];
	    i++;
	    while (shell->Myz->val[i] < 0) {
	      i++;
	    } 
	    i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
	  for (i = i1; i != i2; i += cxt->dx) {

	    // shear
	    p.x = shell->voxel[i].x;
	    if (cxt->xmin <= p.x && p.x <= cxt->xmax) {        	   
	      q.x = p.x - c.x;
	      q.y = p.y - c.y;
	      q.z = p.z - c.z; 

	      u = (int) (q.x + cxt->Su[p.z]); 
	      v = (int) (q.y + cxt->Sv[p.z]); 

	      is = u + ut + shear->tbv[v + vt];

	      if (shear->val[is] > 0.05) {
	      
		// normal
		i_p = i;

		if (shell->voxel[i_p].visible) {

		  l = shell->voxel[i_p].obj;

		  if (l) {

		    n = shell->voxel[i_p].normal;

		    cos_a = viewer.x * shell->normaltable[n].x +\
		      viewer.y * shell->normaltable[n].y +\
		      viewer.z * shell->normaltable[n].z;
		    
		    if (cos_a > 0) {
		      
		      // warp
		      uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		      
		      vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		      
		      iw = warp->tbv[vw + d.y] + uw + d.x;
		      
		      ww = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z;
		      
		      w = ww + wt;k = cxt->depth - w;

		      if (cxt->zbuff->dist[iw] > k) {
		      
			// shading

			cos_2a = 2*cos_a*cos_a - 1.0;
		      
			idist = 1.0 - w/(float)cxt->depth;

			if (cos_2a < 0.) {
			  pow = 0.;
			  spec = 0.;
			} else {
			  pow = 1.;
			  for (j=0; j < cxt->obj[l].ns; j++) 
			    pow = pow * cos_2a;
			  spec = cxt->obj[l].spec * pow;
			}
		
			opac = nopac[shell->voxel[i_p].opac] * cxt->obj[l].opac;
			amb  = cxt->obj[l].amb;
			diff = cxt->obj[l].diff * cos_a;
		
			shading =  (amb + idist * (diff + spec));
			
			// splatting
			iw = warp->tbv[vw + d.y] + uw + d.x;		
			for (j=0; j < fprint->n; j++){		
			  iw_p = iw + fprint->dp[j];
			  if (warp->val[iw_p] > .05) {
			    if (cxt->zbuff->dist[iw_p] > k) {
			      alpha = cxt->footprint->val[j] * opac;
			      AccVoxelColor(cimg,cxt,iw_p,shading,warp->val[iw_p]*alpha,l);
			      warp->val[iw_p] *= (1.0-alpha);
			      if (cxt->zbuff->voxel[iw_p] == NIL) {
				cxt->zbuff->voxel[iw_p] = i_p;
				cxt->zbuff->object[iw_p] = l;
				cxt->zbuff->dist[iw_p] = k;
			      }
			    }
			  }
			}	      
			shear->val[is]=warp->val[iw];
		      } 
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    }
    break;
      
  default: 
    Error(MSG1,"CSWShellRenderingCutPlane");
    break;
  }
  DestroyImage(&img);  
  DestroyImage(&tmp);
  DestroyFBuffer(&shear);
  DestroyFBuffer(&warp);
  DestroyAdjPxl(&fprint);
  return(cimg);
}


CImage *CSWShellRenderingStereo(Shell *shell,Context *cxt, Curve *cs) {

  CImage *cimg = NULL;
  Image *r=NULL;
  Image *b=NULL;
  Image *g=NULL;
  
  cimg=(CImage*)calloc(1,sizeof(CImage));

  AddAngles(cxt,0.,-5.);
  r = SWShellRenderingCut(shell,cxt,cs);
  AddAngles(cxt,0.,10.);
  b = SWShellRenderingCut(shell,cxt,cs);
  AddAngles(cxt,0.,-5.);
  g = SWShellRenderingCut(shell,cxt,cs);

  cimg->C[1] = g;
  cimg->C[0] = r;//Or(r,cimg->C[1]);
  cimg->C[2] = b;

  //  DestroyImage(&r);
  //DestroyImage(&b); 
  return(cimg);
}



int GetShellXSize (Shell *shell) {
  return (shell->xsize);
}
int GetShellYSize (Shell *shell) {
  return (shell->ysize);
}
int GetShellZSize (Shell *shell) {
  return (shell->zsize);
}



int GetShellMaximum (Shell *shell) {

  Voxel v;
  int i,i1,i2;
  int imax=0;

  if (shell->scn) return (MaximumValue3(shell->scn));
  if (!shell->body) return 0;

  for (v.z = 0; v.z != shell->zsize; v.z ++) 
    for (v.y = 0; v.y != shell->ysize; v.y ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {
	  if (shell->voxel[i].visible)
	    imax = MAX(imax,shell->body[i].val);	  
	}        
      }
    }
  shell->maxval = imax;
  return(imax);
}

int GetShellMinimum (Shell *shell) {

  Voxel v;
  int i,i1,i2;
  int imin=INT_MAX;

  if (shell->scn) return (MinimumValue3(shell->scn));
  if (!shell->body) return 0;

  for (v.z = 0; v.z != shell->zsize; v.z ++) 
    for (v.y = 0; v.y != shell->ysize; v.y ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {
	  if (shell->voxel[i].visible)
	    imin = MIN(imin,shell->body[i].val);
	}        
      }
    }
  return(imin);
}

int ShellNObjects(Shell *shell) {

  int i;
  int buf[256];
  int n=0;

  for(i=0;i<256;i++) {
    buf[i] = 0;
  }
  for(i=0;i<shell->nvoxels;i++) {
    buf[shell->voxel[i].obj]++;
  }
  for(i=0;i<256;i++) {
    if(buf[i])
      n++;
  }
  shell->nobjs = (uchar)n;
  return n;
}


Curve *ShellObjHistogram(Shell *shell)
{
  int i,p,n,nbins;
  Curve *hist=NULL;
  nbins = 256;
  hist  = CreateCurve(nbins);
  n     = shell->nvoxels;
  
  for (p=0; p < n; p++) {
    hist->Y[shell->voxel[p].obj]++;
  }
  for (i=0; i < nbins; i++) 
    hist->X[i] = i;
  
  return(hist);
}


Curve *ShellHistogram(Shell *shell)
{
  int i,p,n,nbins;
  Curve *hist=NULL;
  
  if (!shell->body) {
    hist = ShellObjHistogram(shell);
    return(hist);
  }
  
  nbins = GetShellMaximum (shell) + 1;
  hist  = CreateCurve(nbins);
  n     = shell->nvoxels;
  
  for (p=0; p < n; p++) {
    hist->Y[shell->body[p].val]++;
  }
  for (i=0; i < nbins; i++) 
    hist->X[i] = i;

  return(hist);
}

Curve *ShellNormHistogram(Shell *shell) 
{
  int i,sum;
  Curve *hist=NULL,*nhist=NULL;

  hist  = ShellHistogram(shell);
  if (shell->body)
    sum   = shell->nvoxels;
  else 
    sum   = shell->nobjs;
  nhist = CreateCurve(hist->n);
  for (i=0; i < nhist->n;i++){
    nhist->Y[i] = hist->Y[i]/sum;
    nhist->X[i] = hist->X[i];
  }

  DestroyCurve(&hist);

  return(nhist);
}

Curve *ShellGradientHistogram(Shell *shell)
{
  int i,p,n,nbins;
  Curve *hist=NULL;
  
  if (!shell->body) {
    hist = ShellObjHistogram(shell);
    return(hist);
  }
  
  nbins = GetShellMaximum (shell) + 1;
  hist  = CreateCurve(nbins);
  n     = shell->nvoxels;
  
  for (p=0; p < n; p++) {
    hist->Y[shell->body[p].normalmag]++;
  }
  for (i=0; i < nbins; i++) 
    hist->X[i] = i;

  return(hist);
}

Image *GetShellXSlice (Shell *shell, int x) {

  Voxel v;
  int i,i1,i2,j;
  Image *img= NULL;

  img = CreateImage(shell->ysize,shell->zsize);
  v.x = x;
  for (v.z = 0; v.z != shell->zsize; v.z ++) {
    i = shell->Mzx->tbrow[v.x] + v.z;     
    if (shell->Mzx->val[i] >= 0) {	
      i1 = shell->Mzx->val[i];
      i++;
      while (shell->Mzx->val[i] < 0) {
	i++;
      } 
      i2 = shell->Mzx->val[i];
      for (i = i1; i != i2; i++) {
	v.y = shell->pointer[i].y;
	j = img->tbrow[v.z] + v.y;
	if (shell->voxel[shell->pointer[i].i].visible) {
	  img->val[j] = shell->voxel[shell->pointer[i].i].obj;
	} else {
	  img->val[j] = 256; // > 255 = invisible
	}
      }        
    }
  }
  return(img);
}


Image *GetShellYSlice (Shell *shell, int y) {

  Voxel v;
  int i,i1,i2,j;
  Image *img= NULL;

  img = CreateImage(shell->xsize,shell->zsize);
  v.y = y;
  for (v.z = 0; v.z != shell->zsize; v.z ++) {
    i = shell->Myz->tbrow[v.z] + v.y;     
    if (shell->Myz->val[i] >= 0) {	
      i1 = shell->Myz->val[i];
      i++;
      while (shell->Myz->val[i] < 0) {
	i++;
      } 
      i2 = shell->Myz->val[i];
      for (i = i1; i != i2; i++) {
	v.x = shell->voxel[i].x;
	j = img->tbrow[v.z] + v.x;	  
	if (shell->voxel[i].visible) {
	  img->val[j] = shell->voxel[i].obj;
	} else {
	  img->val[j] = 256; // > 255 = invisible
	}
      }        
    }
  }
  return(img);
}

Image *GetShellZSlice (Shell *shell, int z) {

  Voxel v;
  int i,i1,i2,j;
  Image *img= NULL;

  img = CreateImage(shell->xsize,shell->ysize);

  v.z = z;
  for (v.y = 0; v.y != shell->ysize; v.y ++) {
    i = shell->Myz->tbrow[v.z] + v.y;     
    if (shell->Myz->val[i] >= 0) {	
      i1 = shell->Myz->val[i];
      i++;
      while (shell->Myz->val[i] < 0) {
	i++;
      } 
      i2 = shell->Myz->val[i];
      for (i = i1; i != i2; i++) {
	v.x = shell->voxel[i].x;
	j = img->tbrow[v.y] + v.x;
	if (shell->voxel[i].visible) {
	  img->val[j] = shell->voxel[i].obj;
	} else {
	  img->val[j] = 256; // > 255 = invisible
	}
      }        
    }
  }
  return(img);
}


Image *GetBodyShellXSlice (Shell *shell, int x) {

  Voxel v;
  int i,i1,i2,j;
  Image *img= NULL;

  img = CreateImage(shell->ysize,shell->zsize);
  if (shell->body != NULL) {
    v.x = x;
    for (v.z = 0; v.z != shell->zsize; v.z ++) {
      i = shell->Mzx->tbrow[v.x] + v.z;     
      if (shell->Mzx->val[i] >= 0) {	
	i1 = shell->Mzx->val[i];
	i++;
	while (shell->Mzx->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Mzx->val[i];
	for (i = i1; i != i2; i++) {
	  //	  if (shell->voxel[shell->pointer[i].i].visible) {
	  v.y = shell->pointer[i].y;
	  j = img->tbrow[v.z] + v.y;
	  img->val[j] = shell->body[shell->pointer[i].i].val * shell->voxel[shell->pointer[i].i].opac/255.;
	  //	  }
	}
      }
    }
  }
  return(img);
}


Image *GetBodyShellYSlice (Shell *shell, int y) {

  Voxel v;
  int i,i1,i2,j;
  Image *img= NULL;

  img = CreateImage(shell->xsize,shell->zsize);
  if (shell->body != NULL) {
    v.y = y;
    for (v.z = 0; v.z != shell->zsize; v.z ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {	  
	  //if (shell->voxel[i].visible) {
	  v.x = shell->voxel[i].x;
	  j = img->tbrow[v.z] + v.x;
	  img->val[j] = shell->body[i].val * shell->voxel[i].opac/255.;
	  //}
	}        
      }
    }
  }
  return(img);
}

Image *GetBodyShellZSlice (Shell *shell, int z) {

  Voxel v;
  int i,i1,i2,j;
  Image *img= NULL;

  img = CreateImage(shell->xsize,shell->ysize);
  if (shell->body != NULL) {
    v.z = z;
    for (v.y = 0; v.y != shell->ysize; v.y ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {	  
	  //if (shell->voxel[i].visible) {
	  v.x = shell->voxel[i].x;
	  j = img->tbrow[v.y] + v.x;
	  img->val[j] = shell->body[i].val * shell->voxel[i].opac/255.;
	  //}
	}        
      }
    }
  }
  return(img);
}

void SetObjectVisibility (Shell *shell, int obj, int visible)    
{

  Voxel v;
  int i,i1,i2;

  for (v.z = 0; v.z != shell->zsize; v.z ++) 
    for (v.y = 0; v.y != shell->ysize; v.y ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {	  
	  if (shell->voxel[i].obj == obj)
	    shell->voxel[i].visible = visible; 
	}        
      }
    }
}

void SetBodyShellVisibility (Shell *shell, int lower, int higher)    
{

  Voxel v;
  int i,i1,i2;
  
  if (shell->body)
    for (v.z = 0; v.z != shell->zsize; v.z ++) 
      for (v.y = 0; v.y != shell->ysize; v.y ++) {
        i = shell->Myz->tbrow[v.z] + v.y;     
        if (shell->Myz->val[i] >= 0) {	
	  i1 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Myz->val[i];
	  for (i = i1; i != i2; i++) {	  
	    if (shell->body[i].val >= lower && shell->body[i].val <= higher)
	      shell->voxel[i].visible = 1;
	    else 
	      shell->voxel[i].visible = 0;            
	  }        
	}
      }
}



