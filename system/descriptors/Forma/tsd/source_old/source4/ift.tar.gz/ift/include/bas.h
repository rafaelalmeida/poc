#ifndef _BAS_H_
#define _BAS_H_

#include "curve.h"
#include "image.h"
#include "comptime.h"
#include "geometry.h" //vector
#include "descriptor.h" //Image2Curve

typedef struct{
  int length;   // length of the boundary
  int *X;       // X values of each boundary point from 0 to length-1  
  int *Y;       // Y values of each boundary point from 0 to length-1
} boundary_type;

typedef struct{
  int length;   // length of the boundary
  int *mean;    // mean value BAS function
  int *second;  
  int *third;
} representation_type;

Curve *BAS(Image *in);
Curve *MyBAS(Image *bin);
double OCS(FeatureVector1D *c1, FeatureVector1D *c2);

#endif
