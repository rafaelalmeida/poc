#ifndef _CSS_H_
#define _CSS_H_

#include "curve.h"
#include "image.h"
#include "comptime.h"
#include "descriptor.h" //Image2Curve

Curve *CSS(Image *bin);


#endif
