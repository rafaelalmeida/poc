#ifndef _INTERPOLATION_H_
#define _INTERPOLATION_H_

#include "image.h"
#include "common.h"
#include "geometry.h"

int valueInterpol(Point p, Image *img);


#endif
