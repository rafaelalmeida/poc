#ifndef _ANNSCN_H_
#define _ANNSCN_H_

#include "scene.h"
#include "adjacency3.h"
#include "set.h"

typedef struct _annscn {
  Scene *scn;
  Scene *cost;
  Scene *pred;  
  Scene *label;
  Set   *seed;
} AnnScn;

Scene  *CreateMapScene(Scene *mainscn);
void    DestroyMapScene(Scene *scn);
AnnScn *Annotate3(Scene *scn);
void    DeAnnotate3(AnnScn **ascn);
void    AddSeed3(AnnScn *ascn, int voxel, int cost, int label, int pred);
int     FindRoot(Scene *pred, int t);

#endif
