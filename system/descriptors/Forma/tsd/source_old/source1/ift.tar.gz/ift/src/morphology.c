#include "morphology.h"
#include "geometry.h"
#include "queue.h"
#include "mathematics.h"
#include "heap.h"

Image *Dilate(Image *img, AdjRel *A)
{
  Image *fimg=NULL,*fdil=NULL,*dil=NULL;
  AdjPxl *N=NULL;
  int sz,p,q,max,i,x,y,po;

  sz  = FrameSize(A);
  fimg = AddFrame(img,sz,INT_MIN);
  fdil = CreateImage(fimg->ncols,fimg->nrows);
  N  = AdjPixels(fimg,A);
  for (y=0,po=sz+fimg->tbrow[sz]; y < img->nrows; y++, po=po+fimg->ncols) 
    for (x=0,p=po; x < img->ncols; x++,p++){
      max = INT_MIN;
      for (i=0; i < N->n; i++){
	q = p + N->dp[i];
	if (fimg->val[q] > max)
	  max = fimg->val[q];
      }
      fdil->val[p]=max;
    }

  dil = RemFrame(fdil,sz);
  DestroyImage(&fimg);
  DestroyImage(&fdil);
  DestroyAdjPxl(&N);

  return(dil);
}

Image *Erode(Image *img, AdjRel *A)
{
  Image *fimg=NULL,*fero=NULL,*ero=NULL;
  AdjPxl *N=NULL;
  int sz,p,q,min,i,x,y,po;

  sz  = FrameSize(A);
  fimg = AddFrame(img,sz,INT_MAX);
  fero = CreateImage(fimg->ncols,fimg->nrows);
  N  = AdjPixels(fimg,A);
  for (y=0,po=sz+fimg->tbrow[sz]; y < img->nrows; y++, po=po+fimg->ncols) 
    for (x=0,p=po; x < img->ncols; x++,p++){
      min = INT_MAX;
      for (i=0; i < N->n; i++){
	q = p + N->dp[i];
	if (fimg->val[q] < min)
	  min = fimg->val[q];
      }
      fero->val[p]=min;
    }

  ero = RemFrame(fero,sz);
  DestroyImage(&fimg);
  DestroyImage(&fero);
  DestroyAdjPxl(&N);

  return(ero);
}

Image *Open(Image *img, AdjRel *A)
{
  Image *open=NULL,*ero=NULL;

  ero  = Erode(img,A);
  open = Dilate(ero,A);
  DestroyImage(&ero);

  return(open);
}

Image *Close(Image *img, AdjRel *A)
{
  Image *close=NULL,*dil=NULL;

  dil   = Dilate(img,A);
  close = Erode(dil,A);
  DestroyImage(&dil);

  return(close);
}

Image *MorphGrad(Image *img, AdjRel *A)
{
  Image *dil=NULL,*ero=NULL,*grad=NULL;

  dil  = Dilate(img,A);
  ero  = Erode(img,A);
  grad = Diff(dil,ero);
  DestroyImage(&dil);
  DestroyImage(&ero);

  return(grad);
}

Image *AsfOC(Image *img, AdjRel *A)
{
  Image *open=NULL,*close=NULL;

  open  = Open(img,A);
  close = Close(open,A);
  DestroyImage(&open);

  return(close);
}

Image *AsfnOC(Image *img, int ntimes)
{
  Image *asfoc=NULL,*aux=NULL; 
  AdjRel *A;
  int i;
  float r=1.0;
  
  aux = CopyImage(img);
  for (i=1; i <= ntimes; i++){    
    A = Circular(r);
    asfoc = AsfOC(aux,A);
    DestroyAdjRel(&A);
    DestroyImage(&aux);
    aux = asfoc;
    r += 0.5;
  }
  
  if (aux != asfoc)
    DestroyImage(&aux);

  return(asfoc);
}

Image *AsfOCO(Image *img, AdjRel *A)
{
  Image *open=NULL,*close=NULL;

  open  = Open(img,A);
  close = Close(open,A);
  DestroyImage(&open);
  open  = Open(close,A);
  DestroyImage(&close);

  return(open);
}

Image *AsfnOCO(Image *img, int ntimes)
{
  Image *asfoco=NULL,*aux=NULL; 
  AdjRel *A;
  int i;
  float r=1.0;
  
  aux = CopyImage(img);
  for (i=1; i <= ntimes; i++){    
    A = Circular(r);
    asfoco = AsfOCO(aux,A);
    DestroyAdjRel(&A);
    DestroyImage(&aux);
    aux = asfoco;
    r += 0.5;
  }
  
  if (aux != asfoco)
    DestroyImage(&aux);

  return(asfoco);
}

Image *AsfCO(Image *img, AdjRel *A)
{
  Image *open=NULL,*close=NULL;

  close  = Close(img,A);
  open   = Open(close,A);
  DestroyImage(&close);

  return(open);
}

Image *AsfnCO(Image *img, int ntimes)
{
  Image *asfco=NULL,*aux=NULL; 
  AdjRel *A;
  int i;
  float r=1.0;
  
  aux = CopyImage(img);
  for (i=1; i <= ntimes; i++){    
    A = Circular(r);
    asfco = AsfCO(aux,A);
    DestroyAdjRel(&A);
    DestroyImage(&aux);
    aux = asfco;
    r += 0.5;
  }
  
  if (aux != asfco)
    DestroyImage(&aux);

  return(asfco);
}

Image *AsfCOC(Image *img, AdjRel *A)
{
  Image *open=NULL,*close=NULL;

  close  = Close(img,A);
  open   = Open(close,A);
  DestroyImage(&close);
  close  = Close(open,A);
  DestroyImage(&open);

  return(close);
}

Image *AsfnCOC(Image *img, int ntimes)
{
  Image *asfcoc=NULL,*aux=NULL; 
  AdjRel *A;
  int i;
  float r=1.0;
  
  aux = CopyImage(img);
  for (i=1; i <= ntimes; i++){    
    A = Circular(r);
    asfcoc = AsfCOC(aux,A);
    DestroyAdjRel(&A);
    DestroyImage(&aux);
    aux = asfcoc;
    r += 0.5;
  }
  
  if (aux != asfcoc)
    DestroyImage(&aux);

  return(asfcoc);
}

void iftBasins(AnnImg *aimg, AdjRel *A)
{
  Queue *Q=NULL;
  int i,p,q,tmp,Imax,n;
  Pixel u,v;

  n = aimg->img->ncols*aimg->img->nrows;
  Imax = MaximumValue(aimg->img);
  for (p=0; p < n; p++)
    if (aimg->cost->val[p] != INT_MAX)
      if (Imax < aimg->cost->val[p])
	Imax = aimg->cost->val[p];
  
  Q = CreateQueue(Imax+1,n);

  while (aimg->seed != NULL){
    p=RemoveSet(&(aimg->seed));
    InsertQueue(Q,aimg->cost->val[p],p);
  }

  while (!EmptyQueue(Q)) {
    p=RemoveQueue(Q);
    u.x = p%aimg->img->ncols;
    u.y = p/aimg->img->ncols;
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(aimg->img,v.x,v.y)){
	q = v.x + aimg->img->tbrow[v.y];
	if ((aimg->cost->val[p] < aimg->cost->val[q]) || 
	    (p == aimg->pred->val[q]))
	{ 
	  tmp = MAX(aimg->cost->val[p],aimg->img->val[q]);
	  if ((tmp < aimg->cost->val[q]) || 
	      (p == aimg->pred->val[q])     ) /* tmp == cost[q] =>
                                                 label[p] should
                                                 propagate because it
                                                 is the
                                                 predecessor. */
	  {	    
	    InsertQueue(Q,tmp,q);
	    aimg->cost->val[q]  = tmp;
	    aimg->pred->val[q]  = p;
	    aimg->label->val[q] = aimg->label->val[p];
	  } 
	}
      }
    }
  }
  DestroyQueue(&Q);

}

void iftDomes(AnnImg *aimg, AdjRel *A)
{
  Queue *Q=NULL;
  int i,p,q,tmp,Imax,n;
  Pixel u,v;

  n = aimg->img->ncols*aimg->img->nrows;
  Imax = MaximumValue(aimg->img);
  for (p=0; p < n; p++)
    if (aimg->cost->val[p] != INT_MAX){
      if (Imax < aimg->cost->val[p])
	Imax = aimg->cost->val[p];
    } else {
      aimg->cost->val[p] = INT_MIN;
    }


  Q = CreateQueue(Imax+1,n);

  while (aimg->seed != NULL){
    p=RemoveSet(&(aimg->seed));
    InsertQueue(Q,Imax-aimg->cost->val[p],p);
  }

  while (!EmptyQueue(Q)) {
    p=RemoveQueue(Q);
    u.x = p%aimg->img->ncols;
    u.y = p/aimg->img->ncols;
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(aimg->img,v.x,v.y)){
	q = v.x + aimg->img->tbrow[v.y];
	if ((aimg->cost->val[p] > aimg->cost->val[q])||
	    (p == aimg->pred->val[q])){ 
	  tmp = MIN(aimg->cost->val[p],aimg->img->val[q]);
	  if ((tmp > aimg->cost->val[q]) || 
	      (p == aimg->pred->val[q])     ) /* tmp == cost[q] =>
                                                 label[p] should
                                                 propagate because it
                                                 is the
                                                 predecessor. */
	  {
	    InsertQueue(Q,Imax-tmp,q);
	    aimg->cost->val[q]  = tmp;
	    aimg->pred->val[q]  = p;
	    aimg->label->val[q] = aimg->label->val[p];
	  } 
	}
      }
    }
  }
  
  DestroyQueue(&Q);

}
  
Image *HClose(Image *img, Image *seed, AdjRel *A, int H)
{
  Image *cost=NULL;
  Queue *Q=NULL;
  int i,p,q,Imax,n;
  Pixel u,v;
 
  Imax = MaximumValue(img);
  n    = img->ncols*img->nrows;
  cost = CopyImage(img);
  Q    = CreateQueue(Imax+1,n);
  for (p=0; p < n; p++){
    if (seed->val[p] > 0) {
      cost->val[p] = MIN(cost->val[p]+H,Imax);
      InsertQueue(Q,cost->val[p],p);
    } 
  }

  while (!EmptyQueue(Q)) {
    p=RemoveQueue(Q);
    u.x = p%img->ncols;
    u.y = p/img->ncols;
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(img,v.x,v.y)){
	q = v.x + img->tbrow[v.y];
	if (cost->val[p] > cost->val[q])
	  {
	    InsertQueue(Q,cost->val[p],q);
	    cost->val[q]  = cost->val[p];
	  }
      }
    }
  }

  DestroyQueue(&Q);
  return(cost);
}


Image *HOpen(Image *img, Image *seed, AdjRel *A, int H)
{
  Image *cost=NULL;
  Queue *Q=NULL;
  int i,p,q,Imax,n;
  Pixel u,v;
 
  Imax = MaximumValue(img);
  n    = img->ncols*img->nrows;
  cost = CopyImage(img);
  Q    = CreateQueue(Imax+1,n);
  for (p=0; p < n; p++){
    if (seed->val[p] > 0) {
      cost->val[p] = MAX(img->val[p]-H,0);
      InsertQueue(Q,Imax - cost->val[p],p);
    }
  }

  while (!EmptyQueue(Q)) {
    p=RemoveQueue(Q);
    u.x = p%img->ncols;
    u.y = p/img->ncols;
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(img,v.x,v.y)){
	q = v.x + img->tbrow[v.y];
	if (cost->val[p] < cost->val[q])
	  {
	    InsertQueue(Q,Imax - cost->val[p],q);
	    cost->val[q]  = cost->val[p];
	  }
	}
      }
    }
  

  DestroyQueue(&Q);

  return(cost);
}

Image *iftSupRec(AnnImg *aimg, AdjRel *A)
{
  iftBasins(aimg, A);
  return(CopyImage(aimg->cost));
}


Image *iftInfRec(AnnImg *aimg, AdjRel *A)
{
  iftDomes(aimg, A);
  return(CopyImage(aimg->cost));
}

Image *SupRec(Image *img, Image *marker, AdjRel *A)
{
  Image *fcost=NULL,*cost=NULL,*fimg=NULL;
  Queue *Q=NULL;
  int i,sz,p,q,tmp,n;
  AdjPxl *N=NULL;

  sz  = FrameSize(A);
  fimg = AddFrame(img,sz,INT_MIN);
  fcost = AddFrame(marker,sz,INT_MIN);
  N  = AdjPixels(fcost,A);
  n = fcost->ncols*fcost->nrows;
  Q = CreateQueue(MaximumValue(marker)+1,n);
  
  for(p = 0; p < n; p++)
    if (fcost->val[p] != INT_MIN){
      InsertQueue(Q,fcost->val[p],p);
    }

  while(!EmptyQueue(Q)) {
    p=RemoveQueue(Q);
    for (i=1; i < N->n; i++){
      q = p + N->dp[i];
      if (fcost->val[p] < fcost->val[q]){
	tmp = MAX(fcost->val[p],fimg->val[q]);
	if (tmp < fcost->val[q]){
	  UpdateQueue(Q,q,fcost->val[q],tmp);
	  fcost->val[q] = tmp;
	}
      }
    }
  }
  
  cost = RemFrame(fcost,sz);

  DestroyQueue(&Q);
  DestroyImage(&fimg);
  DestroyImage(&fcost);
  DestroyAdjPxl(&N);
  
  return(cost);
}

Image *InfRec(Image *img, Image *marker, AdjRel *A)
{
  Image *fcost=NULL,*cost=NULL,*fimg=NULL;
  Queue *Q=NULL;
  int i,sz,p,q,tmp,n,Imax;
  AdjPxl *N=NULL;

  sz  = FrameSize(A);
  fimg = AddFrame(img,sz,INT_MAX);
  fcost = AddFrame(marker,sz,INT_MAX);
  N  = AdjPixels(fcost,A);
  n = fcost->ncols*fcost->nrows;
  Imax = MaximumValue(img);
  Q = CreateQueue(Imax+1,n);
  
  for(p = 0; p < n; p++)
    if (fcost->val[p] != INT_MAX){
      InsertQueue(Q,Imax - fcost->val[p],p);
    }

  while(!EmptyQueue(Q)) {
    p=RemoveQueue(Q);
    for (i=1; i < N->n; i++){
      q = p + N->dp[i];
      if (fcost->val[p] > fcost->val[q]){
	tmp = MIN(fcost->val[p],fimg->val[q]);
	if (tmp > fcost->val[q]){
	  UpdateQueue(Q,q,Imax - fcost->val[q],Imax - tmp);
	  fcost->val[q] = tmp;
	}
      }
    }
  }
  
  cost  = RemFrame(fcost,sz);

  DestroyQueue(&Q);
  DestroyImage(&fimg);
  DestroyImage(&fcost);
  DestroyAdjPxl(&N);
  
  return(cost);
}

Image *SupRecHeap(Image *img, Image *marker, AdjRel *A)
{
  Image *fcost=NULL,*cost=NULL,*fimg=NULL;
  Heap *H=NULL;
  int i,sz,p,q,tmp,n;
  AdjPxl *N=NULL;

  sz  = FrameSize(A);
  fimg = AddFrame(img,sz,INT_MIN);
  fcost = AddFrame(marker,sz,INT_MIN);
  N  = AdjPixels(fcost,A);
  n = fcost->ncols*fcost->nrows;
  H = CreateHeap(n,fcost->val);
  
  for(i=0; i < n; i++)
    if (fcost->val[i]!=INT_MIN)
      InsertHeap(H,i);

  while(!HeapIsEmpty(H)) {
    RemoveHeap(H,&p);
    for (i=1; i < N->n; i++){
      q = p + N->dp[i];
      if (H->color[q] == GRAY){
	tmp = MAX(fcost->val[p],fimg->val[q]);
	if (tmp < fcost->val[q]){
	  fcost->val[q] = tmp;
	  GoUp(H,H->pos[q]);
	}
      }
    }
  }
  
  cost = RemFrame(fcost,sz);

  DestroyHeap(&H);
  DestroyImage(&fimg);
  DestroyImage(&fcost);
  DestroyAdjPxl(&N);

  return(cost);
}

Image *RemDomes(Image *img)
{
  AdjRel *A=NULL;
  Image *marker=NULL,*oimg=NULL;
  int Imin,i,j,x,y;
  
  Imin  = MinimumValue(img);
  marker  = CreateImage(img->ncols,img->nrows);
  SetImage(marker,MAX(Imin-1,0));
  for (y=0; y < marker->nrows; y++) {
    i = marker->tbrow[y]; j = marker->ncols-1+marker->tbrow[y];
    marker->val[i] = img->val[i];
    marker->val[j] = img->val[j];
  }
  for (x=0; x < marker->ncols; x++) {
    i = x+marker->tbrow[0]; j = x+marker->tbrow[marker->nrows-1]; 
    marker->val[i] = img->val[i];
    marker->val[j] = img->val[j];
  }
  A     = Circular(1.0);
  oimg  = InfRec(img,marker,A);
  
  DestroyImage(&marker);
  DestroyAdjRel(&A);

  return(oimg);
}

Image *CloseHoles(Image *img)
{
  AdjRel *A=NULL;
  Image *marker=NULL,*cimg=NULL;
  int x,y,i,j,Imax;
  
  Imax   = MaximumValue(img);
  marker   = CreateImage(img->ncols,img->nrows);
  SetImage(marker,Imax+1);
  for (y=0; y < marker->nrows; y++) {
    i = marker->tbrow[y]; j = marker->ncols-1+marker->tbrow[y];
    marker->val[i] = img->val[i];
    marker->val[j] = img->val[j];
  }
  for (x=0; x < marker->ncols; x++) {
    i = x+marker->tbrow[0]; j = x+marker->tbrow[marker->nrows-1]; 
    marker->val[i] = img->val[i];
    marker->val[j] = img->val[j];
  }
  A      = Circular(1.0);
  cimg   = SupRec(img,marker,A);  
  DestroyImage(&marker);
  DestroyAdjRel(&A);

  return(cimg);
}

Image *OpenRec(Image *img, AdjRel *A)
{
  Image *open=NULL,*orec=NULL;
  AdjRel *A4;

  open = Open(img,A);
  A4   = Circular(1.0);
  orec = InfRec(img,open,A4);
  DestroyImage(&open);
  DestroyAdjRel(&A4);

  return(orec);
}

Image *CloseRec(Image *img, AdjRel *A)
{
  Image *close=NULL,*crec=NULL;
  AdjRel *A4;

  close = Close(img,A);
  A4    = Circular(1.0);
  crec  = SupRec(img,close,A4);
  DestroyImage(&close);
  DestroyAdjRel(&A4);

  return(crec);
}

Image *Leveling(Image *img1, Image *img2)
{
  AdjRel *A=NULL;
  Image *dil,*ero,*and,*or,*infrec,*suprec;

  A      = Circular(1.0);
  dil    = Dilate(img2,A);
  and    = And(img1,dil);
  infrec = InfRec(img1,and,A);

  ero    = Erode(img2,A);
  or     = Or(ero,infrec);
  suprec = SupRec(img1,or,A);

  DestroyImage(&dil);
  DestroyImage(&ero);
  DestroyImage(&and);
  DestroyImage(&or);
  DestroyImage(&infrec);
  DestroyAdjRel(&A);

  return(suprec);
}

Image *AsfOCRec(Image *img, AdjRel *A)
{
  Image *open=NULL,*close=NULL;

  open  = OpenRec(img,A);
  close = CloseRec(open,A);
  DestroyImage(&open);

  return(close);
}

Image *AsfnOCRec(Image *img, int ntimes)
{
  Image *asfoc=NULL,*aux=NULL; 
  AdjRel *A;
  int i;
  float r=1.0;
  
  aux = CopyImage(img);
  for (i=1; i <= ntimes; i++){    
    A = Circular(r);
    asfoc = AsfOCRec(aux,A);
    DestroyAdjRel(&A);
    DestroyImage(&aux);
    aux = asfoc;
    r += 0.5;
  }
  
  if (aux != asfoc)
    DestroyImage(&aux);

  return(asfoc);
}

Image *AsfOCORec(Image *img, AdjRel *A)
{
  Image *open=NULL,*close=NULL;

  open  = OpenRec(img,A);
  close = CloseRec(open,A);
  DestroyImage(&open);
  open  = OpenRec(close,A);
  DestroyImage(&close);

  return(open);
}

Image *AsfnOCORec(Image *img, int ntimes)
{
  Image *asfoco=NULL,*aux=NULL; 
  AdjRel *A;
  int i;
  float r=1.0;
  
  aux = CopyImage(img);
  for (i=1; i <= ntimes; i++){    
    A = Circular(r);
    asfoco = AsfOCORec(aux,A);
    DestroyAdjRel(&A);
    DestroyImage(&aux);
    aux = asfoco;
    r += 0.5;
  }
  
  if (aux != asfoco)
    DestroyImage(&aux);

  return(asfoco);
}

Image *AsfCORec(Image *img, AdjRel *A)
{
  Image *open=NULL,*close=NULL;

  close  = CloseRec(img,A);
  open   = OpenRec(close,A);
  DestroyImage(&close);

  return(open);
}

Image *AsfnCORec(Image *img, int ntimes)
{
  Image *asfco=NULL,*aux=NULL; 
  AdjRel *A;
  int i;
  float r=1.0;
  
  aux = CopyImage(img);
  for (i=1; i <= ntimes; i++){    
    A = Circular(r);
    asfco = AsfCORec(aux,A);
    DestroyAdjRel(&A);
    DestroyImage(&aux);
    aux = asfco;
    r += 0.5;
  }
  
  if (aux != asfco)
    DestroyImage(&aux);

  return(asfco);
}

Image *AsfCOCRec(Image *img, AdjRel *A)
{
  Image *open=NULL,*close=NULL;

  close  = CloseRec(img,A);
  open   = OpenRec(close,A);
  DestroyImage(&close);
  close  = CloseRec(open,A);
  DestroyImage(&open);

  return(close);
}

Image *AsfnCOCRec(Image *img, int ntimes)
{
  Image *asfcoc=NULL,*aux=NULL; 
  AdjRel *A;
  int i;
  float r=1.0;
  
  aux = CopyImage(img);
  for (i=1; i <= ntimes; i++){    
    A = Circular(r);
    asfcoc = AsfCOCRec(aux,A);
    DestroyAdjRel(&A);
    DestroyImage(&aux);
    aux = asfcoc;
    r += 0.5;
  }
  
  if (aux != asfcoc)
    DestroyImage(&aux);

  return(asfcoc);
}

Image *AreaClose(Image *img, int thres)
{
  Image  *area=NULL,*cost=NULL,*level=NULL,*pred=NULL,*root=NULL;           
  AdjRel *A=NULL;
  Queue  *Q=NULL;
  int i,p,q,r=0,s,n,Imax,tmp;
  Pixel u,v;

  A        = Circular(1.0);
  Imax     = MaximumValue(img);
  area     = CreateImage(img->ncols,img->nrows);
  pred     = CreateImage(img->ncols,img->nrows);
  root     = CreateImage(img->ncols,img->nrows);
  level    = CopyImage(img);
  cost     = CreateImage(img->ncols,img->nrows);
  n        = img->ncols*img->nrows;
  Q        = CreateQueue(Imax+2,n);

  for (p=0; p < n; p++){
    pred->val[p]  = p;
    root->val[p]  = p;
    cost->val[p]  = img->val[p]+1;
    InsertQueue(Q,cost->val[p],p);
  }
  
  /* Find level for local superior reconstruction */
  
  while (!EmptyQueue(Q)){
    p=RemoveQueue(Q);

    /* Find and update root pixel, level and area */    

    r  = SeedComp(root,p);

    if ((area->val[r]<=thres)&&(level->val[r] < img->val[p]))
      level->val[r] = img->val[p];
    area->val[r]++;

    /* Visit the adjacent pixels */

    u.x = p%img->ncols;
    u.y = p/img->ncols;
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(img,v.x,v.y)){
	q = v.x + img->tbrow[v.y];
	if (cost->val[p] < cost->val[q]){
	  tmp = MAX(cost->val[p],img->val[q]);
	  if (tmp < cost->val[q]){
	    UpdateQueue(Q,q,cost->val[q],tmp);
	    cost->val[q] = tmp;
	    root->val[q] = root->val[p];
	    pred->val[q] = pred->val[p];	    	    
	  }
	}else { /* Merge two basins */
	  s = SeedComp(root,q);	  
	  if (r != s) {	
	    if ((area->val[s] <= thres)&&(level->val[s]<img->val[p]))
	      level->val[s] = img->val[p];
	    if (area->val[r] < area->val[s]){
	      tmp = r;
	      r   = s;
	      s   = tmp;
	    }    
	    root->val[s] = r;	    
	    area->val[r] += area->val[s];
	    if ((pred->val[p]==p)&&(pred->val[q]==q)){
	      pred->val[s]  = r;
	    }
	  }
	}
      }
    }
  }

  /* Compute local superior reconstruction */

  ResetQueue(Q);

  for (p=0; p < n; p++) 
    if (pred->val[p]==p)
      InsertQueue(Q,level->val[p],p);

  while (!EmptyQueue(Q)) {
    p=RemoveQueue(Q);
    u.x = p%img->ncols;
    u.y = p/img->ncols;
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(img,v.x,v.y)){
	q = v.x + img->tbrow[v.y];
	if (level->val[p] > level->val[q])
	  {
	    InsertQueue(Q,level->val[p],q);
	    level->val[q]  = level->val[p];
	  }		  
      }
    }
  }
  
  DestroyQueue(&Q);
  DestroyAdjRel(&A);
  DestroyImage(&area);    
  DestroyImage(&cost);    
  DestroyImage(&pred);    
  DestroyImage(&root);    

  return(level);
}

Image *AreaOpen(Image *img, int thres)
{
  Image  *area=NULL,*cost=NULL,*level=NULL,*pred=NULL,*root=NULL;           
  AdjRel *A=NULL;
  Queue  *Q=NULL;
  int i,p,q,r,s,n,Imax,tmp;
  Pixel u,v;


  A        = Circular(1.0);
  Imax     = MaximumValue(img);
  area     = CreateImage(img->ncols,img->nrows);
  pred     = CreateImage(img->ncols,img->nrows);
  root     = CreateImage(img->ncols,img->nrows);
  level    = CopyImage(img);
  cost     = CreateImage(img->ncols,img->nrows);
  n        = img->ncols*img->nrows;
  Q        = CreateQueue(Imax+2,n);

  for (p=0; p < n; p++){
    pred->val[p]  = p;
    root->val[p]  = p;
    cost->val[p]  = Imax + 1 - img->val[p];
    InsertQueue(Q,cost->val[p],p);
  }
  
  /* Find level for local inferior reconstruction */
  
  while (!EmptyQueue(Q)){
    p=RemoveQueue(Q);

    /* Find and update root pixel, level and area */    

    r  = SeedComp(root,p);
    
    if ((area->val[r]<=thres)&&(level->val[r] > img->val[p]))
      level->val[r] = img->val[p];
    area->val[r]++;
  
    /* Visit the adjacent pixels */

    u.x = p%img->ncols;
    u.y = p/img->ncols;
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(img,v.x,v.y)){
	q = v.x + img->tbrow[v.y];
	if (cost->val[p] < cost->val[q]){
	  tmp = MAX(cost->val[p],Imax-img->val[q]);
	  if (tmp < cost->val[q]){
	    UpdateQueue(Q,q,cost->val[q],tmp);
	    cost->val[q] = tmp;
	    root->val[q] = root->val[p];
	    pred->val[q] = root->val[p];	    	    
	  }
	}else { /* Merge two domes */
	  s = SeedComp(root,q);	  
	  if (r != s) {	
	    if ((area->val[s] <= thres)&&(level->val[s]>img->val[p]))
	      level->val[s] = img->val[p];
	    if (area->val[r] < area->val[s]){
	      tmp = r;
	      r   = s;
	      s   = tmp;
	    }    
	    root->val[s] = r;	    
	    area->val[r] += area->val[s];
	    if ((pred->val[p]==p)&&(pred->val[q]==q)){
	      pred->val[s]  = r;
	    } 
	  }
	}
      }
    }
  }
     
  /* Compute local inferior reconstruction */
 
  ResetQueue(Q);
  for (p=0; p < n; p++) 
    if (pred->val[p]==p){
      InsertQueue(Q,Imax-level->val[p],p);
    }

  while (!EmptyQueue(Q)) {
    p=RemoveQueue(Q);
    u.x = p%img->ncols;
    u.y = p/img->ncols;
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(img,v.x,v.y)){
	q = v.x + img->tbrow[v.y];
	if (level->val[p] < level->val[q])
	  {
	    InsertQueue(Q,Imax-level->val[p],q);
	    level->val[q]  = level->val[p];
	  }
      }
    }
  }

  DestroyQueue(&Q);
  DestroyAdjRel(&A);
  DestroyImage(&area);    
  DestroyImage(&cost);    
  DestroyImage(&pred);    
  DestroyImage(&root);    

  return(level);
}

/* It assumes that the next operation is a dilation, but it may be an
   erosion */

Image *DilateBin(Image *bin, Set **seed, float radius)
{
  Image *cost=NULL,*Dx=NULL,*Dy=NULL,*ero=NULL,*boundr=NULL;
  Queue *Q=NULL;
  int i,p,q,n,sz;
  Pixel u,v;
  int *sq=NULL,tmp=INT_MAX,dx,dy;
  float dist;
  AdjRel *A=NULL;
  Image *dil=NULL;

  /* Compute seeds */
  
  if (*seed == NULL) {
    A      = Circular(1.0);
    ero    = Erode(bin,A);
    boundr = Diff(bin,ero);
    DestroyImage(&ero);
    DestroyAdjRel(&A);
    n    = boundr->ncols*boundr->nrows;
    for (p=0; p < n; p++)
      if (boundr->val[p]==1){
	InsertSet(seed,p);
      }
    DestroyImage(&boundr);    
  }

  /* Dilate image */

  dil  = CopyImage(bin);  
  dist = (radius*radius);
  A  = Circular(1.5);
  n  = MAX(dil->ncols,dil->nrows);
  sq = AllocIntArray(n);
  for (i=0; i < n; i++) 
    sq[i]=i*i;

  cost = CreateImage(dil->ncols,dil->nrows);
  Dx   = CreateImage(dil->ncols,dil->nrows);
  Dy   = CreateImage(dil->ncols,dil->nrows);
  n    = dil->ncols*dil->nrows;
  sz   = FrameSize(A);
  Q    = CreateQueue(2*sz*(sz+dil->ncols+dil->nrows),n);
  SetImage(cost,INT_MAX);

  while (*seed != NULL){
    p=RemoveSet(seed);
    cost->val[p]=0;
    InsertQueue(Q,cost->val[p]%Q->C.nbuckets,p);
  }

  while(!EmptyQueue(Q)) {
    p=RemoveQueue(Q);
    if (cost->val[p] <= dist){

      dil->val[p] = 1;

      /* Seeds for dilation, if we wanted to compute a sequence of dilations 

      if (((sq[Dx->val[p]+1]+sq[Dy->val[p]]) > dist)||
	  ((sq[Dx->val[p]]+sq[Dy->val[p]+1]) > dist)){
	InsertSet(seed,p);
      }

      */

      u.x = p%dil->ncols;
      u.y = p/dil->ncols;
      for (i=1; i < A->n; i++){
	v.x = u.x + A->dx[i];
	v.y = u.y + A->dy[i];
	if (ValidPixel(dil,v.x,v.y)){
	  q = v.x + dil->tbrow[v.y];
	  if ((cost->val[p] < cost->val[q])&&(dil->val[q]==0)){
	    dx  = Dx->val[p] + abs(v.x-u.x);
	    dy  = Dy->val[p] + abs(v.y-u.y);
	    tmp = sq[dx] + sq[dy];
	    if (tmp < cost->val[q]){
	      if (cost->val[q] == INT_MAX)
		InsertQueue(Q,tmp%Q->C.nbuckets,q);
	      else
		UpdateQueue(Q,q,cost->val[q]%Q->C.nbuckets,tmp%Q->C.nbuckets);
	      cost->val[q]  = tmp;
	      Dx->val[q] = dx;
	      Dy->val[q] = dy;
	    }
	  }
	}
      }
    } else { /* Seeds for erosion */
      InsertSet(seed,p);
    }
  }

  free(sq);
  DestroyQueue(&Q);
  DestroyImage(&Dx);
  DestroyImage(&Dy);
  DestroyImage(&cost);
  DestroyAdjRel(&A);

  return(dil);
}

/* It assumes that the next operation is never an erosion, but it may
   be a dilation. */

Image *ErodeBin(Image *bin, Set **seed, float radius)
{
  Image *ero=NULL,*boundr=NULL,*dil=NULL;
  Pixel u,v;
  Image *cost=NULL,*Dx=NULL,*Dy=NULL;
  Queue *Q=NULL;
  int i,p,q,n,sz;
  int *sq=NULL,tmp=INT_MAX,dx,dy;
  AdjRel *A=NULL;
  float dist;

  /* Compute seeds */
  
  if (*seed == NULL) {
    A      = Circular(1.0);
    dil    = Dilate(bin,A);
    boundr = Diff(dil,bin);
    DestroyImage(&dil);
    DestroyAdjRel(&A);
    n    = boundr->ncols*boundr->nrows;
    for (p=0; p < n; p++)
      if (boundr->val[p]==1){
	InsertSet(seed,p);
      }
    DestroyImage(&boundr);    
  }

  /* Erode image */

  ero  = CopyImage(bin);  
  dist = (radius*radius);
  A  = Circular(1.5);
  n  = MAX(ero->ncols,ero->nrows);
  sq = AllocIntArray(n);
  for (i=0; i < n; i++) 
    sq[i]=i*i;

  Dx   = CreateImage(ero->ncols,ero->nrows);
  Dy   = CreateImage(ero->ncols,ero->nrows);
  cost = CreateImage(ero->ncols,ero->nrows);
  SetImage(cost,INT_MAX);
  n    = ero->ncols*ero->nrows;
  sz   = FrameSize(A);
  Q    = CreateQueue(2*sz*(sz+ero->ncols+ero->nrows),n);
  
  while (*seed != NULL){
    p=RemoveSet(seed);
    cost->val[p]=0;
    InsertQueue(Q,cost->val[p]%Q->C.nbuckets,p);
  }

  while(!EmptyQueue(Q)) {
    p=RemoveQueue(Q);
    if (cost->val[p] <= dist){

      ero->val[p] = 0;

      /* Seeds for erosion if we wanted to compute sequences of erosions

      if (((sq[Dx->val[p]+1]+sq[Dy->val[p]]) > dist)||
	  ((sq[Dx->val[p]]+sq[Dy->val[p]+1]) > dist)){
	InsertSet(seed,p);
      }

      */

      u.x = p%ero->ncols;
      u.y = p/ero->ncols;
      for (i=1; i < A->n; i++){
	v.x = u.x + A->dx[i];
	v.y = u.y + A->dy[i];
	if (ValidPixel(ero,v.x,v.y)){
	  q = v.x + ero->tbrow[v.y];
	  if ((cost->val[p] < cost->val[q])&&(ero->val[q]==1)){
	    dx  = Dx->val[p] + abs(v.x-u.x);
	    dy  = Dy->val[p] + abs(v.y-u.y);
	    tmp = sq[dx] + sq[dy];
	    if (tmp < cost->val[q]){
	      if (cost->val[q] == INT_MAX)
		InsertQueue(Q,tmp%Q->C.nbuckets,q);
	      else
		UpdateQueue(Q,q,cost->val[q]%Q->C.nbuckets,tmp%Q->C.nbuckets);
	      cost->val[q] = tmp;
	      Dx->val[q] = dx;
	      Dy->val[q] = dy;
	    }
	  }
	}
      }
    } else {  /* Seeds for dilation */
      InsertSet(seed,p);
    }
  }
  
  free(sq);
  DestroyQueue(&Q);
  DestroyImage(&Dx);
  DestroyImage(&Dy);
  DestroyImage(&cost);
  DestroyAdjRel(&A);

  return(ero);
}

Image *CloseBin(Image *bin, float radius)
{
  Image *close=NULL,*dil=NULL;
  Set *seed=NULL;

  dil   = DilateBin(bin,&seed,radius);
  close = ErodeBin(dil,&seed,radius);
  DestroyImage(&dil);
  DestroySet(&seed);

  return(close);
}

Image *OpenBin(Image *bin, float radius)
{
  Image *open=NULL,*ero=NULL;
  Set *seed=NULL;

  ero   = ErodeBin(bin,&seed,radius);
  open  = DilateBin(ero,&seed,radius);
  DestroyImage(&ero);
  DestroySet(&seed);

  return(open);
}

Image *AsfOCBin(Image *bin, float radius)
{
  Image *dil=NULL,*ero=NULL;
  Set *seed=NULL;

  ero = ErodeBin(bin,&seed,radius);
  dil = DilateBin(ero,&seed,2.0*radius);
  DestroyImage(&ero);
  ero = ErodeBin(dil,&seed,radius);
  DestroyImage(&dil);
  DestroySet(&seed);

  return(ero);
}















