#ifndef _ANALYSIS3_H_
#define _ANALYSIS3_H_


#include "annscn.h"
#include "genift3.h"
#include "adjacency3.h"

void iftDistTrans3(AnnScn *ascn, AdjRel3 *A);
void iftGenDistTrans3(AnnScn *ascn, AdjRel3 *A, PathCost3 Pcost);

#endif  







