#ifndef _RADIOMETRIC3_H_
#define _RADIOMETRIC3_H_

#include "scene.h"
#include "curve.h"

Curve *Histogram3(Scene *scn);
Curve *NormHistogram3(Scene *scn);
Curve *AccHistogram3(Scene *scn);
Curve *NormAccHistogram3(Scene *scn);
Scene *GaussStretch3(Scene *scn, float mean, float stdev);
Scene *LinearStretch3(Scene *scn, int f1, int f2, int g1, int g2);

#endif
