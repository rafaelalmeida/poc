#include "segmentation3.h"

void IncWater3(AnnScn *ascn, AdjRel3 *A)
{
  Queue *Q=NULL;
  int s,t,xysize,p,tmp,i;
  Voxel u,v;
  Scene *scn=ascn->scn;

  xysize = scn->xsize*scn->ysize;
  Q = CreateQueue(MaximumValue3(scn)+1,scn->xsize*scn->ysize*scn->zsize);

  while(ascn->seed != NULL) {
    t=RemoveSet(&(ascn->seed));
    InsertQueue(Q,ascn->cost[t],t);
  }

  while (!EmptyQueue(Q)) {
    s=RemoveQueue(Q);
    p   = s%xysize;
    u.x = p%scn->xsize;
    u.y = p/scn->xsize;
    u.z = s/xysize;

    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      v.z = u.z + A->dz[i];
      if (ValidVoxel(scn,v.x,v.y,v.z)){
	t = v.x + scn->tby[v.y] + scn->tbz[v.z];
	if ((ascn->cost[s] < ascn->cost[t])||(s == ascn->pred[t])){
	  tmp = MAX(ascn->cost[s],scn->data[t]);
	  if ((tmp < ascn->cost[t])||(s == ascn->pred[t])){
	    InsertQueue(Q,tmp,t);
	    ascn->cost[t] = tmp;
	    ascn->pred[t] = s;
	    ascn->label[t] = ascn->label[s];
	  }
	} 
      }
    }
  }

  DestroyQueue(&Q);
}

void DecWater3(AnnScn *ascn, AdjRel3 *A)
{
  Queue *Q=NULL;
  int s,t,xysize,p,tmp,i;
  Voxel u,v;
  Scene *scn=ascn->scn;

  xysize = scn->xsize*scn->ysize;
  Q = CreateQueue(MaximumValue3(scn)+1,scn->xsize*scn->ysize*scn->zsize);

  while(ascn->seed != NULL) {
    t=FindRoot(ascn->pred,RemoveSet(&(ascn->seed)));
    if (ascn->cost[t] != INT_MAX)
      InsertQueue(Q,0,t);
    ascn->cost[t]  = INT_MAX;
    ascn->pred[t]  = t;
    ascn->label[t] = 0;    
  }

  while (!EmptyQueue(Q)) {
    s=RemoveQueue(Q);
    
    p   = s%xysize;
    u.x = p%scn->xsize;
    u.y = p/scn->xsize;
    u.z = s/xysize;
    
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      v.z = u.z + A->dz[i];
      if (ValidVoxel(scn,v.x,v.y,v.z)){
	t = v.x + scn->tby[v.y] + scn->tbz[v.z];
	if (ascn->pred[t] == s){
	  ascn->cost[t]  = INT_MAX;
	  ascn->pred[t]  = t;
	  ascn->label[t] = 0;    
	  InsertQueue(Q,0,t);
	}else 
	  if (ascn->pred[t] != NIL)
	    InsertSet(&(ascn->seed),t);
      }
    }
  }

  while(ascn->seed != NULL) {
    t=RemoveSet(&(ascn->seed));
    if (ascn->pred[t] != t)
      InsertQueue(Q,ascn->cost[t],t);
  }

  Q->C.current = 0;

  while (!EmptyQueue(Q)) {
    s=RemoveQueue(Q);
    p   = s%xysize;
    u.x = p%scn->xsize;
    u.y = p/scn->xsize;
    u.z = s/xysize;

    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      v.z = u.z + A->dz[i];
      if (ValidVoxel(scn,v.x,v.y,v.z)){
	t = v.x + scn->tby[v.y] + scn->tbz[v.z];
	if (ascn->cost[s] < ascn->cost[t]){
	  tmp = MAX(ascn->cost[s],scn->data[t]);
	  if (tmp < ascn->cost[t]){
	    InsertQueue(Q,tmp,t);
	    ascn->cost[t] = tmp;
	    ascn->pred[t] = s;
	    ascn->label[t] = ascn->label[s];
	  }
	} 
      }
    }
  }

  DestroyQueue(&Q);
}

void IncFuzzCon3(AnnScn *ascn, AdjRel3 *A)
{
  Queue *Q=NULL;
  int s,t,xysize,p,tmp,i,w,Imax;
  Voxel u,v;
  Scene *scn=ascn->scn;
  char *color;
  uchar *W;
  float D;
  
  Imax = MaximumValue3(scn);
  D  = 10.0;
  D  *= 2.*D;
  W    = AllocUCharArray(Imax+1);
  for (i=0; i <= Imax; i++) 
    W[i] = (uchar)(255.*(1.0 - exp(-((float)i*i)/D)));

  xysize = scn->xsize*scn->ysize;
  Q = CreateQueue(256,scn->xsize*scn->ysize*scn->zsize);
  color = AllocCharArray(scn->xsize*scn->ysize*scn->zsize);

  while(ascn->seed != NULL) {
    t=RemoveSet(&(ascn->seed));
    InsertQueue(Q,ascn->cost[t],t);
    color[t] = GRAY;
  }

  while (!EmptyQueue(Q)) {
    s=RemoveQueue(Q);
    color[s]=BLACK;

    p   = s%xysize;
    u.x = p%scn->xsize;
    u.y = p/scn->xsize;
    u.z = s/xysize;

    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      v.z = u.z + A->dz[i];
      if (ValidVoxel(scn,v.x,v.y,v.z)){
	t = v.x + scn->tby[v.y] + scn->tbz[v.z];
	if (color[t] != BLACK){
	  w   = abs((int)scn->data[t]-(int)scn->data[s]);
	  tmp = MAX(ascn->cost[s],W[w]);
	  if ((tmp < ascn->cost[t])||(s == ascn->pred[t])){
	    if (color[t]==WHITE){
	      InsertQueue(Q,tmp,t);
	      color[t]=GRAY;
	    }else
	      UpdateQueue(Q,t,ascn->cost[t],tmp);
	    ascn->cost[t] = tmp;
	    ascn->pred[t] = s;
	    ascn->label[t] = ascn->label[s];
	  }
	} 
      }
    }
  }
  free(W);
  free(color);
  DestroyQueue(&Q);
}

void DecFuzzCon3(AnnScn *ascn, AdjRel3 *A)
{
  Queue *Q=NULL;
  int s,t,w,xysize,p,tmp,i,Imax;
  Voxel u,v;
  Scene *scn=ascn->scn;
  uchar *W;
  float D;
  
  Imax = MaximumValue3(scn);
  D  = 50.0;
  D  *= 2.*D;
  W    = AllocUCharArray(Imax+1);
  for (i=0; i <= Imax; i++) 
    W[i] = (uchar)(255.*(1.0 - exp(-((float)i*i)/D)));

  xysize = scn->xsize*scn->ysize;
  Q = CreateQueue(256,scn->xsize*scn->ysize*scn->zsize);

  while(ascn->seed != NULL) {
    t=FindRoot(ascn->pred,RemoveSet(&(ascn->seed)));
    if (ascn->cost[t] != INT_MAX)
      InsertQueue(Q,0,t);
    ascn->cost[t]  = INT_MAX;
    ascn->pred[t]  = t;
    ascn->label[t] = 0;    
  }

  while (!EmptyQueue(Q)) {
    s=RemoveQueue(Q);
    p   = s%xysize;
    u.x = p%scn->xsize;
    u.y = p/scn->xsize;
    u.z = s/xysize;
    
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      v.z = u.z + A->dz[i];
      if (ValidVoxel(scn,v.x,v.y,v.z)){
	t = v.x + scn->tby[v.y] + scn->tbz[v.z];
	if (ascn->pred[t] == s){
	  ascn->cost[t]  = INT_MAX;
	  ascn->pred[t]  = t;
	  ascn->label[t] = 0;    
	  InsertQueue(Q,0,t);
	}else 
	  if (ascn->pred[t] != NIL)
	    InsertSet(&(ascn->seed),t);
      }
    }
  }

  while(ascn->seed != NULL) {
    t=RemoveSet(&(ascn->seed));
    if (ascn->pred[t] != t){
      InsertQueue(Q,ascn->cost[t],t);
    }
  }

  Q->C.current = 0;

  while (!EmptyQueue(Q)) {
    s=RemoveQueue(Q);
    p   = s%xysize;
    u.x = p%scn->xsize;
    u.y = p/scn->xsize;
    u.z = s/xysize;

    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      v.z = u.z + A->dz[i];
      if (ValidVoxel(scn,v.x,v.y,v.z)){
	t = v.x + scn->tby[v.y] + scn->tbz[v.z];
	if (ascn->cost[s] < ascn->cost[t]){
	  w   = abs((int)scn->data[t]+(int)scn->data[s]);
	  tmp = MAX(ascn->cost[s],W[w]);
	  if (tmp < ascn->cost[t]){
	    if (ascn->cost[t]==INT_MAX)
	      InsertQueue(Q,tmp,t);
	    else
	      UpdateQueue(Q,t,ascn->cost[t],tmp);
	    ascn->cost[t] = tmp;
	    ascn->pred[t] = s;
	    ascn->label[t] = ascn->label[s];
	  }
	} 
      }
    }
  }
  free(W);
  DestroyQueue(&Q);
}

Scene *Threshold3(Scene *scn, int lower, int higher)
{
  Scene *bin=NULL;
  int p,n;

  bin = CreateScene(scn->xsize,scn->ysize,scn->zsize);
  bin->dx = scn->dx;
  bin->dy = scn->dy;
  bin->dz = scn->dz;
  n = scn->xsize*scn->ysize*scn->zsize;
  for (p=0; p < n; p++)
    if ((scn->data[p] >= lower)&&(scn->data[p] <= higher))
      bin->data[p]=1;
  return(bin);
}

