#ifndef _SHELL_H_
#define _SHELL_H_

#include "scene.h"
#include "image.h"
#include "context.h"
#include "geometry.h"
#include "shading.h"
#include "adjacency.h"
#include "curve.h"


typedef struct _fbuffer{
  float *val;
  int usize,vsize;
  int *tbv;
} FBuffer;

typedef struct _attrib {
  int x;
  float opac;
  int val;
  ushort normal;
  uchar obj;
} Attrib;

typedef struct _pattrib {
  int y;
  int i;
} PAttrib;


typedef struct _shell {
  Attrib *voxel;
  PAttrib *pointer;
  int xsize,ysize,zsize;
  int nvoxels;
  float dx,dy,dz;
  Image *Myz;
  Image *Mzx;
  Vector *normaltable;
} Shell;


Shell  *CreateShell (Scene *scn, Context *cxt);
Shell  *CreateShell2(Scene *scn,float *alpha,Context *cxt);
void    DestroyShell (Shell **shell);
int     GetPointer (Shell *shell, Voxel V);

Vector  GetVindNormal (Scene *scn, int Vind);
Vector  GetVoxelNormal (Scene *scn, Voxel v);
ushort  GetNormalIndex (Shell *shell, Vector V);
void    CreateNormalTable (Shell *shell);

FBuffer *CreateFBuffer(int usize, int vsize);
void     DestroyFBuffer(FBuffer **buff);
void     InitFBuffer(FBuffer *fbuff, float f);

Image   *SWShellRendering (Shell *shell,Context *cxt);
Image   *ShellRendering (Shell *shell,Context *cxt);
Image   *ISWShellRendering (Shell *shell,Context *cxt);



#endif








