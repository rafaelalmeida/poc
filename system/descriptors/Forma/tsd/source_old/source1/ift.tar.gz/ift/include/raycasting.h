#ifndef _RAYCAST_H_
#define _RAYCAST_H_

#include "ift.h"

Image    *SWRaycastAnnScn(AnnScn *ascn, Context *cxt);
Image    *RaycastAnnScn(AnnScn *ascn, Context *cxt);
Image    *BRaycastAnnScn(AnnScn *ascn, Context *cxt);
Image    *SWRaycastScene(Scene *scn, Context *cxt);
Image    *RaycastScene(Scene *scn, Context *cxt);
Image    *BRaycastScene(Scene *scn, Context *cxt);

#endif
