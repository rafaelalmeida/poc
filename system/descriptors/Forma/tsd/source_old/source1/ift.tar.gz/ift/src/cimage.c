#include "cimage.h"

CImage *CreateCImage(int ncols, int nrows)
{
  CImage *cimg=NULL;
  int i;

  cimg = (CImage *) calloc(1, sizeof(CImage));
  for (i=0; i < 3; i++) 
    cimg->C[i] = CreateImage(ncols,nrows);
  return(cimg);
}

void    DestroyCImage(CImage **cimg)
{
  CImage *tmp;
  int i;

  tmp = *cimg;
  if (tmp != NULL) {
    for (i=0; i < 3; i++) 
      DestroyImage(&(tmp->C[i]));
    free(tmp);
    *cimg = NULL;
  }
}

void    WriteCImage(CImage *cimg, char *filename)
{
  FILE *fp;
  int i,n;

  fp = fopen(filename,"w");
  fprintf(fp,"P6\n");
  fprintf(fp,"%d %d\n",cimg->C[0]->ncols,cimg->C[0]->nrows);
  fprintf(fp,"255\n"); 
  n = cimg->C[0]->ncols*cimg->C[0]->nrows;
  for (i=0; i < n; i++) {
    fputc(cimg->C[0]->val[i],fp);
    fputc(cimg->C[1]->val[i],fp);
    fputc(cimg->C[2]->val[i],fp);
  }
  fclose(fp); 
}

CImage *CopyCImage(CImage *cimg)
{
  CImage *imgc;
  int i;

  imgc = (CImage *) calloc(1,sizeof(CImage));
  if (imgc == NULL){
    Error(MSG1,"CopyCImage");
  }
  for (i=0; i<3; i++)
    imgc->C[i] = CopyImage(cimg->C[i]);
  return imgc;
}

CImage *CROI(CImage *cimg, int xl, int yl, int xr, int yr)
{
  CImage *croi=NULL;
  int i;

  if (ValidPixel(cimg->C[0],xl,yl)&&ValidPixel(cimg->C[0],xr,yr)&&
      (xl <= xr)&&(yl <= yr)) {
    croi = (CImage *) calloc(1,sizeof(CImage));
    if (croi == NULL){
      Error(MSG1,"CreateCImage");
    }
    for (i=0; i<3; i++)
      croi->C[i] = ROI(cimg->C[i], xl, yl, xr, yr);
  }
  return (croi);
}

CImage *CScale(CImage *cimg, float Sx, float Sy)
{
  CImage *scl=NULL;
  int i;

  scl = (CImage *) calloc(1,sizeof(CImage));
  if (scl == NULL){
    Error(MSG1,"CreateCImage");
  }
  for (i=0; i<3; i++)
    scl->C[i] = Scale(cimg->C[i], Sx, Sy);
  return (scl);
}

