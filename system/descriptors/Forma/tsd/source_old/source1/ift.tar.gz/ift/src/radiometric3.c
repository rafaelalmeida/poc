#include "radiometric3.h"

Curve *Histogram3(Scene *scn)
{
  int i, n, nbins;
  Curve *hist = NULL;

  nbins = MaximumValue3(scn)+1;
  hist = CreateCurve(nbins);
  n = scn->xsize * scn->ysize * scn->zsize;
  for (i = 0; i < n; i++)
    hist->Y[scn->data[i]]++;
  for (i = 0; i < nbins; i++)
    hist->X[i] = i;

  return (hist);
}

Curve *NormHistogram3(Scene *scn)
{
  int i, sum;
  Curve *nhist;

  nhist = Histogram3(scn);
  sum = scn->xsize * scn->ysize * scn->zsize;
  for (i = 0; i < nhist->n; i++)
    nhist->Y[i] /= sum;

  return (nhist);
}

Curve *AccHistogram3(Scene *scn)
{
  int i;
  Curve *ahist;

  ahist = Histogram3(scn);
  for (i = 1; i < ahist->n; i++)
    ahist->Y[i] += ahist->Y[i-1];

  return (ahist);
}

Curve *NormAccHistogram3(Scene *scn)
{
  int i, sum;
  Curve *ahist;

  ahist = Histogram3(scn);
  sum = scn->xsize * scn->ysize * scn->zsize;
  ahist->Y[0] /= sum;
  for (i = 1; i < ahist->n; i++)
    ahist->Y[i] = (ahist->Y[i-1] + ahist->Y[i]) / sum;

  return (ahist);
}


Scene *GaussStretch3(Scene *scn, float mean, float stdev)
{
  float *gauss=NULL,sq,var2;
  int i,Imax,n;
  Scene *gscn=NULL;

  Imax  = MaximumValue3(scn);
  gauss = AllocFloatArray(Imax+1);
  var2  = 2*stdev*stdev;
  for (i=0; i < Imax+1; i++){
    sq  = ((float)i-mean)*((float)i-mean);
    gauss[i]=(float)(Imax*exp(-sq/var2));
  }
  n     = scn->xsize*scn->ysize*scn->zsize;
  gscn     = CreateScene(scn->xsize,scn->ysize,scn->zsize);
  for (i=0; i < n; i++){
    gscn->data[i] = (int)(gauss[scn->data[i]]);
  }
  free(gauss);
  return(gscn);  
}

Scene *LinearStretch3(Scene *scn, int f1, int f2, int g1, int g2)
{
  Scene *sscn = NULL;
  int p, n;
  float a;

  sscn = CreateScene(scn->xsize, scn->ysize, scn->zsize);
  n = scn->xsize * scn->ysize * scn->zsize;

  if (f1 != f2)
    a = (float) ((g2-g1)/(f2-f1));
  else
    a = INT_MAX;

  for (p = 0; p < n; p++) {
    if (scn->data[p] < f1)
      sscn->data[p] = g1;
    else if ((scn->data[p] > f2) || (a == INT_MAX))
      sscn->data[p] = g2;
    else
      sscn->data[p] = (int)(a*(scn->data[p]-f1)+g1);
  }

  return (sscn);
}
