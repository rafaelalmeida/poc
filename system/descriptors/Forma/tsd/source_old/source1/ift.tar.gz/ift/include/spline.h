#ifndef _SPLINE_H_
#define _SPLINE_H_

#include "math.h"

typedef struct _spline{
  Pixel po[20];
  Voxel vo[20];
  float len[20];
  float total;
  int numpts;
} Spline;

Spline *CreateSpline();
void AddPoints(Spline *spline,int x,int y);
void MovePoint(Spline *spline,int x,int y,int pointnumber);
void DestroySpline(Spline **spline);
void DrawSpline(Scene *scn,Context *cxt,Plane *pl,Spline *spline,Image *img);
void Compute3DSpline(Scene *scn,Context *cxt,Plane *pl,Spline *spline);
void CloseSpline(Spline *spline);
Plane *NormalPlane(Scene *scn,Spline *spline,float alpha);
void DrawNormal(Scene *scn,Context *cxt,Plane *pl,Spline *spline,Image *img,float alpha);
float LengthSpline(Spline *spline,float alpha);

#endif
