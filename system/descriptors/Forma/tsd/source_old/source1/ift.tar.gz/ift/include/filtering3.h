#ifndef _FILTERING3_H_
#define _FILTERING3_H_

#include "adjacency3.h"
#include "scene.h"
#include "annscn.h"
#include "sort.h"

typedef struct _kernel3 {
  float *val;
  AdjRel3 *adj;
  int xsize,ysize,zsize;
} Kernel3;

Kernel3 *MakeKernel3(char *coefs);
Kernel3 *CreateKernel3(AdjRel3 *A);
Kernel3 *LinearKernel3(AdjRel3 *A);
Kernel3 *GaussianKernel3(AdjRel3 *A, float mean, float stddev);
void    DestroyKernel3(Kernel3 **K);
Scene  *LinearFilter3(Scene *scn, Kernel3 *K);
Scene  *MedianFilter3(Scene *scn, AdjRel3 *A);


/* ----------- IFT-based Operators ------------------- */



#endif
