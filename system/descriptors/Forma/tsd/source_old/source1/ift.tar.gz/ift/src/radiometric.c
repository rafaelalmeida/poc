#include "radiometric.h"

Curve *Histogram(Image *img)
{
  int i,p,n,nbins;
  Curve *hist=NULL;

  nbins = MaximumValue(img)+1;
  hist  = CreateCurve(nbins);
  n     = img->ncols*img->nrows;
  for (p=0; p < n; p++)
    hist->Y[img->val[p]]++;
  for (i=0; i < nbins; i++) 
    hist->X[i] = i;

  return(hist);
}

Curve *NormHistogram(Image *img) 
{
  int i,sum;
  Curve *hist=NULL,*nhist=NULL;

  hist  = Histogram(img);
  sum   = img->ncols*img->nrows;
  nhist = CreateCurve(hist->n);
  for (i=0; i < nhist->n;i++){
    nhist->Y[i] = hist->Y[i]/sum;
    nhist->X[i] = hist->X[i];
  }

  DestroyCurve(&hist);

  return(nhist);
}

Image *Probability(Image *img) 
{
  int p,n;
  Image *prob;
  Curve *nhist;

  n     = img->ncols*img->nrows;
  prob  = CreateImage(img->ncols,img->nrows);
  nhist = NormHistogram(img);
  for (p=0; p < n; p++)
      prob->val[p] = (int)(100*nhist->Y[img->val[p]]);

  DestroyCurve(&nhist);
  return(prob);
}

Curve *AccHistogram(Image *img)
{
  int i;
  Curve *hist=NULL,*ahist=NULL;

  hist = Histogram(img);
  ahist = CreateCurve(hist->n);
  ahist->X[0] = 0;
  ahist->Y[0] = hist->Y[0];
  for (i=1; i < ahist->n; i++){
    ahist->X[i] = i;
    ahist->Y[i] = ahist->Y[i-1] + hist->Y[i];
  }

  DestroyCurve(&hist);

  return(ahist);
}

Curve *NormAccHistogram(Image *img)
{
  int i,sum;
  Curve *ahist=NULL,*nahist=NULL;

  ahist  = AccHistogram(img);
  sum    = img->ncols*img->nrows;
  nahist = CreateCurve(ahist->n);
  for (i=0; i < nahist->n;i++){
    nahist->Y[i] = ahist->Y[i]/sum;
    nahist->X[i] = ahist->X[i];
  }
  DestroyCurve(&ahist);

  return(nahist);
}


Image *Equalize(Image *img)
{
  int p,n,Imax;
  Image *eimg=NULL;
  Curve *nhist;

  nhist = NormAccHistogram(img);
  eimg  = CreateImage(img->ncols,img->nrows);
  n     = img->ncols*img->nrows;
  Imax  = MaximumValue(img);

  if (Imax < 255) 
    Imax = 255;
  else
    if (Imax < 65535)
      Imax = 65535;

  for (p=0; p < n; p++)
    eimg->val[p] = (int)(Imax*nhist->Y[img->val[p]]);

  DestroyCurve(&nhist);

  return(eimg);
}

Image *MatchHistogram(Image *img, Image *des)
{
  int i,p,n,Imax,Dmax,prev,next;
  Image *simg=NULL,*eimg=NULL,*mimg=NULL;
  Curve *nhist=NULL,*ihist=NULL;
  double step,val;

  Imax  = MaximumValue(img);    
  Dmax  = MaximumValue(des);      
  if (Imax != Dmax){
    simg = LinearStretch(img,0,Imax,0,Dmax);    
    eimg = Equalize(simg);
    DestroyImage(&simg);
  } else {
    eimg = Equalize(img);
  }

  nhist = NormAccHistogram(des);
  for (i=0; i < nhist->n; i++) 
    nhist->Y[i] = Dmax*nhist->Y[i]; 

  ihist = CreateCurve(Dmax+1);
  for (i=0; i < ihist->n; i++) 
    ihist->Y[(int)nhist->Y[i]] = i; 

  for (i=0; i < ihist->n; i++)                                    
    if ((ihist->Y[i] == 0.0)&&(i > 0)){
      prev = i-1;
      while(ihist->Y[i] == 0.0)
	i++;
      next = i;
      step = (ihist->Y[next]-ihist->Y[prev])/(next-prev);
      for (i=prev+1,val=ihist->Y[prev]+step; i < next; i++,val=val+step)
	ihist->Y[i] = val;
    }

  mimg  = CreateImage(eimg->ncols,eimg->nrows);  
  n     = eimg->ncols*eimg->nrows;
  for (p=0; p < n; p++)    
    mimg->val[p] = (int)ihist->Y[eimg->val[p]];

  DestroyCurve(&nhist);
  DestroyCurve(&ihist);
  DestroyImage(&eimg);

  return(mimg);
}

Image *LinearStretch(Image *img, int f1, int f2, int g1, int g2)
{
  Image *simg=NULL;
  int p,n;
  float a;

  simg = CreateImage(img->ncols,img->nrows);
  n    = img->ncols*img->nrows;
  if (f1 != f2) 
    a = ((float)(g2-g1))/(f2-f1);
  else
    a = INT_MAX;

  for (p=0; p < n; p++){
    if (img->val[p] < f1)
      simg->val[p] = g1;
    else 
      if (img->val[p] > f2)
	simg->val[p] = g2;
      else {
	if (a != INT_MAX)	  
	  simg->val[p] = (int)(a*(img->val[p]-f1)+g1);
	else{
	    simg->val[p] = g2;
	}   
      }
  }
  return(simg);
}

Image *GaussStretch(Image *img, float mean, float stdev)
{
  float *gauss=NULL,sq,var2;
  int i,Imax,n;
  Image *gimg=NULL;

  Imax  = MaximumValue(img);
  gauss = AllocFloatArray(Imax+1);
  var2  = 2*stdev*stdev;
  for (i=0; i < Imax+1; i++){
    sq  = ((float)i-mean)*((float)i-mean);
    gauss[i]=(float)(Imax*exp(-sq/var2));
  }
  n     = img->ncols*img->nrows;
  gimg     = CreateImage(img->ncols,img->nrows);
  for (i=0; i < n; i++){
    gimg->val[i] = (int)(gauss[img->val[i]]);
  }
  free(gauss);
  return(gimg);  
}











