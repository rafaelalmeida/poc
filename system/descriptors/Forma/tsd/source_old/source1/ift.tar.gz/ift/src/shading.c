#include "shading.h"

Image *DepthShading(Context *cxt) 
{
  Image *img=NULL;
  int i,n;
  float dmin=(float)INT_MAX,dmax=(float)INT_MIN,coef;

  img = CreateImage(cxt->zbuff->usize,cxt->zbuff->vsize);
  n = img->ncols*img->nrows;
  for (i=0; i < n; i++){
    //    if (zbuf_pd[k] >= 0)   {  /* not background */???????/
    if (cxt->zbuff->dist[i] < dmin)
      dmin = cxt->zbuff->dist[i];
    if (cxt->zbuff->dist[i] > dmax)
      dmax = cxt->zbuff->dist[i];
  }
  printf("dmin %f dmax %f\n",dmin,dmax);

  if (dmin != dmax) {
    coef = 255./(dmax-dmin);  
    for (i=0; i < n; i++){
      //      if ( cxt->zbuff->dist[i] < 0)  /* negative distance means out of the object */???????
      //	img->val[i] = BACKGROUND;
      //      else
      img->val[i] = (int) (coef*(dmax-cxt->zbuff->dist[i]));
    }
  }

  return(img);
}

Vector ZBuffNormal(int i, Context *cxt) {
  int u,v;
  float nu,nv,modn;
  float nx,ny,nz;
  Vector normal;

  u = i % (cxt->zbuff->usize);
  v = i / (cxt->zbuff->usize);
  if (u==0)	  /* progressive difference method */
    nu = cxt->zbuff->dist[i+1] - cxt->zbuff->dist[i];
  else
    if (u==cxt->zbuff->usize-1)
      nu = cxt->zbuff->dist[i] - cxt->zbuff->dist[i-1];
    else	  /* central difference method */
      nu = (cxt->zbuff->dist[i+1] - cxt->zbuff->dist[i-1])/2.;
  
  if (v==0)	  /* progressive difference method */
    nv = cxt->zbuff->dist[i+cxt->zbuff->usize] - cxt->zbuff->dist[i];
  else
    if (v==cxt->zbuff->vsize-1)
      nv = cxt->zbuff->dist[i] - cxt->zbuff->dist[i-cxt->zbuff->usize];
    else	  /* central difference method */
      nv = (cxt->zbuff->dist[i+cxt->zbuff->usize] - cxt->zbuff->dist[i-cxt->zbuff->usize])/2.;
 
  /* normalization */
  modn = sqrt(nu*nu + nv*nv + 9);
  if (modn > Epsilon) {
    nx = nu/modn;
    ny = nv/modn;
    nz = 3./modn;
    normal.x = nx;
    normal.y = ny;
    normal.z = nz;
  }
  else {
    normal.x = 0.;
    normal.y = 0.;
    normal.z = 0.;
  }
  return(normal);
}

Image *PhongShading(Context *cxt) 
{
  Image *img=NULL;
  Vector viewer,normal;
  int i,k,n,value;
  float dmin=(float)INT_MAX,dmax=(float)INT_MIN,coef,amb;
  double cos2O,cosine,pow;

  img = CreateImage(cxt->zbuff->usize,cxt->zbuff->vsize);
  n = img->ncols*img->nrows;

  /* view-plane normal coordinates */
  viewer.x = cxt->IR[0][2];//acho que nao precisa do sinal MENOS!!!!
  viewer.y = cxt->IR[1][2];//idem
  viewer.z = cxt->IR[2][2];//idem

  for (i=0; i < n; i++){
    if (cxt->zbuff->dist[i] >= 0)   {  /* not background */
      if (cxt->zbuff->dist[i] < dmin)
	dmin = cxt->zbuff->dist[i];
      if (cxt->zbuff->dist[i] > dmax)
	dmax = cxt->zbuff->dist[i];
    }
  }
  //  printf("dmin %f dmax %f\n",dmin,dmax);
  
  if (dmin != dmax) {
    amb = cxt->amb*255;
    coef = 255./(dmax-dmin);
    for (i=0; i < n; i++){
      if ( cxt->zbuff->dist[i] < 0) /* negative distance means out of the object */
      	img->val[i] = 0;
      else {
	normal = ZBuffNormal(i,cxt);
	cosine = ScalarProd(viewer,normal); /* light and normal vectors are already normalized */
	
	if (cosine < -1.0) cosine = -1.0; /* necessary due to numeric errors in decimal digits?????? */
	else if (cosine > 1.0) cosine = 1.0;
	
	/*
	  |angle|>90� impossible case because raycasting/splatting selected only visible voxels, i.e. |angle|< 90�
	  if (cosine < -Epsilon)	
	  cosine = 0.;
	*/
	
	cos2O = 2*cosine*cosine-1;
	
	if (cos2O < 0.)	  /* |angle| >45� */
	  pow = 0.;
	else {
	  pow = 1.;
	  for (k=0; k < cxt->ns; k++)
	    pow = pow*cos2O;
	}
	
	value = ROUND(amb + coef * (dmax-cxt->zbuff->dist[i]) * (cosine*cxt->diff + pow*cxt->spec));
	img->val[i] = ((value>255) ? 255 : (( value < 0 ) ? 0 : (unsigned char)value)); /* conversion with saturation */
      }
    }
  }
  return(img);
}


CImage *Colorize(Context *cxt, Image *img) 
{
  CImage *cimg=NULL;
  int i,n;
  float Y,Cb,Cr,R,G,B;

  cimg = CreateCImage(img->ncols,img->nrows);
  n = img->ncols*img->nrows;
  for(i=0; i < n; i++) 
    if (cxt->zbuff->voxel[i] != NIL) {
      Y  = ((float)img->val[i])*cxt->obj[cxt->zbuff->object[i]].Y;
      Cb = cxt->obj[cxt->zbuff->object[i]].Cb*255.0;
      Cr = cxt->obj[cxt->zbuff->object[i]].Cr*255.0;

      R=1.164*((float)Y-16.0)+
	1.596*((float)Cr-128.0);

      G=1.164*((float)Y-16.0)-
	0.813*((float)Cr-128.0)-
	0.392*((float)Cb-128.0);
  
      B=1.164*((float)Y-16.0)+
	2.017*((float)Cb-128.0);

      if (R<0.0) R=0.0;
      if (G<0.0) G=0.0;
      if (B<0.0) B=0.0;
      if (R>255.0) R=255.0;
      if (G>255.0) G=255.0;
      if (B>255.0) B=255.0;
      cimg->C[0]->val[i]=(uchar)R;
      cimg->C[1]->val[i]=(uchar)G;
      cimg->C[2]->val[i]=(uchar)B;
    } else { 
      if (img->val[i]==255){ /* Colorize Cube */
	cimg->C[0]->val[i]=255;
	cimg->C[1]->val[i]=255;
	cimg->C[2]->val[i]=255;
      }
    }

  return(cimg);
}

