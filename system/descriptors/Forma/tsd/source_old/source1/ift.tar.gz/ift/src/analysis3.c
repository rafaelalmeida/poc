#include "analysis3.h"

void iftDistTrans3(AnnScn *ascn, AdjRel3 *A)
{
  AdjRel3 *A6=Spheric(1.0);
  Voxel u,v;
  int s,t,i;
  Scene *scn=ascn->scn;
  int qsize,fsize;

  for (u.z=0; u.z < scn->zsize; u.z++)
    for (u.y=0; u.y < scn->ysize; u.y++)
      for (u.x=0; u.x < scn->xsize; u.x++){
	s = u.x + scn->tby[u.y] + scn->tbz[u.z];
	if (scn->data[s] != 0){ 
	  for (i=1; i < A6->n; i++){
	    v.x = u.x + A6->dx[i];
	    v.y = u.y + A6->dy[i];
	    v.z = u.z + A6->dz[i];
	    if (ValidVoxel(scn,v.x,v.y,v.z)){
	      t = v.x + scn->tby[v.y] + scn->tbz[v.z];
	      if (scn->data[t]==0){
		AddSeed31(ascn,s,0,s,s);
		break;
	      }
	    } else {
	      AddSeed31(ascn,s,0,s,s);
	      break;
	    }
	  }
	}
      }
  DestroyAdjRel3(&A6);
  fsize = FrameSize3(A);
  qsize = 2*fsize*(scn->xsize+scn->ysize+scn->zsize)+3*fsize*fsize;
  IFT3(ascn,A,FEucl3,qsize);
}
