#ifndef _SET_H_
#define _SET_H_

#include "common.h"

typedef struct _set {
  int elem;
  struct _set *next;
} Set;

void InsertSet(Set **S, int elem);
int  RemoveSet(Set **S);
void DestroySet(Set **S);


/* vetor de booleanos, usa um bit por booleano
   tamanho = ceil(n / 8) */

typedef struct _bmap {
  char *data;
  int N, VN;
} BMap;

BMap * BMapNew(int n);
void   BMapDestroy(BMap *b);
void   BMapFill(BMap *b, int value);
int    BMapGet(BMap *b, int n);
void   BMapSet(BMap *b, int n, int value);
void   BMapToggle(BMap *b, int n);

/* versoes inline de BMapGet, BMapSet e BMapToggle */
/* se estiver apenas setando ou resetando o bit incondicionalmente, 
   use Set0 / Set1 */

#define _fast_BMapGet(b,n) ((b->data[n>>3]&(1<<(n&0x07)))!=0)
#define _fast_BMapSet(b,n,v) if (v) b->data[n>>3]|=(1<<(n&0x07)); else b->data[n>>3]&=((~0)^(1<<n&0x07));

#define _fast_BMapSet0(b,n) b->data[n>>3]&=((~0)^(1<<n&0x07));
#define _fast_BMapSet1(b,n) b->data[n>>3]|=(1<<n&0x07);
#define _fast_BMapToggle(b,n) b->data[n>>3]^=(1<<n&0x07);

/* estrutura de conjunto para a DIFT */

typedef struct _intset {
  int n;
  int count;
  int slsize, slgrow;
  BMap  *Sv;
  int   *Sl;
} IntSet;

/* cria conjunto de inteiros no dominio [0,N) */
IntSet * IntSetNew(int N);
void     IntSetDestroy(IntSet *S);

int      IntSetBelongs(IntSet *S, int elem); /* !=0 se elem \in S */
void     IntSetUnion(IntSet *S, IntSet *T);  /* S := S U T */
void     IntSetUnion1(IntSet *S, int elem);  /* S := S U { elem } */
void     IntSetMinus(IntSet *S, IntSet *T);  /* S := S \ T */
void     IntSetIntersection(IntSet *S, IntSet *T); /* S := S \cap T */

int      IntSetEmpty(IntSet *S);     /* !=0 se S=\emptyset */
int      IntSetRemoveAny(IntSet *S);
void     IntSetRemoveElement(IntSet *S, int elem);

/* libera memoria, se possivel. Para ser usado, por exemplo,
   apos um IntSetMinus ou IntSetIntersection que reduza muito
   o tamanho de S */
void IntSetShrink(IntSet *S);


#endif
