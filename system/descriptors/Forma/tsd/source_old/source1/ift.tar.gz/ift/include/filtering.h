#ifndef _FILTERING_H_
#define _FILTERING_H_

#include "adjacency.h"
#include "image.h"
#include "annimg.h"

typedef struct _kernel {
  float *val;
  AdjRel *adj;
  int xsize,ysize;
} Kernel;

Kernel *MakeKernel(char *coefs);
Kernel *CreateKernel(AdjRel *A);
Kernel *LinearKernel(AdjRel *A);
void    DestroyKernel(Kernel **K);
Image  *LinearFilter(Image *img, Kernel *K);
Image  *MedianFilter(Image *img, AdjRel *A);
Image  *ModeFilter(Image *img, AdjRel *A);

/* ----------- IFT-based Operators ------------------- */

Image  *ShapeFilter(Image *bin, float perc);

#endif
