#ifndef _SPLATTING_H_
#define _SPLATTING_H_

#include "ift.h"

Image    *SplatScene(Scene *scn, Context *cxt);
Image    *SWSplatScene(Scene *scn, Context *cxt);

#endif
