#include "adjacency3.h"

AdjRel3 *CreateAdjRel3(int n)
{
  AdjRel3 *A=NULL;

  A = (AdjRel3 *) calloc(1,sizeof(AdjRel3));
  if (A != NULL){
    A->dx = AllocIntArray(n);
    A->dy = AllocIntArray(n);
    A->dz = AllocIntArray(n);
    A->n  = n;
  } else {
    Error(MSG1,"CreateAdjRel3");
  }

  return(A);
}

void DestroyAdjRel3(AdjRel3 **A)
{
  AdjRel3 *aux;

  aux = *A;
  if (aux != NULL){
    if (aux->dx != NULL) free(aux->dx);
    if (aux->dy != NULL) free(aux->dy);
    if (aux->dz != NULL) free(aux->dz);
    free(aux);
    *A = NULL;
  }   
}

AdjRel3 *Spheric(float r)
{
  AdjRel3 *A=NULL;
  int i,n,r0,r2,dx,dy,dz,i0=0;

  n=0;
  r0 = (int)r;
  r2  = (int)(r*r);
  for(dz=-r0;dz<=r0;dz++)
    for(dy=-r0;dy<=r0;dy++)
      for(dx=-r0;dx<=r0;dx++)
      if(((dx*dx)+(dy*dy)+(dz*dz)) <= r2)
	n++;
	
  A = CreateAdjRel3(n);
  i=0;
  for(dz=-r0;dz<=r0;dz++)
    for(dy=-r0;dy<=r0;dy++)
      for(dx=-r0;dx<=r0;dx++)
	if(((dx*dx)+(dy*dy)+(dz*dz)) <= r2){
	  A->dx[i]=dx;
	  A->dy[i]=dy;
	  A->dz[i]=dz;
	  if ((dx==0)&&(dy==0)&&(dz==0))
	    i0 = i;
	  i++;	  
	}

  /* shift to right and place central voxel at first */
  
  for (i=i0; i > 0; i--) {
    dx = A->dx[i];
    dy = A->dy[i];
    dz = A->dz[i];
    A->dx[i] = A->dx[i-1];
    A->dy[i] = A->dy[i-1];
    A->dz[i] = A->dz[i-1];
    A->dx[i-1] = dx;
    A->dy[i-1] = dy;
    A->dz[i-1] = dz;
  }

  return(A);
}

int FrameSize3(AdjRel3 *A)
{
  int sz=INT_MIN,i=0;

  for (i=0; i < A->n; i++){
    if (fabs(A->dx[i]) > sz) 
      sz = fabs(A->dx[i]);
    if (fabs(A->dy[i]) > sz) 
      sz = fabs(A->dy[i]);
    if (fabs(A->dz[i]) > sz) 
      sz = fabs(A->dz[i]);
  }
  return(sz);
}

AdjRel3 *Cube(int xsize, int ysize, int zsize)
{
  AdjRel3 *A=NULL;
  int i,dx,dy,dz;

  if (xsize%2 == 0) xsize++;
  if (ysize%2 == 0) ysize++;
  if (zsize%2 == 0) zsize++;
      
  A = CreateAdjRel3(xsize*ysize*zsize);
  i=1;
  for(dz=-zsize/2;dz<=zsize/2;dz++)
    for(dy=-ysize/2;dy<=ysize/2;dy++)
      for(dx=-xsize/2;dx<=xsize/2;dx++)
	if ((dx != 0)&&(dy != 0)){
	  A->dx[i]=dx;
	  A->dy[i]=dy;
	  A->dz[i]=dz;
	  i++;
	}
  
  
    /* place the central pixel at first */
  A->dx[0] = 0;
  A->dy[0] = 0;
  A->dz[0] = 0;

  return(A);
}


AdjVxl *AdjVoxels(Scene *scn, AdjRel3 *A)
{
  AdjVxl *N;
  int i;

  N = (AdjVxl *) calloc(1,sizeof(AdjVxl));
  if(N != NULL){
    N->dp = AllocIntArray(A->n);
    N->n  = A->n;
    for (i=0; i < N->n; i++)
      N->dp[i] = A->dx[i] + scn->ysize*A->dy[i] + scn->zsize*A->dz[i];
  }else{
    Error(MSG1,"AdjPixels");  
  }

  return(N);
}

void DestroyAdjVxl(AdjVxl **N)
{
  AdjVxl *aux;

  aux = *N;
  if (aux != NULL){
    if (aux->dp != NULL) free(aux->dp);
    free(aux);
    *N = NULL;
  }
}
