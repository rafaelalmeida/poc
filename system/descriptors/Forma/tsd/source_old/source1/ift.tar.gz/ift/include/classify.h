#ifndef _CLASSIFY_H_
#define _CLASSIFY_H_

#include "shell.h"
#include "context.h"
#include "curve.h"
#include "image.h"
#include "scene.h"


typedef int (*CFun)(Scene *scn, Voxel v);

int FDensity3  (Scene *scn, Voxel v);
int FGradient3 (Scene *scn, Voxel v);
int FMorphGrad3(Scene *scn, Voxel v);

void ClassifyVoxel (Attrib *voxel, Curve *c, int i);
void ClassifyShell (Shell  *shell, Scene *scn, Curve *c, CFun cfun);
void ClassifyScene (float  *alpha, Scene *scn, Curve *c, CFun cfun);
float *CreateOpacity (Scene *scn);
void ApplyOpacity (Scene *scn, float *alpha);
#endif








