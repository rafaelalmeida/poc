#ifndef _MATHEMATICS3_H_
#define _MATHEMATICS3_H_

#include "scene.h"

Scene *Diff3(Scene *scn1, Scene *scn2);
Scene *Sum3(Scene *scn1, Scene *scn2);
Scene  *Complement3(Scene *scn);
Scene  *SQRT3(Scene *scn);

#endif
