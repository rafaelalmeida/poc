#ifndef _DESCRIPTOR_H_
#define _DESCRIPTOR_H_

#include "ift.h"

#define LOW 0
#define HIGH 1

#define FALSE 0
#define TRUE 1

#define SIZE 512

typedef struct {
  int color;
  int frequency;
}Property;

typedef struct {
  unsigned long colorH[SIZE];
  unsigned long lowH[SIZE];
  unsigned long highH[SIZE];
}VisualFeature;

typedef struct {
  unsigned char colorH[SIZE];
  unsigned char lowH[SIZE];
  unsigned char highH[SIZE];
}CompressedVisualFeature;

/**********************************************/
/* Contour Multiscale Fractal Dimension */
Curve *PolynomToFractalCurve(Polynom *P, double lower, double higher, int nbins);
Curve *ContourMSFractal(Image *in);

/**********************************************/
/* Contour Saliences */
Curve3D *iftContourSaliences(Image *bin,
			     int maxdist,
			     int threshold_in, 
			     int threshold_out,
			     int angle_in,
			     int angle_out);
Curve3D *iftContourConvexSaliences(Image *bin,int maxdist,int threshold,int angle);
Curve3D *iftContourConcaveSaliences(Image *bin,int maxdist,int threshold,int angle);
Curve *ContourSaliences(Image *in);
/**********************************************/
/* Moments Invariant */

Curve *MomentInv(Image *img);
Curve *MomentInvariant(Image *img); // contorno e objeto inteiro
/**********************************************/
/* Fourier Descriptor */

Curve *Image2Curve(Image *img);
Curve *FourierDescriptor(Image *img);
/**********************************************/
/* Curvature Scale Space */

Curve *CSS(Image *bin);
/**********************************************/
/* BIC */

Curve *BIC(CImage *img);
void Write_visual_features(char *filename,char *dbname, CompressedVisualFeature *cvf);
CompressedVisualFeature *Extract_visual_features(CImage *img);
#endif
