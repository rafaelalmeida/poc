#include "set.h"

void InsertSet(Set **S, int elem)
{
  Set *p=NULL;

  p = (Set *) calloc(1,sizeof(Set));
  if (p == NULL) Error(MSG1,"InsertSet");
  if (*S == NULL){
    p->elem  = elem;
    p->next  = NULL;
  }else{
    p->elem  = elem;
    p->next  = *S;
  }
  *S = p;
}

int RemoveSet(Set **S)
{
  Set *p;
  int elem=NIL;
  
  if (*S != NULL){
    p    =  *S;
    elem = p->elem;
    *S   = p->next;
    //printf("RemoveSet before free");
    free(p);
    //printf(" RemoveSet after free: elem is %d\n",elem);
    //if(*S != NULL) printf(" *S->elem is %d\n",(*S)->elem);
  }

  return(elem);
}

void DestroySet(Set **S)
{
  Set *p;
  while(*S != NULL){
    p = *S;
    *S = p->next;
    free(p);
  }
}


/* BMap */

BMap * BMapNew(int n) {
  BMap *x;
  x= (BMap *) malloc(sizeof(BMap));
  if (!x) return 0;
  x->N    = n;
  x->VN   = n/8;
  if (n%8) x->VN++;
  x->data = (char *) malloc(sizeof(char) * x->VN);
  if (!x->data) return 0;
  BMapFill(x,0);
  return x;
}

void   BMapDestroy(BMap *b) {
  if (b) {
    if (b->data) {
      free(b->data);
      b->data = 0;
    }
    free(b);
  }
}
void   BMapFill(BMap *b, int value) {
  memset(b->data, value?0xff:0, b->VN);
}

static char bmap_set[8]   = { 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80 };
static char bmap_reset[8] = { 0xfe, 0xfd, 0xfb, 0xf7, 0xef, 0xdf, 0xbf, 0x7f };

int    BMapGet(BMap *b, int n) {
  int thebyte, thebit, value;

  thebyte = n >> 3;
  thebit  = n & 0x07;

  value = b->data[thebyte] & bmap_set[thebit];
  if (value) value=1;
  return value;
}

void BMapSet(BMap *b, int n, int value) {
  int thebyte, thebit;

  thebyte = n >> 3;
  thebit  = n & 0x07;

  if (value)
    b->data[thebyte] |= bmap_set[thebit];
  else
    b->data[thebyte] &= bmap_reset[thebit];  
}

void   BMapToggle(BMap *b, int n) {
  int thebyte, thebit;

  thebyte = n >> 3;
  thebit  = n & 0x07;

  b->data[thebyte] ^= bmap_set[thebit];
}

/* IntSet */
/* a descricao algoritmica desta estrutura esta' na
   secao 3.6 da minha tese -- Felipe Bergo */

IntSet * IntSetNew(int N) {
  IntSet *S;

  S = (IntSet *) malloc(sizeof(IntSet));
  if (!S) return 0;

  S->n     = N;
  S->count = 0;
  S->Sv    = BMapNew(N);
  if (!S->Sv) {
    free(S);
    return 0;
  }
  
  /* tamanho inicial de Sl: 64 elementos, cresce de 256 em 256 */
  S->slsize = 64;
  S->slgrow = 256;
  S->Sl = (int *) malloc(S->slsize * sizeof(int));
  if (!S->Sl) {
    free(S);
    return 0;
  }

  return S;
}

void IntSetDestroy(IntSet *S) {
  if (S) {
    if (S->Sl)
      free(S->Sl);
    if (S->Sv)
      BMapDestroy(S->Sv);
    free(S);
  }
}

/* operacoes internas (nao estao declaradas no .h para
   evitar que usem errado) */

void IntSetGrow(IntSet *S) {
  S->slsize += S->slgrow;
  S->Sl = (int *) realloc(S->Sl, sizeof(int) * S->slsize);
}

void IntSetAddUniqueElementToSet(IntSet *S, int elem) {
  _fast_BMapSet1(S->Sv, elem);
  if (S->count == S->slsize)
    IntSetGrow(S);
  S->Sl[S->count++] = elem;
}

/* remove um fulano do meio de S->Sl */
void IntSetR1(IntSet *S, int index) {
  S->Sl[index] = S->Sl[--(S->count)];
}

/* operacoes publicas */

int  IntSetBelongs(IntSet *S, int elem) {
  return(_fast_BMapGet(S->Sv,elem));
}

#define _fast_Belongs(S,elem) (_fast_BMapGet(S->Sv,elem))

void IntSetUnion(IntSet *S, IntSet *T) {
  int i;
  for(i=0;i<T->count;i++)
    if (!_fast_Belongs(S,T->Sl[i]))
      IntSetAddUniqueElementToSet(S, T->Sl[i]);
}

void IntSetUnion1(IntSet *S, int elem) {
  if (!_fast_Belongs(S,elem))
    IntSetAddUniqueElementToSet(S, elem);
}

void IntSetMinus(IntSet *S, IntSet *T) {
  int i;

  for(i=0;i<T->count;i++)
    if (_fast_Belongs(S,T->Sl[i]))
      _fast_BMapSet0(S->Sv,T->Sl[i]);

  for(i=0;i<S->count;i++)
    if (!_fast_BMapGet(S->Sv,S->Sl[i]))
      IntSetR1(S,i--);
}

void IntSetIntersection(IntSet *S, IntSet *T) {
  int i;

  for(i=0;i<T->count;i++)
    if (_fast_Belongs(S,T->Sl[i]))
      _fast_BMapSet0(S->Sv,T->Sl[i]);

  for(i=0;i<S->count;i++) {
    _fast_BMapToggle(S->Sv,S->Sl[i]);
    if (!_fast_BMapGet(S->Sv,S->Sl[i]))
      IntSetR1(S,i--);
  }
}

/* encolhe o Sl, se a area desperdicada for maior
   que slgrow */
void IntSetShrink(IntSet *S) {
  if (S->slsize - S->count > S->slgrow) {
    S->slsize = S->count;
    S->Sl = (int *) realloc(S->Sl, sizeof(int) * S->slsize);
  }
}

int IntSetEmpty(IntSet *S) {
  return(S->count == 0);
}

int IntSetRemoveAny(IntSet *S) {
  _fast_BMapSet0(S->Sv,S->Sl[--S->count]);
  return(S->Sl[S->count]);
}

void IntSetRemoveElement(IntSet *S, int elem) {
  int i;
  if (_fast_Belongs(S,elem)) {
    i=0;
    while(S->Sl[i]!=elem) ++i;
    IntSetR1(S,i);
    _fast_BMapSet0(S->Sv,elem);
  }
}
