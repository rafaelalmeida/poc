#ifndef _SEGMENTATION3_H_
#define _SEGMENTATION3_H_

#include "ift.h"

void   IncWater3(AnnScn *ascn, AdjRel3 *A);
void   DecWater3(AnnScn *ascn, AdjRel3 *A);
void   IncFuzzCon3(AnnScn *ascn, AdjRel3 *A);
void   DecFuzzCon3(AnnScn *ascn, AdjRel3 *A);
Scene *Threshold3(Scene *scn, int lower, int higher);
int    AutoThreshold3(Scene *scn);

#endif
