#ifndef _PLANE_H_
#define _PLANE_H_

#include "common.h"
#include "geometry.h"

typedef struct _plane {
  Vector normal;
  Point  po;
} Plane;

Plane *CreatePlane();
void   DestroyPlane(Plane **pl);
void   RotatePlane(Plane *pl, float thx, float thy, float thz);
void   TranslatePlane(Plane *pl, float alpha);
void  RotatePlaneAux(Plane *pl, float thx, float thy, float thz);
void   TranslatePlaneAux(Plane *pl, float alpha);
Plane *FacePlane(Vertex *vert, int n);

#endif
