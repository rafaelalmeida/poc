#ifndef _BSHELL_H_
#define _BSHELL_H_

#include "scene.h"
#include "image.h"
#include "context.h"
#include "geometry.h"
#include "shell.h"
#include "curve.h"



typedef struct _battrib {
  int x;
  int val;
  float opac;
  ushort normal;
  ushort mag;
  uchar obj;
} BAttrib;


typedef struct _bshell {
  BAttrib *voxel;
  PAttrib *pointer;
  int xsize,ysize,zsize;
  int nvoxels;
  char PAxis;
  float dx,dy,dz;
  Image *Myz;
  Image *Mzx;
  Vector *normaltable;
} BShell;


BShell *CreateBShell (Scene *scn);
void    DestroyBShell (BShell **bshell);
int     GetBPointer (BShell *bshell, Voxel V);

void    SetBShellNormal (BShell *bshell, Scene *scn);
void    SetBVoxelNormal(Scene *scn, Voxel *v, Vector *normal, int *mag);
Image   *SWBShellRendering  (BShell *bshell,Context *cxt);
void    ClassifyBShell (BShell *bshell, Curve *den, Curve *grad);



#endif








