#include "morphology3.h"

Scene *Dilate3(Scene *scn, AdjRel3 *A)
{
  Scene *dil = NULL;
  Voxel u, v;
  int p, q, max, i;

  dil = CreateScene(scn->xsize, scn->ysize, scn->zsize);
  dil->dx = scn->dx;
  dil->dy = scn->dy;
  dil->dz = scn->dz;

  for (u.z = 0, p = 0; u.z < scn->zsize; u.z++)
    for (u.y = 0; u.y < scn->ysize; u.y++)
      for (u.x = 0; u.x < scn->xsize; u.x++, p++) {
	max = INT_MIN;
	for (i = 0; i < A->n; i++) {
	  v.x = u.x + A->dx[i];
	  v.y = u.y + A->dy[i];
	  v.z = u.z + A->dz[i];
	  if (ValidVoxel(scn, v.x, v.y, v.z)) {
	    q = v.x + scn->tby[v.y] + scn->tbz[v.z];
	    if (scn->data[q] > max)
	      max = scn->data[q];
	  }
	}
	dil->data[p] = max;
      }

  return (dil);
}

Scene *Erode3(Scene *scn, AdjRel3 *A)
{
  Scene *ero = NULL;
  Voxel u, v;
  int p, q, min, i;

  ero = CreateScene(scn->xsize, scn->ysize, scn->zsize);
  ero->dx = scn->dx;
  ero->dy = scn->dy;
  ero->dz = scn->dz;

  for (u.z = 0, p = 0; u.z < scn->zsize; u.z++)
    for (u.y = 0; u.y < scn->ysize; u.y++)
      for (u.x = 0; u.x < scn->xsize; u.x++, p++) {
	min = INT_MAX;
	for (i = 0; i < A->n; i++) {
	  v.x = u.x + A->dx[i];
	  v.y = u.y + A->dy[i];
	  v.z = u.z + A->dz[i];
	  if (ValidVoxel(scn, v.x, v.y, v.z)) {
	    q = v.x + scn->tby[v.y] + scn->tbz[v.z];
	    if (scn->data[q] < min)
	      min = scn->data[q];
	  }
	}
	ero->data[p] = min;
      }

  return (ero);
}
  
Scene *Open3(Scene *scn, AdjRel3 *A)
{
  Scene *open, *ero;

  ero = Erode3(scn, A);
  open = Dilate3(scn, A);
  DestroyScene(&scn);

  return (open);
}

Scene *lmOpen3(Scene *scn, AdjRel3 *A)
{
  Scene *open = NULL;
  Voxel u, v, t;
  int p, q, s, max, min, i, j;

  open = CreateScene(scn->xsize, scn->ysize, scn->zsize);
  open->dx = scn->dx;
  open->dy = scn->dy;
  open->dz = scn->dz;

  for (u.z = 0, p = 0; u.z < scn->zsize; u.z++)
    for (u.y = 0; u.y < scn->ysize; u.y++)
      for (u.x = 0; u.x < scn->xsize; u.x++, p++) {
	max = INT_MIN;
	for (i = 0; i < A->n; i++) {
	  v.x = u.x + A->dx[i];
	  v.y = u.y + A->dy[i];
	  v.z = u.z + A->dz[i];
	  if (ValidVoxel(scn, v.x, v.y, v.z)) {
	    q = v.x + scn->tby[v.y] + scn->tbz[v.z];
	    min = INT_MAX;
	    for (j = 0; j < A->n; j++) {
	      t.x = v.x + A->dx[i];
	      t.y = v.y + A->dy[i];
	      t.z = v.z + A->dz[i];
	      if (ValidVoxel(scn, t.x, t.y, t.z)) {
		s = t.x + scn->tby[t.y] + scn->tbz[t.z];
		if (scn->data[s] < min)
		  min = scn->data[s];
	      }
	    }
	    if (min > max)
	      max = min;
	  }
	}
	open->data[p] = max;
      }

  return (open);
}


Scene *Close3(Scene *scn, AdjRel3 *A)
{
  Scene *close, *dil;

  dil = Dilate3(scn, A);
  close = Erode3(scn, A);
  DestroyScene(&scn);

  return (close);
}

Scene *lmClose3(Scene *scn, AdjRel3 *A)
{
  Scene *close = NULL;
  Voxel u, v, t;
  int p, q, s, max, min, i, j;

  close = CreateScene(scn->xsize, scn->ysize, scn->zsize);
  close->dx = scn->dx;
  close->dy = scn->dy;
  close->dz = scn->dz;

  for (u.z = 0, p = 0; u.z < scn->zsize; u.z++)
    for (u.y = 0; u.y < scn->ysize; u.y++)
      for (u.x = 0; u.x < scn->xsize; u.x++, p++) {
	min = INT_MAX;
	for (i = 0; i < A->n; i++) {
	  v.x = u.x + A->dx[i];
	  v.y = u.y + A->dy[i];
	  v.z = u.z + A->dz[i];
	  if (ValidVoxel(scn, v.x, v.y, v.z)) {
	    q = v.x + scn->tby[v.y] + scn->tbz[v.z];
	    max = INT_MIN;
	    for (j = 0; j < A->n; j++) {
	      t.x = v.x + A->dx[i];
	      t.y = v.y + A->dy[i];
	      t.z = v.z + A->dz[i];
	      if (ValidVoxel(scn, t.x, t.y, t.z)) {
		s = t.x + scn->tby[t.y] + scn->tbz[t.z];
		if (scn->data[s] > max)
		  max = scn->data[s];
	      }
	    }
	    if (max < min)
	      min = max;
	  }
	}
	close->data[p] = min;
      }

  return (close);
}

Scene *MorphGrad3(Scene *scn, AdjRel3 *A)
{
  Scene *grad=NULL;
  Voxel u,v;
  int i,s,t,min,max;

  grad = CreateScene(scn->xsize,scn->ysize,scn->zsize);
  grad->dx = scn->dx;
  grad->dy = scn->dy;
  grad->dz = scn->dz;

  for (u.z=0; u.z < scn->zsize; u.z++)
    for (u.y=0; u.y < scn->ysize; u.y++)
      for (u.x=0; u.x < scn->xsize; u.x++){
	s = u.x + scn->tby[u.y] + scn->tbz[u.z];
	min = INT_MAX;
	max = INT_MIN;
	for (i=0; i < A->n; i++) {
	  v.x = u.x + A->dx[i];
	  v.y = u.y + A->dy[i];
	  v.z = u.z + A->dz[i];
	  if (ValidVoxel(scn,v.x,v.y,v.z)){
	    t = v.x + scn->tby[v.y] + scn->tbz[v.z];
	    if (scn->data[t] > max)
	      max = scn->data[t];
	    if (scn->data[t] < min)
	      min = scn->data[t];
	  }
	}
	grad->data[s] = max - min;
      }

  return(grad);
}


Scene *SupRec3(Scene *scn, Scene *marker, AdjRel3 *A)
{
  Scene *cost = NULL;
  Queue *Q = NULL;
  Voxel u, v;
  int i, p, q, n, s, tmp;

  cost = CreateScene(scn->xsize, scn->ysize, scn->zsize);
  cost->dx = scn->dx; cost->dy = scn->dy; cost->dz = scn->dz;
  s = scn->xsize * scn->ysize;
  n = s * scn->zsize;
  Q = CreateQueue(MaximumValue3(marker)+1, n);

  for(p = 0; p < n; p++) {
    cost->data[p] = marker->data[p];
    InsertQueue(Q, cost->data[p], p);
  }

  while (!EmptyQueue(Q)) {
    p = RemoveQueue(Q);
    u.z = p / s;
    u.y = (p % s) / scn->ysize;
    u.x = (p % s) % scn->ysize;
    for (i = 0; i < A->n; i++) {
      v.z = u.z + A->dz[i];
      v.y = u.y + A->dy[i];
      v.x = u.x + A->dx[i];
      if (ValidVoxel(scn, v.x, v.y, v.z)) {
	q = v.x + scn->tby[v.y] + scn->tbz[v.z];
	if (cost->data[p] < cost->data[q]) {
	  tmp = MAX(cost->data[p], scn->data[q]);
	  if (tmp < cost->data[q]) {
	    UpdateQueue(Q, q, cost->data[q], tmp);
	    cost->data[q] = tmp;
	  }
	}
      }
    }
  }
	  
  DestroyQueue(&Q);

  return (cost);
}
  
Scene *InfRec3(Scene *scn, Scene *marker, AdjRel3 *A)
{
  Scene *cost = NULL;
  Queue *Q = NULL;
  Voxel u, v;
  int i, p, q, n, s, Imax, tmp;

  cost = CreateScene(scn->xsize, scn->ysize, scn->zsize);
  cost->dx = scn->dx; cost->dy = scn->dy; cost->dz = scn->dz;
  s = scn->xsize * scn->ysize;
  n = s * scn->zsize;
  Imax = MaximumValue3(scn);
  Q = CreateQueue(Imax+1, n);

  for(p = 0; p < n; p++) {
    cost->data[p] = marker->data[p];
    InsertQueue(Q, Imax - cost->data[p], p);
  }

  while (!EmptyQueue(Q)) {
    p = RemoveQueue(Q);
    u.z = p / s;
    u.y = (p % s) / scn->ysize;
    u.x = (p % s) % scn->ysize;
    for (i = 0; i < A->n; i++) {
      v.z = u.z + A->dz[i];
      v.y = u.y + A->dy[i];
      v.x = u.x + A->dx[i];
      if (ValidVoxel(scn, v.x, v.y, v.z)) {
	q = v.x + scn->tby[v.y] + scn->tbz[v.z];
	if (cost->data[p] > cost->data[q]) {
	  tmp = MIN(cost->data[p], scn->data[q]);
	  if (tmp > cost->data[q]) {
	    UpdateQueue(Q, q, Imax - cost->data[q], Imax - tmp);
	    cost->data[q] = tmp;
	  }
	}
      }
    }
  }
	  
  DestroyQueue(&Q);

  return (cost);
}


Scene *CloseHoles3(Scene *scn)
{
  AdjRel3 *A = NULL;
  Scene *cost = NULL;
  Queue *Q = NULL;
  Voxel u, v;
  int i, p, q, n, s, Imax, tmp;

  cost = CreateScene(scn->xsize, scn->ysize, scn->zsize);
  cost->dx = scn->dx; cost->dy = scn->dy; cost->dz = scn->dz;
  s = scn->xsize * scn->ysize;
  n = s * scn->zsize;
  Imax = MaximumValue3(scn) + 1;
  Q = CreateQueue(Imax+1, n);
  A = Spheric(1.0);

  for(p = 0; p < n; p++) {
    if (EdgeVoxel(scn,p,s))
      cost->data[p] = scn->data[p];
    else
      cost->data[p] = Imax;
    InsertQueue(Q, cost->data[p], p);
  }

  while (!EmptyQueue(Q)) {
    p = RemoveQueue(Q);
    u.z = p / s;
    u.y = (p % s) / scn->ysize;
    u.x = (p % s) % scn->ysize;
    for (i = 0; i < A->n; i++) {
      v.z = u.z + A->dz[i];
      v.y = u.y + A->dy[i];
      v.x = u.x + A->dx[i];
      if (ValidVoxel(scn, v.x, v.y, v.z)) {
	q = v.x + scn->tby[v.y] + scn->tbz[v.z];
	if (cost->data[p] < cost->data[q]) {
	  tmp = MAX(cost->data[p], scn->data[q]);
	  if (tmp < cost->data[q]) {
	    UpdateQueue(Q, q, cost->data[q], tmp);
	    cost->data[q] = tmp;
	  }
	}
      }
    }
  }
	  
  DestroyQueue(&Q);
  DestroyAdjRel3(&A);

  return (cost);
}

Scene *RemDomes3(Scene *scn)
{
  AdjRel3 *A = NULL;
  Scene *cost = NULL;
  Queue *Q = NULL;
  Voxel u, v;
  int i, p, q, n, s, Imin, Imax, tmp;

  cost = CreateScene(scn->xsize, scn->ysize, scn->zsize);
  cost->dx = scn->dx; cost->dy = scn->dy; cost->dz = scn->dz;
  s = scn->xsize * scn->ysize;
  n = s * scn->zsize;
  Imax = MaximumValue3(scn);
  Imin = MinimumValue3(scn) - 1;
  Q = CreateQueue(Imax+1, n);
  A = Spheric(1.0);

  for(p = 0; p < n; p++) {
    if (EdgeVoxel(scn,p,s))
      cost->data[p] = scn->data[p];
    else
      cost->data[p] = Imin;
    InsertQueue(Q, Imax - cost->data[p], p);
  }

  while (!EmptyQueue(Q)) {
    p = RemoveQueue(Q);
    u.z = p / s;
    u.y = (p % s) / scn->ysize;
    u.x = (p % s) % scn->ysize;
    for (i = 0; i < A->n; i++) {
      v.z = u.z + A->dz[i];
      v.y = u.y + A->dy[i];
      v.x = u.x + A->dx[i];
      if (ValidVoxel(scn, v.x, v.y, v.z)) {
	q = v.x + scn->tby[v.y] + scn->tbz[v.z];
	if (cost->data[p] > cost->data[q]) {
	  tmp = MIN(cost->data[p], scn->data[q]);
	  if (tmp > cost->data[q]) {
	    UpdateQueue(Q, q, Imax - cost->data[q], Imax - tmp);
	    cost->data[q] = tmp;
	  }
	}
      }
    }
  }
	  
  DestroyQueue(&Q);
  DestroyAdjRel3(&A);

  return (cost);
}


Scene *OpenRec3(Scene *scn, AdjRel3 *A)
{
  Scene *open, *orec;
  AdjRel3 *A6;

  open = Open3(scn, A);
  A6 = Spheric(1.0);
  orec = InfRec3(scn, open, A6);
  DestroyScene(&open);
  DestroyAdjRel3(&A6);

  return (orec);
}

Scene *CloseRec3(Scene *scn, AdjRel3 *A)
{
  Scene *close, *crec;
  AdjRel3 *A6;

  close = Close3(scn, A);
  A6 = Spheric(1.0);
  crec = SupRec3(scn, close, A6);
  DestroyScene(&scn);
  DestroyAdjRel3(&A6);

  return (crec);
}

Scene *Leveling3(Scene *scn1, Scene *scn2)
{
  AdjRel3 *A = NULL;
  Scene *tmp = NULL, *infrec = NULL, *lev = NULL;
  Voxel u, v;
  int p, q, max, min, i;

  tmp = CreateScene(scn2->xsize, scn2->ysize, scn2->zsize);
  A = Spheric(1.0);

  for (u.z = 0, p = 0; u.z < scn2->zsize; u.z++)
    for (u.y = 0; u.y < scn2->ysize; u.y++)
      for (u.x = 0; u.x < scn2->xsize; u.x++, p++) {
	max = INT_MIN;
	for (i = 0; i < A->n; i++) {
	  v.x = u.x + A->dx[i];
	  v.y = u.y + A->dy[i];
	  v.z = u.z + A->dz[i];
	  if (ValidVoxel(scn2, v.x, v.y, v.z)) {
	    q = v.x + scn2->tby[v.y] + scn2->tbz[v.z];
	    if (scn2->data[q] > max)
	      max = scn2->data[q];
	  }
	}
	tmp->data[p] = MIN(max, scn1->data[p]);
      }
  
  infrec = InfRec3(scn1, tmp, A);

  for (u.z = 0, p = 0; u.z < scn2->zsize; u.z++)
    for (u.y = 0; u.y < scn2->ysize; u.y++)
      for (u.x = 0; u.x < scn2->xsize; u.x++, p++) {
	min = INT_MAX;
	for (i = 0; i < A->n; i++) {
	  v.x = u.x + A->dx[i];
	  v.y = u.y + A->dy[i];
	  v.z = u.z + A->dz[i];
	  if (ValidVoxel(scn2, v.x, v.y, v.z)) {
	    q = v.x + scn2->tby[v.y] + scn2->tbz[v.z];
	    if (scn2->data[q] < min)
	      min = scn2->data[q];
	  }
	}
	tmp->data[p] = MAX(min, infrec->data[p]);
      }

  DestroyScene(&infrec);

  lev = SupRec3(scn1, tmp, A);

  DestroyScene(&tmp);
  DestroyAdjRel3(&A);

  return (lev);
}
