#include "classify.h"
#include "geometry.h"

void ClassifyShell (Shell *shell, Scene *scn, Curve *c, VectorFun fun)
{  
  int i,i1,i2;
  Voxel v;
  Curve *fc;
  Vector normal;
  AdjRel3 *A = NULL;
  AdjVxl *V = NULL;

  A = Spheric(1.8);
  V = AdjVoxels(scn,A);

  fc = FillCurve(c,1.0);

  for (v.z = 0; v.z != shell->zsize; v.z ++) 
    for (v.y = 0; v.y != shell->ysize; v.y ++) {
      i = shell->Myz->tbrow[v.z] + v.y;     
      if (shell->Myz->val[i] >= 0) {	
	i1 = shell->Myz->val[i];
	i++;
	while (shell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = shell->Myz->val[i];
	for (i = i1; i != i2; i++) {	  
	  v.x = shell->voxel[i].x;
	  shell->voxel[i].opac *= fc->Y[abs((int)fun(scn,&v,&normal,A,V))];
	}        
      }
    }
  DestroyCurve(&fc);
  DestroyAdjRel3(&A);
  DestroyAdjVxl(&V);
}

void ClassifyScene (Scene *alpha, Scene *scn, Curve *c, VectorFun fun)
{  
  int i;
  Voxel v;
  Curve *fc;
  Vector normal;
  AdjRel3 *A = NULL;
  AdjVxl *V = NULL;

  A = Spheric(1.8);
  V = AdjVoxels(scn,A);

  fc = FillCurve(c,1.0);
  i = 0;
  for (v.z = 0; v.z != scn->zsize; v.z ++) 
    for (v.y = 0; v.y != scn->ysize; v.y ++) 
      for (v.x = 0; v.x != scn->xsize; v.x ++) {
	i = scn->tbz[v.z]+scn->tby[v.y]+v.x;
	if (scn->data[i] != 0)
	  alpha->data[i] *= fc->Y[abs((int)fun(scn,&v,&normal,A,V))];
      }  
  DestroyCurve(&fc);
  DestroyAdjRel3(&A);
  DestroyAdjVxl(&V);
}



