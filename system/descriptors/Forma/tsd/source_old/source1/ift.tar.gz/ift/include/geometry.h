#ifndef _GEOMETRY_H_
#define _GEOMETRY_H_

typedef struct _vector{
  float x;
  float y;
  float z;
} Vector;

typedef struct _point{
  float x;
  float y;
  float z;
} Point, Vertex;

typedef struct _edge {
  int vert[2];
} Edge;

typedef struct _myquad {
  int vert[4];
} Quad;


float    ScalarProd(Vector v1, Vector v2);
Vector   VectorProd(Vector v1, Vector v2);

#endif
