#ifndef _SCENE_H_
#define _SCENE_H_

#include "image.h"

typedef struct _voxel {
  int x,y,z;
} Voxel;

typedef struct _scene {
  int *data;
  int xsize,ysize,zsize;
  float dx,dy,dz;
  int *tby, *tbz;
} Scene;

Scene  *CreateScene(int xsize,int ysize,int zsize);
void    DestroyScene(Scene **scn);
int     VoxelValue(Scene *scn,Voxel v);
bool    ValidVoxel(Scene *scn, int vx, int vy, int vz);
int     MaximumValue3(Scene *scn);
int     MinimumValue3(Scene *scn);
Scene  *ROI3(Scene *scn, int xl, int yl, int zl, int xh, int yh, int zh);
Scene  *MBB3(Scene *scn);
Scene  *ReadScene(char *filename);
void    WriteScene(Scene *scn, char *filename);
Image  *GetSlice(Scene *scn, int z);
void    PutSlice(Image *img, Scene *scn, int z);
Scene *LinearInterp(Scene *scn,float dx,float dy,float dz);
#endif








