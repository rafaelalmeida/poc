#ifndef _CIMAGE_H_
#define _CIMAGE_H_

#include "image.h"

typedef struct cimage {
  Image *C[3];
} CImage;

CImage *CreateCImage(int ncols, int nrows);
void    DestroyCImage(CImage **cimg);
void    WriteCImage(CImage *cimg, char *filename);
CImage *CopyCImage(CImage *cimg);
CImage *CROI(CImage *cimg, int xl, int yl, int xr, int yr);
CImage *CScale(CImage *cimg, float Sx, float Sy);


#endif
