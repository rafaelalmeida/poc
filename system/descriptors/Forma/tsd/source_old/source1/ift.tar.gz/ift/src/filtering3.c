#include "filtering3.h"
#include "segmentation3.h"

Kernel3 *MakeKernel3(char *coefs)
{
  Kernel3 *K;
  AdjRel3 *A;
  int xsize,ysize,zsize,i;

  sscanf(coefs,"%d",&xsize);
  coefs=strchr(coefs,',')+1;
  sscanf(coefs,"%d",&ysize);
  coefs=strchr(coefs,',')+1;
  sscanf(coefs,"%d",&zsize);
  coefs=strchr(coefs,',')+1;

  A = Cube(xsize, ysize, zsize);
  K = CreateKernel3(A);
  for (i=0;i<A->n;i++) {
    sscanf(coefs,"%f",&K->val[i]);
    coefs=strchr(coefs,',')+1;
  }
  DestroyAdjRel3(&A);
  return(K);
}

Kernel3 *CreateKernel3(AdjRel3 *A)
{
  Kernel3 *K=NULL;
  int i;
  Voxel max, min;

  max.x = max.y = max.z = INT_MIN;
  min.x = min.y = min.z = INT_MAX;

  K = (Kernel3 *) calloc(1,sizeof(Kernel3));
  if (K == NULL){
    Error(MSG1,"CreateKernel3");
  }
  K->val = AllocFloatArray(A->n);
  K->adj = CreateAdjRel3(A->n);

  for (i=0;i<A->n;i++) {
    max.x = MAX(A->dx[i],max.x);
    max.y = MAX(A->dy[i],max.y);
    max.z = MAX(A->dz[i],max.z);
    min.x = MIN(A->dx[i],min.x);
    min.y = MIN(A->dy[i],min.y);
    min.z = MIN(A->dz[i],min.z);
    K->adj->dx[i] = A->dx[i];
    K->adj->dy[i] = A->dy[i];
    K->adj->dz[i] = A->dz[i];
  }
  
  K->xsize = max.x - min.x + 1;
  K->ysize = max.y - min.y + 1;
  K->xsize = max.x - min.x + 1;
  
  return(K);
}


void DestroyKernel3(Kernel3 **K)
{
  Kernel3 *aux;

  aux = *K;
  if(aux != NULL){
    if (aux->val != NULL)   free(aux->val); 
    DestroyAdjRel3(&(aux->adj));
    free(aux);    
    *K = NULL;
  }
}

Scene *LinearFilter(Scene *scn, Kernel3 *K) /* generic kernel */ 
{
  Scene *cscn;
  Voxel u,v;
  AdjVxl *vxl;
  int p,i;
  float conv;
  
  cscn = CreateScene(scn->xsize,scn->ysize,scn->zsize);

  vxl = AdjVoxels(scn,K->adj);

  for (u.z=0; u.z < scn->zsize; u.z++)
    for (u.y=0; u.y < scn->ysize; u.y++)
      for (u.x=0; u.x < scn->xsize; u.x++){
	conv=0.0;
	for (i=0;i<K->adj->n;i++) {
	  if (ValidVoxel(scn, v.x + K->adj->dx[i], v.y + K->adj->dy[i], v.z + K->adj->dz[i])){
	    p = v.x + scn->tby[v.y] + scn->tbz[v.z] + vxl->dp[i];
	    conv += ((float)scn->data[p])*K->val[i];	   
	  }      
	  p = u.x + cscn->tby[u.y] + cscn->tbz[u.z];
	  cscn->data[p] = (int)conv;
	}
      }
  DestroyAdjVxl(&vxl);
  return(cscn);
}



Scene *MedianFilter3(Scene *scn, AdjRel3 *A)
{
  int *val,*oval,n,i,p,q;
  Voxel u,v;
  Scene *med;

  val = AllocIntArray(A->n);
  med = CreateScene(scn->xsize, scn->ysize, scn->zsize);
  for (u.z=0; u.z < scn->zsize; u.z++)  
    for (u.y=0; u.y < scn->ysize; u.y++)  
      for (u.x=0; u.x < scn->xsize; u.x++) {
	p = u.x + scn->tby[u.y] + scn->tbz[u.z];
	n = 0;
	for (i=0; i < A->n; i++) {
	  v.x = u.x + A->dx[i];
	  v.y = u.y + A->dy[i];
	  v.z = u.z + A->dz[i];
	  if (ValidVoxel(scn,v.x,v.y,v.z)){
	    q = v.x + scn->tby[v.y] + scn->tbz[v.z];
	    val[n] = scn->data[q];
	    n++;
	  }
	}
	oval = BucketSort(val,n,INCREASING);
	med->data[p] = oval[n/2];
      free(oval);
      }
  free(val);
  return(med);
}

Kernel3 *LinearKernel3(AdjRel3 *A)
{
  float dmax, d = 0;
  Kernel3 *K;
  int i;

  K = CreateKernel3(A);
  dmax = K->xsize * K->ysize * K->zsize;

  for (i=0;i<A->n;i++) {
    d = A->dx[i] * A->dx[i] + A->dy[i] * A->dy[i] + A->dz[i] * A->dz[i];
    K->val[i] = 1.0 - (d / (dmax + 3.)); // squared d!
  }
  
  return(K);

}

