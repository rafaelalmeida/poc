#include "analysis.h"

Image *Perimeter(Image *bin)
{
  int p,n;
  Image *cont,*perim;
  Curve *hist;

  cont  = LabelContour(bin);
  n     = cont->ncols*cont->nrows;
  perim = CreateImage(cont->ncols,cont->nrows);
  hist  = Histogram(cont);
  for (p=0; p < n; p++)
    if (cont->val[p] > 0)
      perim->val[p] = hist->Y[cont->val[p]];

  DestroyCurve(&hist);
  DestroyImage(&cont);

  return(perim);
}

Image *Area(Image *bin)
{
  int p,n;
  Image *label,*area;
  Curve *hist;
  AdjRel *A;

  A     = Circular(1.5);
  label = LabelBinComp(bin,A);
  n     = label->ncols*label->nrows;
  area  = CreateImage(label->ncols,label->nrows);
  hist  = Histogram(label);
  for (p=0; p < n; p++)
    if (label->val[p] > 0)
      area->val[p] = hist->Y[label->val[p]];

  DestroyCurve(&hist);
  DestroyImage(&label);
  DestroyAdjRel(&A);

  return(area);
}

Image   *GeomCenter(Image *bin)
{
  int p,i,n,Lmax;
  Image *label,*geom;
  float *X,*Y,*N;
  AdjRel *A;
  
  A     = Circular(1.5);
  label = LabelBinComp(bin,A);
  geom  = CreateImage(bin->ncols,bin->nrows);
  Lmax  = MaximumValue(label);
  X     = AllocFloatArray(Lmax+1);
  Y     = AllocFloatArray(Lmax+1);
  N     = AllocFloatArray(Lmax+1);
  n     = bin->ncols*bin->nrows;
  for (p=0; p < n; p++){
    X[label->val[p]] += (float)(p%label->ncols);
    Y[label->val[p]] += (float)(p/label->ncols);
    N[label->val[p]] ++;
  }
  for (i=0; i <= Lmax; i++){
    X[i] /= N[i];
    Y[i] /= N[i];
  }
  for (p=0; p < n; p++)
    geom->val[p] = (int)X[label->val[p]] + 
      geom->tbrow[(int)Y[label->val[p]]];

  DestroyImage(&label);
  DestroyAdjRel(&A);
  free(X);
  free(Y);
  free(N);

  return(geom);
}

Image *CompMSSkel(AnnImg *aimg)
{
  int i,p,q,n,maxd1,maxd2,d1,d2,MaxD;
  Pixel u,v;
  int sign=1,s2;
  Image *msskel,*cont=NULL,*perim=NULL,*seed=NULL;
  AdjRel *A;

  /* Compute MS Skeletons */

  cont   = LabelContour(aimg->img);
  perim  = Perimeter(aimg->img);
  seed   = CompPaths(aimg->pred);
  A      = Circular(1.0);
  n      = aimg->label->ncols*aimg->label->nrows;
  msskel = CreateImage(aimg->label->ncols,aimg->label->nrows);

  MaxD = INT_MIN;
  for (p=0; p < n; p++) {
    if (aimg->pred->val[p] != p) {  /* It eliminates the countors and
                                       already takes into account the
                                       side option */
      u.x = p%aimg->label->ncols;
      u.y = p/aimg->label->ncols;
      maxd1 = maxd2 = INT_MIN;
      for (i=1; i < A->n; i++){
	v.x = u.x + A->dx[i];
	v.y = u.y + A->dy[i];
	if (ValidPixel(aimg->label,v.x,v.y)){
	  q = v.x + aimg->label->tbrow[v.y];
	  if (cont->val[seed->val[p]] == cont->val[seed->val[q]]){ 
	    d2   = aimg->label->val[q]-aimg->label->val[p];
	    s2   = 1;
	    //	    if (d2 > (perim->val[seed->val[p]]-1-d2)){
	    if (d2 > (perim->val[seed->val[p]]-d2)){
	      s2 = -1;
	      //	      d2 = (perim->val[seed->val[p]]-1-d2);
	      d2 = (perim->val[seed->val[p]]-d2);
	    } 
	    if (d2 > maxd2){
	      maxd2 = d2;
	      sign  = s2;
	    }
	  } else {
	    d1 = cont->val[seed->val[q]] - cont->val[seed->val[p]];
	    if (d1 > maxd1) 
	      maxd1 = d1;
	  }
	}
      }
      if (maxd1 > 0) {
	msskel->val[p] = INT_MAX;
      } else {
	msskel->val[p] = sign*maxd2;
	if (msskel->val[p] > MaxD)
	  MaxD = msskel->val[p];    
      }
    }
  }

  for (p=0; p < n; p++) { /* Set up SKIZ */
    if (msskel->val[p] == INT_MAX)
      msskel->val[p] = MaxD + 1;
  }

  DestroyImage(&cont);
  DestroyImage(&perim);
  DestroyImage(&seed);
  DestroyAdjRel(&A);

  return(msskel);
}

Image *Skeleton(Image *msskel, float perc)
{
  Image *skel = NULL;
  int p ,n, thres;
  
  skel  = Abs(msskel);
  thres = (int)((MaximumValue(skel)*perc)/100.0);      
  n = skel->ncols*skel->nrows;
  for (p=0; p < n; p++)
    if (skel->val[p] >= thres) 
      skel->val[p]=1;
    else
      skel->val[p]=0;
  
  return(skel);
}

Image *CompSKIZ(AnnImg *aimg)
{
  Image *skiz;
  int i,p,q,n,maxd,d;
  AdjRel *A;
  Pixel u,v;

  A      = Circular(1.0);
  n      = aimg->label->ncols*aimg->label->nrows;
  skiz   = CreateImage(aimg->label->ncols,aimg->label->nrows);

  for (p=0; p < n; p++) {
    if (aimg->pred->val[p] != p) {
      u.x = p%aimg->label->ncols;
      u.y = p/aimg->label->ncols;
      maxd = INT_MIN;
      for (i=1; i < A->n; i++){
	v.x = u.x + A->dx[i];
	v.y = u.y + A->dy[i];
	if (ValidPixel(aimg->label,v.x,v.y)){
	  q = v.x + aimg->label->tbrow[v.y];
	  d = aimg->label->val[q]-aimg->label->val[p];
	  if (d > maxd)
	    maxd = d;
	}
      }
      if (maxd > 0)
	skiz->val[p] = 1;
      else
	skiz->val[p] = 0;
    }
  }

  DestroyAdjRel(&A);

  return(skiz);
}

Curve3D *CompSaliences(AnnImg *aimg, int maxcost)
{
  Image *cont=NULL;
  double *inter=NULL,*exter=NULL;  
  int p,n,i,Lmax;
  Curve3D *saliences=NULL;
  
  n       = aimg->img->ncols*aimg->img->nrows;
  cont = CreateImage(aimg->img->ncols,aimg->img->nrows);
  for(p=0;p<n; p++){
    if (aimg->pred->val[p]==p){
      cont->val[p]=aimg->label->val[p];
    }
  }
  
  Lmax    = MaximumValue(aimg->label);
  inter   = AllocDoubleArray(Lmax);
  exter   = AllocDoubleArray(Lmax);
  
  
  /* Compute influence areas */

  for (p=0; p < n; p++){
    if ((aimg->label->val[p] > 0)&&(aimg->cost->val[p] <= maxcost)) {
      if (aimg->img->val[p] == 1){
	inter[aimg->label->val[p]-1]++;
      } else {
	exter[aimg->label->val[p]-1]++;
      }
    }
  }
  
  /* Compute saliences */

  saliences  = CreateCurve3D(Lmax);
  
  for (p=0; p < n; p++){
    if (cont->val[p] > 0){
      i = cont->val[p]-1;
      saliences->X[i] = (double)(p%cont->ncols);
      saliences->Y[i] = (double)(p/cont->ncols);
      if (exter[i] > inter[i]){
	saliences->Z[i] = exter[i];
      }else{
	if (exter[i] < inter[i]){
	  saliences->Z[i] = -inter[i];
	}else{
	  saliences->Z[i] = 0.0;
	}
      }
    }
  }

  DestroyImage(&cont);
  free(inter);
  free(exter);

  return(saliences);
}


Curve3D *RemSaliencesByAngle(Curve3D *curve,int radius, int angle)
{
  Curve3D *scurve;
  double area;
  int i;

  scurve = CreateCurve3D(curve->n);
  for (i=0; i < curve->n; i++){ 
    scurve->X[i] = curve->X[i];
    scurve->Y[i] = curve->Y[i];
    scurve->Z[i] = curve->Z[i];
  }
  
  area = ((double)angle*PI*radius*radius/360.0);
  for (i=0; i < scurve->n; i++){ 
    if (fabs(scurve->Z[i]) <= area)
      scurve->Z[i] = 0.0;      
  }

  return(scurve);
}

Image *PaintSaliences(Image *bin, Curve3D *curve)
{
  int i,p;
  Image *points=NULL;

  points=CopyImage(bin);
    
  for (i=0; i < curve->n; i++) {
    p = (int)curve->X[i]+points->tbrow[(int)curve->Y[i]];
    if ((curve->Z[i] > 0.0)&&(points->val[p]==1)){ /* Convex */
      PaintCircle(points,p,2.0,3);
    }  
    if ((curve->Z[i] < 0.0)&&(points->val[p]==1)) { /* Concave */
      PaintCircle(points,p,2.0,2);
    }
  }
  return(points);
}
  
void iftFastDilation(AnnImg *aimg, AdjRel *A)
{
  Image *Dx=NULL,*Dy=NULL;
  Queue *Q=NULL;
  Heap *H=NULL;
  int i,p,q,n,sz;
  Pixel u,v;
  int *sq=NULL,tmp=INT_MAX,dx,dy;
  bool cuisenaire;
  AdjRel *A8=Circular(1.5),*CA=NULL;
  char *color=NULL;

  if (aimg->seed == NULL)
    return;

  n  = MAX(aimg->img->ncols,aimg->img->nrows);
  sq = AllocIntArray(n);
  for (i=0; i < n; i++) 
    sq[i]=i*i;

  Dx = CreateImage(aimg->img->ncols,aimg->img->nrows);
  Dy = CreateImage(aimg->img->ncols,aimg->img->nrows);
  n  = aimg->img->ncols*aimg->img->nrows;
  color = AllocCharArray(n);
  sz = FrameSize(A);
  Q  = CreateQueue(2*sz*(sz+aimg->img->ncols+aimg->img->nrows),n);
  
  /* Compute IFT with 8-Adjacency */

  while (aimg->seed != NULL){
    p=RemoveSet(&(aimg->seed));
    InsertQueue(Q,aimg->cost->val[p]%Q->C.nbuckets,p);
    color[p]=GRAY;
  }

  while(!EmptyQueue(Q)) {
    p=RemoveQueue(Q);
    color[p]=BLACK;
    u.x = p%aimg->img->ncols;
    u.y = p/aimg->img->ncols;
    cuisenaire=true;
    for (i=1; i < A8->n; i++){
      v.x = u.x + A8->dx[i];
      v.y = u.y + A8->dy[i];
      if (ValidPixel(aimg->img,v.x,v.y)){
	q = v.x + aimg->img->tbrow[v.y];
	if (color[q] != BLACK){
	  dx  = Dx->val[p] + abs(v.x-u.x);
	  dy  = Dy->val[p] + abs(v.y-u.y);
	  tmp = sq[dx] + sq[dy];
	  if (tmp < aimg->cost->val[q]){
	      if (color[q] == WHITE){
		InsertQueue(Q,tmp%Q->C.nbuckets,q);
		color[q] = GRAY;
	      }else
		UpdateQueue(Q,q,aimg->cost->val[q]%Q->C.nbuckets,tmp%Q->C.nbuckets);
	      aimg->cost->val[q]  = tmp;
	      aimg->pred->val[q]  = p;
	      aimg->label->val[q] = aimg->label->val[p];
	      Dx->val[q] = dx;
	      Dy->val[q] = dy;
	      cuisenaire = false;
	    }
	} 
      }    
    }
    if (cuisenaire)    
      InsertSet(&(aimg->seed),p); 
  }

  DestroyQueue(&Q);
  free(color);
    
  /* Compute IFT with Complementary Adjacency */

  if (A8->n < A->n) {

    CA = ComplAdj(A8,A);
    H  = CreateHeap(n,aimg->cost->val);

    while (aimg->seed != NULL){
      p=RemoveSet(&(aimg->seed));
      InsertHeap(H,p);
    }

    while(!HeapIsEmpty(H)) {
      RemoveHeap(H,&p);
      u.x = p%aimg->img->ncols;
      u.y = p/aimg->img->ncols;
      for (i=0; i < CA->n; i++){
	v.x = u.x + CA->dx[i];
	v.y = u.y + CA->dy[i];
	if (ValidPixel(aimg->img,v.x,v.y)){
	  q = v.x + aimg->img->tbrow[v.y];
	  if (color[q]!=BLACK){
	    dx  = Dx->val[p] + abs(v.x-u.x);
	    dy  = Dy->val[p] + abs(v.y-u.y);
	    tmp = sq[dx] + sq[dy];
	    if (tmp < aimg->cost->val[q]) 
	      {
		aimg->cost->val[q]  = tmp;
		aimg->pred->val[q]  = p;
		aimg->label->val[q] = aimg->label->val[p];
		Dx->val[q] = dx;
		Dy->val[q] = dy;
		if (color[q] == WHITE){
		  InsertHeap(H,q);
		}else
		  GoUp(H,H->pos[q]);
	      }
	  }
	}    
      }
    }
    DestroyAdjRel(&CA);
    DestroyHeap(&H);
  }

  DestroyAdjRel(&A8);

  free(sq);
  DestroyImage(&Dx);
  DestroyImage(&Dy);
}

void iftDilation(AnnImg *aimg, AdjRel *A)
{
  Image *Dx=NULL,*Dy=NULL;
  Queue *Q=NULL;
  int i,p,q,n,sz;
  Pixel u,v;
  int *sq=NULL,tmp=INT_MAX,dx,dy;
  char *color=NULL;

  if (aimg->seed == NULL)
    return;

  n  = MAX(aimg->img->ncols,aimg->img->nrows);
  sq = AllocIntArray(n);
  for (i=0; i < n; i++) 
    sq[i]=i*i;

  Dx = CreateImage(aimg->img->ncols,aimg->img->nrows);
  Dy = CreateImage(aimg->img->ncols,aimg->img->nrows);
  n  = aimg->img->ncols*aimg->img->nrows;
  color = AllocCharArray(n);
  sz = FrameSize(A);
  Q  = CreateQueue(2*sz*(sz+aimg->img->ncols+aimg->img->nrows),n);
  
  while (aimg->seed != NULL){
    p=RemoveSet(&(aimg->seed));
    InsertQueue(Q,aimg->cost->val[p]%Q->C.nbuckets,p);
    color[p]=GRAY;
  }

  while(!EmptyQueue(Q)) {
    p=RemoveQueue(Q);
    color[p]=BLACK;
    u.x = p%aimg->img->ncols;
    u.y = p/aimg->img->ncols;
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(aimg->img,v.x,v.y)){
	q = v.x + aimg->img->tbrow[v.y];
	if (color[q] != BLACK){
	  dx  = Dx->val[p] + abs(v.x-u.x);
	  dy  = Dy->val[p] + abs(v.y-u.y);
	  tmp = sq[dx] + sq[dy];
	  if (tmp < aimg->cost->val[q])
	    {
	      if (color[q] == WHITE){
		InsertQueue(Q,tmp%Q->C.nbuckets,q);
		color[q]=GRAY;
	      }else
		UpdateQueue(Q,q,aimg->cost->val[q]%Q->C.nbuckets,tmp%Q->C.nbuckets);
	      aimg->cost->val[q]  = tmp;
	      aimg->pred->val[q]  = p;
	      aimg->label->val[q] = aimg->label->val[p];
	      Dx->val[q] = dx;
	      Dy->val[q] = dy;
	    }
	}
      }    
    }
  }
  free(color);
  free(sq);
  DestroyQueue(&Q);
  DestroyImage(&Dx);
  DestroyImage(&Dy);

}

void iftDilationHeap(AnnImg *aimg, AdjRel *A)
{
  Image *Dx=NULL,*Dy=NULL;
  Heap *H=NULL;
  int i,p,q,n;
  Pixel u,v;
  int *sq=NULL,tmp=INT_MAX,dx,dy;

  if (aimg->seed == NULL)
    return;

  n  = MAX(aimg->img->ncols,aimg->img->nrows);
  sq = AllocIntArray(n);
  for (i=0; i < n; i++) 
    sq[i]=i*i;

  Dx = CreateImage(aimg->img->ncols,aimg->img->nrows);
  Dy = CreateImage(aimg->img->ncols,aimg->img->nrows);
  n  = aimg->img->ncols*aimg->img->nrows;
  H  = CreateHeap(n,aimg->cost->val);
  
  while (aimg->seed != NULL){
    p=RemoveSet(&(aimg->seed));
    InsertHeap(H,p);
  }
  
  while(!HeapIsEmpty(H)) {
    RemoveHeap(H,&p);
    u.x = p%aimg->img->ncols;
    u.y = p/aimg->img->ncols;
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(aimg->img,v.x,v.y)){
	q = v.x + aimg->img->tbrow[v.y];
	if (H->color[q] != BLACK){
	  dx  = Dx->val[p] + abs(v.x-u.x);
	  dy  = Dy->val[p] + abs(v.y-u.y);
	  tmp = sq[dx] + sq[dy];
	  if (tmp < aimg->cost->val[q]){
	      aimg->cost->val[q]  = tmp;
	      aimg->pred->val[q]  = p;
	      aimg->label->val[q] = aimg->label->val[p];
	      Dx->val[q] = dx;
	      Dy->val[q] = dy;

	      if (H->color[q] == WHITE)
		InsertHeap(H,q);
	      else
		GoUp(H,H->pos[q]);
	    }
	}
      }    
    }
  }

  free(sq);
  DestroyHeap(&H);
  DestroyImage(&Dx);
  DestroyImage(&Dy);

}

int iftGeoDilation(AnnImg *aimg) /* Chamfer 17x24 */
{
  Queue *Q=NULL;
  Pixel u,v;
  int i,dst=-1,p,q,tmp,c;
  AdjRel *A=NULL;

  A = Circular(1.5);
  Q = CreateQueue(25,aimg->img->ncols*aimg->img->nrows);

  while (aimg->seed != NULL){
    p=RemoveSet(&(aimg->seed));
    if (aimg->label->val[p]==1)
      InsertQueue(Q,aimg->cost->val[p]%Q->C.nbuckets,p);
    else
      aimg->cost->val[p] = INT_MAX;
  }

  while(!EmptyQueue(Q)) {
    p=RemoveQueue(Q);
    if (aimg->label->val[p]==2){
      dst = p;
      break;
    }
    u.x = p%aimg->img->ncols;
    u.y = p/aimg->img->ncols;
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(aimg->img,v.x,v.y)){
	q = v.x + aimg->img->tbrow[v.y];
	if ((aimg->cost->val[p] < aimg->cost->val[q])&&(aimg->img->val[q]==1)){
	  if ((i%2)==0)
	    c = 24;
	  else
	    c = 17;	  
	  tmp = aimg->cost->val[p] + c;
	  if (tmp < aimg->cost->val[q]){
	    if (aimg->cost->val[q] == INT_MAX)
	      InsertQueue(Q,tmp%Q->C.nbuckets,q);
	    else
	      UpdateQueue(Q,q,aimg->cost->val[q]%Q->C.nbuckets,tmp%Q->C.nbuckets);
	    aimg->cost->val[q]  = tmp;
	    aimg->pred->val[q]  = p;
	    if (aimg->label->val[q] != 2) 
	      aimg->label->val[q] = aimg->label->val[p];
	  }
	}
      }    
    }
  }

  while(!EmptyQueue(Q)){
    p = RemoveQueue(Q);
    InsertSet(&(aimg->seed),p);
  }

  DestroyQueue(&Q);
  DestroyAdjRel(&A);

  return(dst);
}

Image *iftDistTrans(AnnImg *aimg, AdjRel *A, char side)
{
  int p,n;

  n = aimg->img->ncols*aimg->img->nrows;

  switch (side) {
  case INTERIOR:
    for(p = 0; p < n; p++)
      if (aimg->img->val[p] == 0)
	aimg->cost->val[p] = 0;
    break;
  case EXTERIOR:
    for(p = 0; p < n; p++)
      if ((aimg->img->val[p] == 1)&&(aimg->cost->val[p]==INT_MAX))
	aimg->cost->val[p] = 0;
    break;
  }

  iftDilation(aimg, A);
  return(CopyImage(aimg->cost));
}

Image *FastDistTrans(Image *bin, AdjRel *A, char side)
{
  Image *Dx=NULL,*Dy=NULL,*fcont,*cont,*fcost,*cost,*dil;
  Queue *Q1=NULL,*Q2=NULL;
  int i,p,q,n,sz;
  Pixel u,v;
  int *sq=NULL,tmp=INT_MAX,dx,dy;
  AdjRel *A4,*CA;
  AdjPxl *N4,*N;
  bool cuisenaire;
  char *color=NULL; 

  A4    = Circular(1.0);
  dil   = Dilate(bin,A4);
  cont  = Diff(dil,bin);
  DestroyImage(&dil);

  n  = MAX(bin->ncols,bin->nrows);
  sq = AllocIntArray(n);
  for (i=0; i < n; i++) 
    sq[i]=i*i;

  sz = FrameSize(A);
  fcont = AddFrame(cont,sz,INT_MIN);
  DestroyImage(&cont);
  fcost = AddFrame(bin,sz,INT_MIN);
  Dx = CreateImage(fcost->ncols,fcost->nrows);
  Dy = CreateImage(fcost->ncols,fcost->nrows);  
  N4 = AdjPixels(fcost,A4);
  n  = fcost->ncols*fcost->nrows;
  color = AllocCharArray(n);
  Q1 = CreateQueue(2*sz*(sz+bin->ncols+bin->nrows),n);
  Q2 = CreateQueue(2*sz*(sz+bin->ncols+bin->nrows),n);

  switch (side) {
  case INTERIOR:
    for(p = 0; p < n; p++){
      if (fcost->val[p] <= 0){
	if (fcont->val[p]==1){
	  fcost->val[p]=0;    
	  InsertQueue(Q1,fcost->val[p]%Q1->C.nbuckets,p);
	}
     }else{
       fcost->val[p] = INT_MAX;
     }
    }
    break;
  case EXTERIOR:
    for(p = 0; p < n; p++){
      if (fcost->val[p] == 0){
	fcost->val[p] = INT_MAX;
	if (fcont->val[p]==1){
	  fcost->val[p]=0;    
	  InsertQueue(Q1,fcost->val[p]%Q1->C.nbuckets,p);
	}
      }
    }
    break;
  case BOTH:
  default:    
    for(p = 0; p < n; p++){
      if (fcost->val[p] >= 0){
	fcost->val[p] = INT_MAX;
	if (fcont->val[p]==1){
	  fcost->val[p]=0;    
	  InsertQueue(Q1,fcost->val[p]%Q1->C.nbuckets,p);
	}
      }
    }
  }
  DestroyImage(&fcont);

  while(!EmptyQueue(Q1)) {
    p=RemoveQueue(Q1);
    cuisenaire=true;
    for (i=1; i < N4->n; i++){
      q = p + N4->dp[i];
      if (fcost->val[p] < fcost->val[q]){
	u.x = p%fcost->ncols;
	u.y = p/fcost->ncols;
	v.x = u.x + A4->dx[i];
	v.y = u.y + A4->dy[i];
	dx  = Dx->val[p] + abs(v.x-u.x);
	dy  = Dy->val[p] + abs(v.y-u.y);
	tmp = sq[dx] + sq[dy];
	if (tmp < fcost->val[q]){
	  if (fcost->val[q] == INT_MAX)
	    InsertQueue(Q1,tmp%Q1->C.nbuckets,q);
	  else
	    UpdateQueue(Q1,q,fcost->val[q]%Q1->C.nbuckets,tmp%Q1->C.nbuckets);
	    fcost->val[q]  = tmp;
	    Dx->val[q] = dx;
	    Dy->val[q] = dy;
	    cuisenaire = false;
	}
      }
    }
    if (cuisenaire){
      color[p]=GRAY;
      InsertQueue(Q2,fcost->val[p]%Q2->C.nbuckets,p);    
    }
  }

  DestroyQueue(&Q1);
  DestroyAdjPxl(&N4);

  if (A4->n < A->n) {

    CA = ComplAdj(A4,A);
    N  = AdjPixels(fcost,CA);

    while(!EmptyQueue(Q2)) {
      p=RemoveQueue(Q2);
      color[p]=BLACK;
      for (i=1; i < N->n; i++){
	q = p + N->dp[i];
	if (color[q] != BLACK){
	  u.x = p%fcost->ncols;
	  u.y = p/fcost->ncols;
	  v.x = u.x + CA->dx[i];
	  v.y = u.y + CA->dy[i];
	  dx  = Dx->val[p] + abs(v.x-u.x);
	  dy  = Dy->val[p] + abs(v.y-u.y);
	  tmp = sq[dx] + sq[dy];
	  if (tmp < fcost->val[q]){
	    if (color[q] == WHITE){
	      color[q]=GRAY;
	      InsertQueue(Q2,tmp%Q2->C.nbuckets,q);
	    } else
	      UpdateQueue(Q2,q,fcost->val[q]%Q2->C.nbuckets,tmp%Q2->C.nbuckets);
	    fcost->val[q]  = tmp;
	    Dx->val[q] = dx;
	    Dy->val[q] = dy;
	  }
	}
      }
    }
  }

  cost = RemFrame(fcost,sz);
  free(color);
  free(sq);
  DestroyQueue(&Q2);
  DestroyAdjRel(&CA);
  DestroyAdjRel(&A4);
  DestroyAdjPxl(&N);
  DestroyImage(&Dx);
  DestroyImage(&Dy);
  DestroyImage(&fcost);

  return(cost);
}

Image *DistTrans(Image *bin, AdjRel *A, char side)
{
  Image *Dx=NULL,*Dy=NULL,*fbin,*fcont,*fcost,*cost;
  Queue *Q=NULL;
  int i,p,q,n,sz;
  Pixel u,v;
  int *sq=NULL,tmp=INT_MAX,dx,dy;
  AdjPxl *N;
  char *color=NULL; 

  n  = MAX(bin->ncols,bin->nrows);
  sq = AllocIntArray(n);
  for (i=0; i < n; i++) 
    sq[i]=i*i;

  sz = FrameSize(A);  
  fbin = AddFrame(bin,sz,0);
  fcont = LabelContour(fbin);
  fcost = AddFrame(bin,sz,INT_MIN);
  Dx = CreateImage(fcost->ncols,fcost->nrows);
  Dy = CreateImage(fcost->ncols,fcost->nrows);  
  N  = AdjPixels(fcost,A);
  n  = fcost->ncols*fcost->nrows;
  color = AllocCharArray(n);
  Q = CreateQueue(2*sz*(sz+bin->ncols+bin->nrows),n);

  switch (side) {
  case INTERIOR:
    for(p = 0; p < n; p++){
      if (fbin->val[p] == 1){
	if (fcont->val[p]>0){
	  fcost->val[p]=0;    
	  InsertQueue(Q,fcost->val[p]%Q->C.nbuckets,p);
	} else
	  fcost->val[p] = INT_MAX;	  
     }else{
       if (fcost->val[p]!=INT_MIN)
	 fcost->val[p] = 0;
     }
    }
    break;
  case EXTERIOR:
    for(p = 0; p < n; p++){
      if (fbin->val[p] == 0){
	if (fcost->val[p]!=INT_MIN)
	  fcost->val[p] = INT_MAX;	  
      }else{
	if (fcont->val[p]>0){
	  fcost->val[p]=0;    
	  InsertQueue(Q,fcost->val[p]%Q->C.nbuckets,p);
	}else
	  fcost->val[p] = 0;
      }
    }
    break;
  case BOTH:
  default:    
    for(p = 0; p < n; p++){
      if (fcont->val[p] > 0){
	fcost->val[p]=0;    
	InsertQueue(Q,fcost->val[p]%Q->C.nbuckets,p);
      }else{ 
	if (fcost->val[p]!=INT_MIN)
	  fcost->val[p]=INT_MAX;    
      }
    }
  }

  DestroyImage(&fcont);
  DestroyImage(&fbin);

  while(!EmptyQueue(Q)) {
    p=RemoveQueue(Q);
    for (i=1; i < N->n; i++){
      q = p + N->dp[i];
      if (fcost->val[p] < fcost->val[q]){
	u.x = p%fcost->ncols;
	u.y = p/fcost->ncols;
	v.x = u.x + A->dx[i];
	v.y = u.y + A->dy[i];
	dx  = Dx->val[p] + abs(v.x-u.x);
	dy  = Dy->val[p] + abs(v.y-u.y);
	tmp = sq[dx] + sq[dy];
	if (tmp < fcost->val[q]){
	  if (fcost->val[q] == INT_MAX)
	    InsertQueue(Q,tmp%Q->C.nbuckets,q);
	  else
	    UpdateQueue(Q,q,fcost->val[q]%Q->C.nbuckets,tmp%Q->C.nbuckets);
	    fcost->val[q]  = tmp;
	    Dx->val[q] = dx;
	    Dy->val[q] = dy;
	}
      }
    }
  }

  DestroyQueue(&Q);
  DestroyAdjPxl(&N);
  cost = RemFrame(fcost,sz);
  free(color);
  free(sq);
  DestroyImage(&Dx);
  DestroyImage(&Dy);
  DestroyImage(&fcost);

  return(cost);
}

int iftGeoDist(AnnImg *aimg)
{
  int dist=INT_MAX,p;

  p    = iftGeoDilation(aimg);
  if (p != -1)
    dist = aimg->cost->val[p];
  return(dist);
}

int *iftGeoPath(AnnImg *aimg)
{
  int p, *path = NULL;

  p    = iftGeoDilation(aimg);
  if (p != -1)
    path = Path(aimg->pred,p);
  return(path);
}

Curve *MSFractal(Image *shape, int maxdist)
{
  Curve *fractal=NULL,*hist=NULL,*haux=NULL,*ahist=NULL;
  AnnImg *aimg=NULL;
  AdjRel *A=NULL;
  Image *mbb=NULL,*nbin=NULL;
  int n,i,j,maxcost=maxdist*maxdist;
  Polynom *P=NULL,*D=NULL;
  double lower=MAX(0.1*log(maxdist),0.5), higher=MAX(0.9*log(maxdist),lower+5.0), inc=(higher-lower)/100.0;

  mbb  = MBB(shape);
  nbin = AddFrame(mbb,maxdist,0);
  DestroyImage(&mbb);

  /* Compute Euclidean IFT */

  A = Circular(1.5);
  aimg = Annotate(nbin,NULL,nbin);
  n = aimg->img->ncols*aimg->img->nrows;
  iftDilation(aimg, A);
  DestroyAdjRel(&A);

  /* Compute MS Fractal */

  hist = Histogram(aimg->cost);

  /* Compute non-zero points */

  n = 0;
  for (i=1; i < maxcost; i++)
    if (hist->Y[i] != 0)
      n++;

  haux = CreateCurve(n);
  j=0;
  for (i=1; i < maxcost; i++)
    if (hist->Y[i] != 0){
      haux->X[j] = log(sqrt((double)i));
      haux->Y[j] = hist->Y[i];
      j++;
    }
  
  /* Accumulate values */

  ahist = CreateCurve(n);
  ahist->X[0] = haux->X[0];
  ahist->Y[0] = haux->Y[0];
  for (i=1; i < n; i++) {
    ahist->X[i] = haux->X[i];
    ahist->Y[i] = ahist->Y[i-1] + haux->Y[i];
  }

  /* Compute log(Y) */

  for (i=0; i < n; i++)
    ahist->Y[i] = log((double)ahist->Y[i]);
    
  /* Compute Regression */

  P = Regression(ahist,10);
  
  /* Compute Fractal Curve */

  D = DerivPolynom(P);

  fractal = SamplePolynom(D,lower,higher,inc);
  
  for (i=0; i < fractal->n; i++) {
    fractal->Y[i] = 2.0 - fractal->Y[i];
  }

  DestroyCurve(&hist);
  DestroyCurve(&haux);
  DestroyCurve(&ahist);
  DestroyPolynom(&P);
  DestroyPolynom(&D);
  DeAnnotate(&aimg);
  DestroyImage(&nbin);

  return(fractal);
}

Image *MSSkel(Image *bin, char side)
{
  Image *msskel,*cont;
  AdjRel *A;
  AnnImg *aimg;
  int p,n;

  /* Compute Euclidean IFT */

  cont   = LabelContPixel(bin);
  aimg   = Annotate(bin,NULL,cont); 
  A      = Circular(1.5);
  n      = aimg->img->ncols*aimg->img->nrows;
  switch (side) {
  case INTERIOR:
    for(p = 0; p < n; p++)
      if (aimg->img->val[p] == 0){
	aimg->cost->val[p] = 0;
      }
    break;
  case EXTERIOR:
    for(p = 0; p < n; p++)
      if (aimg->img->val[p] == 1){
	aimg->cost->val[p] = 0;
      }
    break;
  case BOTH:
  default:    
  }
  iftDilation(aimg,A);
  DestroyAdjRel(&A);
  DestroyImage(&cont);
  
  /* Compute MS Skeletons */

  msskel = CompMSSkel(aimg);
  DeAnnotate(&aimg);

  return(msskel);
}

Image *SKIZ(Image *bin, char side)
{
  Image *skiz,*cont;
  AdjRel *A;
  AnnImg *aimg;
  int p,n;

  /* Compute Euclidean IFT */

  cont   = LabelContour(bin);
  aimg   = Annotate(bin,NULL,cont); 
  A      = Circular(1.5);
  n      = aimg->img->ncols*aimg->img->nrows;
  switch (side) {
  case INTERIOR:
    for(p = 0; p < n; p++)
      if (aimg->img->val[p] == 0){
	aimg->cost->val[p] = 0;
      }
    break;
  case EXTERIOR:
    for(p = 0; p < n; p++)
      if (aimg->img->val[p] == 1){
	aimg->cost->val[p] = 0;
      }
    break;
  case BOTH:
  default:    
  }
  iftDilation(aimg,A);
  DestroyAdjRel(&A);
  DestroyImage(&cont);
  
  /* Compute SKIZ */
  
  skiz = CompSKIZ(aimg);
  DeAnnotate(&aimg);
  
  return(skiz);
}

Image *LabelSkel(Image *skel, Curve3D *curve, char option)
{
  
  Image *mainbody = NULL;
  Image *label = NULL;
  Image *dist = NULL;
  Image *parent = NULL;
  Image *length = NULL;
  Image *output = NULL;
  char  *color = NULL;
  AdjRel *A;
  Queue *Q;
  Pixel u, v;
  int p, q, r, i, j, n, maxlabel, maxdist;
  
  n = skel->ncols*skel->nrows;
  color      = AllocCharArray(n);
  mainbody   = CreateImage(skel->ncols,skel->nrows);
  label      = CreateImage(skel->ncols,skel->nrows);
  dist       = CreateImage(skel->ncols,skel->nrows);
  parent     = CreateImage(skel->ncols,skel->nrows);
  length     = CreateImage(skel->ncols,skel->nrows);
  A          = Circular(1.5);
  for (p=0; p<n; p++){
    if (skel->val[p]==1){
      j = 0;
      u.x = p%skel->ncols;
      u.y = p/skel->ncols;
      for (i=1; i < A->n; i++){
	v.x = u.x + A->dx[i];
	v.y = u.y + A->dy[i];
	if (ValidPixel(skel,v.x,v.y)){
	  q = v.x + skel->tbrow[v.y];
	  if (skel->val[q]!=0)
	    j++;
	}
      }
      if (j>3)
	mainbody->val[p] = 1;
    }
  }
  DestroyAdjRel(&A); 

  for (i=0; i<curve->n; i++){
    if (curve->Z[i]>0.0){
      p = (int)curve->X[i]+skel->tbrow[(int)curve->Y[i]];
      label->val[p]  = (int)curve->Z[i];
      dist->val[p]   = 1;
      parent->val[p] = p;
    }
  }
    
  maxlabel = MaximumValue(label);
  
  Q        = CreateQueue(maxlabel+2,n);
  A        = Circular(1.5); 
  
  for (p=0; p<n; p++)
    if (label->val[p] !=0){
      color[p]=GRAY;
      InsertQueue(Q,label->val[p],p);
    }
  
  while(!EmptyQueue(Q)) {
    p = RemoveQueue(Q);
    color[p]=BLACK;
    n = 0;
    u.x = p%skel->ncols;
    u.y = p/skel->ncols;
    for (i=1; i < A->n; i++){
      v.x = u.x + A->dx[i];
      v.y = u.y + A->dy[i];
      if (ValidPixel(skel,v.x,v.y)){
	q = v.x + skel->tbrow[v.y];
	if (skel->val[q]==1){
	  if (color[q] != BLACK){
	    if (mainbody->val[q]==0){
	      if (color[q] == WHITE){
		n++;
		color[q]=GRAY;
		InsertQueue(Q,label->val[p],q);
		label->val[q] = label->val[p];
		dist->val[q] = dist->val[p] + 1;
		parent->val[q] = p;
	      }
	    }
	    else{
	      r = p;
	      while (r!=parent->val[r]){
		length->val[r] = dist->val[p];
		r = parent->val[r];
	      }
	      length->val[r] = dist->val[p];
		
	      if (color[q] == WHITE){
		n++;
		color[q] = GRAY;
		InsertQueue(Q, maxlabel+1,q);
		label->val[q] = maxlabel+1;
		dist->val[q] = dist->val[p] + 1;
	      }
	    }
	  }
	}
      }
    }
    if (n==0){
      r = p;
      while (r!=parent->val[r]){
	length->val[r] = dist->val[p];
	r = parent->val[r];
      }
      length->val[r] = dist->val[p];
    }
  }
  
  maxdist = MaximumValue(dist);
  n = skel->ncols*skel->nrows;
  for (p=0; p<n; p++)
    if (label->val[p]==(maxlabel+1)){
      dist->val[p] = maxdist + 1;
      length->val[p] = maxdist + 1;
    }
      
  switch (option) {
  case 0:
    output = CopyImage(label);
    break;
  case 1:
    output = CopyImage(dist);
    break;
  case 2:
    output = CopyImage(length);
    break;
  }

  DestroyAdjRel(&A); 
  DestroyQueue(&Q);
  DestroyImage(&mainbody);
  DestroyImage(&label);
  DestroyImage(&dist);
  DestroyImage(&parent);
  DestroyImage(&length);
  free(color);
  return(output);
}
 
Curve3D *ContSaliences(Image *bin,int maxdist,int threshold,int angle)
{
  int x, y, i;
  Pixel right, left;
  Curve3D *cont_salie = NULL;
  Curve3D *salie_int = NULL;   
  Curve3D *salie_ext = NULL; 
  Curve3D *saliences = NULL;
    
  salie_int = SkelCont(bin, maxdist, threshold, angle, INTERIOR);
  salie_ext = SkelCont(bin, maxdist, (int)2*threshold, angle, EXTERIOR);
    
  left.x  = bin->ncols-1;
  left.y  = bin->nrows-1;
  right.x = 0;
  right.y = 0;
  for (y=0; y < bin->nrows; y++)
    for (x=0; x < bin->ncols; x++){
      if (bin->val[x+bin->tbrow[y]] > 0){
	if (x < left.x)
	  left.x = x;
	if (y < left.y)
	  left.y = y;
	if (x > right.x)
	  right.x = x;
	if (y > right.y)
	  right.y = y;	
      }
    }
  
  for (i=0; i<salie_ext->n; i++){
    if ((salie_ext->X[i]<left.x)||
	(salie_ext->X[i]>right.x)||
	(salie_ext->Y[i]<left.y)||
	(salie_ext->Y[i]>right.y))
      salie_ext->Z[i] = 0.0;
  }
    
  cont_salie = Saliences(bin, maxdist);
  saliences  = CreateCurve3D(cont_salie->n);
  for (i=0; i<salie_int->n; i++){
    if (salie_int->Z[i]>0.0){
      saliences->X[(int)salie_int->Z[i]-1] = cont_salie->X[(int)salie_int->Z[i]-1];
      saliences->Y[(int)salie_int->Z[i]-1] = cont_salie->Y[(int)salie_int->Z[i]-1];
      saliences->Z[(int)salie_int->Z[i]-1] = cont_salie->Z[(int)salie_int->Z[i]-1];
    }
  }
  for (i=0; i<salie_ext->n; i++){
    if (salie_ext->Z[i]>0.0){
      saliences->X[(int)salie_ext->Z[i]-1] = cont_salie->X[(int)salie_ext->Z[i]-1];
      saliences->Y[(int)salie_ext->Z[i]-1] = cont_salie->Y[(int)salie_ext->Z[i]-1];
      saliences->Z[(int)salie_ext->Z[i]-1] = cont_salie->Z[(int)salie_ext->Z[i]-1];
    }
  }

  DestroyCurve3D(&cont_salie);
  DestroyCurve3D(&salie_int);   
  DestroyCurve3D(&salie_ext);
  return(saliences);
}

Curve3D *Saliences(Image *bin, int maxdist) 
{  
  Image *cont=NULL;
  AdjRel *A=NULL;
  AnnImg *aimg=NULL;
  Curve3D *saliences=NULL;
  
  /* Compute Euclidean IFT */
  
  cont    = LabelContPixel(bin);
  aimg    = Annotate(bin,NULL,cont); 
  A       = Circular(1.5);
  iftDilation(aimg,A);
  saliences = CompSaliences(aimg, maxdist*maxdist);
  
  DestroyImage(&cont);
  DestroyAdjRel(&A);
  DeAnnotate(&aimg);
  
  return(saliences);
}

Curve3D *SkelSaliences(Image *skel, int maxdist, int angle) 
{  
  Image *cont=NULL;
  AdjRel *A=NULL;
  AnnImg *aimg=NULL;
  Curve3D *saliences=NULL;
  Curve3D *auxsalie=NULL;

  /* Compute Euclidean IFT */
  A         = Circular(0.0);
  cont      = LabelBinComp(skel, A);
  aimg      = Annotate(skel,NULL,cont);
  DestroyAdjRel(&A); 

  A         = Circular(1.5);
  iftDilation(aimg,A);
  auxsalie  = CompSaliences(aimg, maxdist*maxdist);
  saliences = RemSaliencesByAngle(auxsalie,maxdist,angle);
  DestroyImage(&cont);
  DestroyAdjRel(&A);
  DeAnnotate(&aimg);
  DestroyCurve3D(&auxsalie);
  return(saliences);
}

Curve3D *SkelCont(Image *bin, int maxdist, int threshold, int angle, char side) 
{  
  Image   *cont=NULL;
  Image   *msskel=NULL;
  Image   *skel=NULL;
  Image   *bin_skel=NULL;
  Image   *label_skel=NULL;
  AdjRel  *A=NULL;
  AnnImg  *aimg=NULL;
  Curve3D *saliences=NULL;
  Curve3D *auxsalie=NULL;
  Curve3D *cont_salie=NULL;
  int i, j, p, q, n, label, imax, max, min, imin;
  
  /* Compute MS Skeletons */

  cont   = LabelContPixel(bin);
  aimg   = Annotate(bin,NULL,cont); 
  A      = Circular(1.5);
  n      = aimg->img->ncols*aimg->img->nrows;
  switch (side) {
  case INTERIOR:
    for(p = 0; p < n; p++)
      if (aimg->img->val[p] == 0){
	aimg->cost->val[p] = 0;
      }
    break;
  case EXTERIOR:
    for(p = 0; p < n; p++)
      if (aimg->img->val[p] == 1){
	aimg->cost->val[p] = 0;
      }
    break;
  case BOTH:
  default:    
  }
  iftDilation(aimg,A);
  
  msskel   = CompMSSkel(aimg);
  skel     = Skeleton(msskel, threshold);
  bin_skel = Skeleton(msskel, threshold);
  cont_salie = Saliences(bin, maxdist);
  for (p=0; p<n; p++){
    if (skel->val[p]==1){
      q = Seed(aimg->pred, p);
      label = (aimg->label->val[q] + msskel->val[p]/2 + MaximumValue(cont))%MaximumValue(cont);
      skel->val[p] = label;
      if (side == INTERIOR){
	if (cont_salie->Z[label-1]<0.0){
	  max = INT_MIN;
	  imax = 0;
	  for (j=-5; j<5; j++){
	    if (cont_salie->Z[(label-1+j+cont_salie->n)%cont_salie->n] > max){
	      imax = (label-1+j+cont_salie->n)%cont_salie->n;
	      max = cont_salie->Z[imax];
	    }
	  }
	  skel->val[p] = imax + 1;
	}
	else {
	  skel->val[p] = label;
	}
      }
      else{ 
	if (side == EXTERIOR){
	  if (cont_salie->Z[label-1]>0.0){
	    min = INT_MAX;
	    imin = 0;
	    for (j=-5; j<5; j++){
	      if (cont_salie->Z[(label-1+j+cont_salie->n)%cont_salie->n] < min){
		imin = (label-1+j+cont_salie->n)%cont_salie->n;
		min = cont_salie->Z[imin];
	      }
	    }
	    skel->val[p] = imin + 1;
	  }
	  else {
	    skel->val[p] = label;
	  }
	}
      }
    }
  }

  DestroyAdjRel(&A);
  DeAnnotate(&aimg);
  /* Compute Skeleton Saliences */
  A          = Circular(0.0);
  label_skel = LabelBinComp(bin_skel, A);
  aimg       = Annotate(label_skel,NULL,label_skel);
  DestroyAdjRel(&A); 
  
  A       = Circular(1.5);
  iftDilation(aimg,A);
  auxsalie = CompSaliences(aimg, maxdist*maxdist);
  saliences = RemSaliencesByAngle(auxsalie,maxdist,angle);
    
  for (i=0; i< saliences->n; i++){
    if (saliences->Z[i]!=0){
      p = (int)saliences->X[i]+bin->tbrow[(int)saliences->Y[i]];
      saliences->Z[i] = skel->val[p];
    }  
  }
  
  DestroyImage(&cont);
  DestroyImage(&label_skel);
  DestroyImage(&msskel);
  DestroyImage(&skel);
  DestroyImage(&bin_skel);
  DestroyCurve3D(&auxsalie);
  DestroyCurve3D(&cont_salie);
  DestroyAdjRel(&A);
  DeAnnotate(&aimg);
  return(saliences);
}



   
