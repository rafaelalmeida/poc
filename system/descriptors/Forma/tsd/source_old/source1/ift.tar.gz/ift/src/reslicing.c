#include "reslicing.h"

Scene *ResliceScene(Scene *scn, Context *cxt, Plane *pl, \
		    float alpha, int nslices)
{
  Scene *res;
  float z,u1,v1;
  int u,v,i,usize,vsize;
  Voxel w,w1;
  float Rx[4][4],Ry[4][4],R[4][4],d;

  usize = cxt->zbuff->usize;
  vsize = cxt->zbuff->vsize;
  d = sqrt(pl->normal.y*pl->normal.y + pl->normal.z*pl->normal.z);
  R[0][0] = Ry[0][0] = d;
  R[0][1] = Ry[0][1] = 0.0;
  R[0][2] = Ry[0][2] = pl->normal.x;
  R[0][3] = Ry[0][3] = 0.0;
  R[1][0] = Ry[1][0] = 0.0;
  R[1][1] = Ry[1][1] = 1.0;
  R[1][2] = Ry[1][2] = 0.0;
  R[1][3] = Ry[1][3] = 0.0;
  R[2][0] = Ry[2][0] = -pl->normal.x;
  R[2][1] = Ry[2][1] = 0.0;
  R[2][2] = Ry[2][2] = d;
  R[2][3] = Ry[2][3] = 0.0;
  R[3][0] = Ry[3][0] = 0.0;
  R[3][1] = Ry[3][1] = 0.0;
  R[3][2] = Ry[3][2] = 0.0;
  R[3][3] = Ry[3][3] = 1.0;

  if (d != 0.0){
    Rx[0][0] = 1.0;
    Rx[0][1] = 0.0;
    Rx[0][2] = 0.0;
    Rx[0][3] = 0.0;
    Rx[1][0] = 0.0;
    Rx[1][1] = pl->normal.z/d;
    Rx[1][2] = pl->normal.y/d;
    Rx[1][3] = 0.0;
    Rx[2][0] = 0.0;
    Rx[2][1] = -pl->normal.y/d;
    Rx[2][2] = pl->normal.z/d;
    Rx[2][3] = 0.0;
    Rx[3][0] = 0.0;
    Rx[3][1] = 0.0;
    Rx[3][2] = 0.0;
    Rx[3][3] = 1.0;    
    MultMatrices(Rx,Ry,R);
  } 

  res = CreateScene(usize,vsize,nslices);

  for (i=0; i < nslices; i++) {

    if (pl->po.z < 0)
      z = -sqrt(pl->po.x*pl->po.x + pl->po.y*pl->po.y + pl->po.z*pl->po.z);    
    else
      z = +sqrt(pl->po.x*pl->po.x + pl->po.y*pl->po.y + pl->po.z*pl->po.z);    
    for (v=0; v < vsize; v++) 
      for (u=0; u < usize; u++) {
	u1   = u - usize/2;
	v1   = v - vsize/2;
	w1.x  =(u1*R[0][0] + v1*R[0][1] + z*R[0][2]); 
	w1.y  =(u1*R[1][0] + v1*R[1][1] + z*R[1][2]);
	w.x = w1.x + scn->xsize/2;
	w.y = w1.y + scn->ysize/2;
	if ((w.x >= cxt->xmin)&&(w.x <= cxt->xmax)&&
	    (w.y >= cxt->ymin)&&(w.y <= cxt->ymax)){
	  w1.z = (int) (u1*R[2][0] + v1*R[2][1] + z*R[2][2]);
	  w.z  = w1.z + scn->zsize/2;
	  if ((w.z >= cxt->zmin)&&(w.z <= cxt->zmax)){
	    res->data[u + res->tby[v] + res->tbz[i]] = 
	      scn->data[w.x + scn->tby[w.y] + scn->tbz[w.z]];
	  }
	}
      }
    TranslatePlane(pl,alpha);
  }
  return(res);
}

Image *SliceScene(Scene *scn, Context *cxt, Plane *pl)
{
  Image *img;
  float z;
  int u,v,u1,v1,usize,vsize;
  Voxel w,w1;
  float Rx[4][4],Ry[4][4],R[4][4],d;

  usize = cxt->zbuff->usize;
  vsize = cxt->zbuff->vsize;

  d = sqrt(pl->normal.y*pl->normal.y + pl->normal.z*pl->normal.z);
  R[0][0] = Ry[0][0] = d;
  R[0][1] = Ry[0][1] = 0.0;
  R[0][2] = Ry[0][2] = pl->normal.x;
  R[0][3] = Ry[0][3] = 0.0;
  R[1][0] = Ry[1][0] = 0.0;
  R[1][1] = Ry[1][1] = 1.0;
  R[1][2] = Ry[1][2] = 0.0;
  R[1][3] = Ry[1][3] = 0.0;
  R[2][0] = Ry[2][0] = -pl->normal.x;
  R[2][1] = Ry[2][1] = 0.0;
  R[2][2] = Ry[2][2] = d;
  R[2][3] = Ry[2][3] = 0.0;
  R[3][0] = Ry[3][0] = 0.0;
  R[3][1] = Ry[3][1] = 0.0;
  R[3][2] = Ry[3][2] = 0.0;
  R[3][3] = Ry[3][3] = 1.0;

  if (d != 0.0){
    Rx[0][0] = 1.0;
    Rx[0][1] = 0.0;
    Rx[0][2] = 0.0;
    Rx[0][3] = 0.0;
    Rx[1][0] = 0.0;
    Rx[1][1] = pl->normal.z/d;
    Rx[1][2] = pl->normal.y/d;
    Rx[1][3] = 0.0;
    Rx[2][0] = 0.0;
    Rx[2][1] = -pl->normal.y/d;
    Rx[2][2] = pl->normal.z/d;
    Rx[2][3] = 0.0;
    Rx[3][0] = 0.0;
    Rx[3][1] = 0.0;
    Rx[3][2] = 0.0;
    Rx[3][3] = 1.0;    
    MultMatrices(Rx,Ry,R);
  } 

  img = CreateImage(usize,vsize);
  if (pl->po.z < 0)
    z = -sqrt(pl->po.x*pl->po.x + pl->po.y*pl->po.y + pl->po.z*pl->po.z);
  else 
    z = +sqrt(pl->po.x*pl->po.x + pl->po.y*pl->po.y + pl->po.z*pl->po.z);

  for (v=0; v < vsize; v++) 
    for (u=0; u < usize; u++) {
      u1   = u - usize/2;
      v1   = v - vsize/2;
      w1.x  = u1*R[0][0] + v1*R[0][1] + z*R[0][2]; 
      w1.y  = u1*R[1][0] + v1*R[1][1] + z*R[1][2];
      w.x = w1.x + scn->xsize/2;
      w.y = w1.y + scn->ysize/2;
      if ((w.x >= cxt->xmin)&&(w.x <= cxt->xmax)&&
	  (w.y >= cxt->ymin)&&(w.y <= cxt->ymax)){
	w1.z = (int) (u1*R[2][0] + v1*R[2][1] + z*R[2][2]);
	w.z  = w1.z + scn->zsize/2;
	if ((w.z >= cxt->zmin)&&(w.z <= cxt->zmax)){
	  img->val[u + v*usize] = 
	    scn->data[w.x + scn->tby[w.y] + scn->tbz[w.z]];
	}
      }
    }
  return(img);
}
