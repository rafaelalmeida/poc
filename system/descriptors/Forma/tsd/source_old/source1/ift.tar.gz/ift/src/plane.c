#include "plane.h"

Plane    *CreatePlane()
{
  Plane *pl=NULL;

  pl = (Plane *) calloc(1,sizeof(Plane));
  if (pl == NULL) 
    Error(MSG1,"CreatePlane");
  pl->normal.x = 0.0; pl->normal.y = 0.0; pl->normal.z = 1.0;
  pl->po.x = 0.0;
  pl->po.y = 0.0;
  pl->po.z = 0.0;
 
  return(pl);
}

void      DestroyPlane(Plane **pl)
{
  Plane *aux=*pl;

  if (aux != NULL) {
    free(aux);
    *pl = NULL;
  }
}

void RotatePlane(Plane *pl, float thx, float thy, float thz)
{
  Vector n;
  float Rx[4][4],Ry[4][4],Rz[4][4],R[4][4];
  float M[4][4];
  float thx1,thy1,thz1;
  double trash;

  thx1 = 360.*modf(thx/360.,&trash);
  if (thx1 < 0.0)
    thx1 += 360.0;
  thy1 = 360.*modf(thy/360.,&trash);
  if (thy1 < 0.0)
    thy1 += 360.0;
  thz1 = 360.*modf(thz/360.,&trash);
  if (thz1 < 0.0)
    thz1 += 360.0;
  
  thx      = thx1*PI/180.;
  thy      = thy1*PI/180.;
  thz      = thz1*PI/180.;

  Rx[0][0] = 1.0;
  Rx[0][1] = 0.0;
  Rx[0][2] = 0.0;
  Rx[0][3] = 0.0;
  Rx[1][0] = 0.0;
  Rx[1][1] = cos(thx);
  Rx[1][2] = -sin(thx);
  Rx[1][3] = 0.0;
  Rx[2][0] = 0.0;
  Rx[2][1] = sin(thx);
  Rx[2][2] = cos(thx);
  Rx[2][3] = 0.0;
  Rx[3][0] = 0.0;
  Rx[3][1] = 0.0;
  Rx[3][2] = 0.0;
  Rx[3][3] = 1.0;

  Ry[0][0] = cos(thy);
  Ry[0][1] = 0.0;
  Ry[0][2] = sin(thy);
  Ry[0][3] = 0.0;
  Ry[1][0] = 0.0;
  Ry[1][1] = 1.0;
  Ry[1][2] = 0.0;
  Ry[1][3] = 0.0; 
  Ry[2][0] = -sin(thy);
  Ry[2][1] = 0.0;
  Ry[2][2] = cos(thy);
  Ry[2][3] = 0.0;
  Ry[3][0] = 0.0;
  Ry[3][1] = 0.0;
  Ry[3][2] = 0.0;
  Ry[3][3] = 1.0;

  Rz[0][0] = cos(thz);
  Rz[0][1] = -sin(thz);
  Rz[0][2] = 0.0;
  Rz[0][3] = 0.0;
  Rz[1][0] = sin(thz);
  Rz[1][1] = cos(thz);
  Rz[1][2] = 0.0;
  Rz[1][3] = 0.0; 
  Rz[2][0] = 0.0;
  Rz[2][1] = 0.0;
  Rz[2][2] = 1.0;
  Rz[2][3] = 0.0;
  Rz[3][0] = 0.0;
  Rz[3][1] = 0.0;
  Rz[3][2] = 0.0;
  Rz[3][3] = 1.0;

  /* Rz*Ry*Rx */

  MultMatrices(Ry,Rx,M);
  MultMatrices(Rz,M,R);
  
  n.x = pl->normal.x;
  n.y = pl->normal.y;
  n.z = pl->normal.z;

  pl->normal.x = n.x*R[0][0] + n.y*R[0][1] + n.z*R[0][2];
  pl->normal.y = n.x*R[1][0] + n.y*R[1][1] + n.z*R[1][2];
  pl->normal.z = n.x*R[2][0] + n.y*R[2][1] + n.z*R[2][2];
}

void TranslatePlane(Plane *pl, float alpha)
{
  if (pl->normal.x < 0)
  pl->po.x -= alpha*pl->normal.x;
  else
    pl->po.x += alpha*pl->normal.x;

  if (pl->normal.y < 0)
  pl->po.y -= alpha*pl->normal.y;
  else
    pl->po.y += alpha*pl->normal.y;


  if (pl->normal.z < 0)
    pl->po.z -= alpha*pl->normal.z;
  else
    pl->po.z += alpha*pl->normal.z;
 }

/* n must be >= 3 */

void RotatePlaneAux(Plane *pl, float thx, float thy, float thz){
  
  pl->normal.x=0.0;
  pl->normal.y=0.0;
  pl->normal.z=1.0;
  RotatePlane(pl,thx,thy,thz);
  
}

void TranslatePlaneAux(Plane *pl, float alpha){
  pl->po.x=0.0;
  pl->po.y=0.0;
  pl->po.z=0.0;
  TranslatePlane(pl,alpha);
}

Plane *FacePlane(Vertex *vert, int n) 
{
  Plane *pl=NULL;
  Vector v1,v2,normal;
  float mag;
  int i;

  pl   = CreatePlane();
  v2.x = vert[0].x - vert[1].x;
  v2.y = vert[0].y - vert[1].y;
  v2.z = vert[0].z - vert[1].z;
  v1.x = vert[2].x - vert[1].x;
  v1.y = vert[2].y - vert[1].y;
  v1.z = vert[2].z - vert[1].z;  
  normal = VectorProd(v1,v2);
  mag    = sqrt(normal.x*normal.x + normal.y*normal.y + normal.z*normal.z);
  pl->normal.x = normal.x/mag;
  pl->normal.y = normal.y/mag;
  pl->normal.z = normal.z/mag;
  for (i=0; i < n; i++) {
    pl->po.x += vert[i].x;
    pl->po.y += vert[i].y;
    pl->po.z += vert[i].z;
  }
  pl->po.x /= n;
  pl->po.y /= n;
  pl->po.z /= n;

  return(pl);
}
