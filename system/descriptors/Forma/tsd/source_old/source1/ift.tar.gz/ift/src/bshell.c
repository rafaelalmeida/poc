#include "bshell.h"
#include "shading.h"
#include "adjacency.h"
#include "common.h"
#include "geometry.h"

BShell *CreateBShell (Scene *scn) {

  BShell *bshell=NULL;
  int i,n,index,Vind;
  Voxel v;

  bshell=(BShell *)calloc(1, sizeof(BShell));
  if (bshell == NULL){
    Error(MSG1,"CreateBShell");
  }

  n = scn->xsize * scn->ysize * scn->zsize; 

  bshell->nvoxels=0;
  for (i=0;i<n;i++)  
    if (scn->data[i] != 0) 
      bshell->nvoxels++;

  bshell->xsize = scn->xsize;
  bshell->ysize = scn->ysize;
  bshell->zsize = scn->zsize;

  bshell->voxel=(BAttrib *)calloc(bshell->nvoxels, sizeof(BAttrib));
  if (bshell->voxel == NULL) {
    Error(MSG1,"CreateBBshell");
  }

  bshell->pointer=(PAttrib *)calloc(bshell->nvoxels, sizeof(PAttrib));
  if (bshell->pointer == NULL) {
    Error(MSG1,"CreateBShell");
  }

  /* Myz and Mzx */

  bshell->Myz=CreateImage(scn->ysize, scn->zsize+1);
  bshell->Mzx=CreateImage(scn->zsize, scn->xsize+1);  

  SetImage(bshell->Myz,-1);
  SetImage(bshell->Mzx,-1);

  bshell->Mzx->val[scn->zsize*scn->xsize] = bshell->nvoxels;
  bshell->Myz->val[scn->zsize*scn->ysize] = bshell->nvoxels;

  bshell->normaltable = CreateNormalTable();

  i=0;

  for(v.z=0;v.z<scn->zsize;v.z++)
    for(v.y=0;v.y<scn->ysize;v.y++)
      for(v.x=0;v.x<scn->xsize;v.x++) { 
	Vind = scn->tbz[v.z] + scn->tby[v.y] + v.x;
        if (scn->data[Vind] != 0) {
	  index = bshell->Myz->tbrow[v.z] + v.y;
	  if (bshell->Myz->val[index] < 0) {
	    bshell->Myz->val[index]=i;
	  }
  	  bshell->voxel[i].x = v.x;
	  bshell->voxel[i].opac = 1.;
	  bshell->voxel[i].val = scn->data[Vind];
	  i++;
	}
      }

  i=0;  
  for(v.x=0;v.x<scn->xsize;v.x++)
    for(v.z=0;v.z<scn->zsize;v.z++)
      for(v.y=0;v.y<scn->ysize;v.y++) { 
	Vind = scn->tbz[v.z] + scn->tby[v.y] + v.x;
        if (scn->data[Vind] != 0) {
	  index = bshell->Mzx->tbrow[v.x] + v.z;
          if (bshell->Mzx->val[index] < 0) {
            bshell->Mzx->val[index]=i;
          }	  
	  bshell->pointer[i].i = GetBPointer(bshell,v);
	  bshell->pointer[i].y = v.y;
	  i++;
	}
      }
  bshell->PAxis = 0;
  return bshell;
}

void    DestroyBShell(BShell **bshell) {

  BShell *aux = *bshell;
  if(aux != NULL){
    if (aux->voxel    != NULL)  free(aux->voxel); 
    if (aux->pointer  != NULL)  free(aux->pointer);
    if (aux->normaltable  != NULL)  free(aux->normaltable);
    DestroyImage(&(aux->Myz));
    DestroyImage(&(aux->Mzx));
    free(aux);    
    *bshell = NULL;
  }

}


int GetBPointer(BShell *bshell, Voxel V) {

  int low,hi,mid,size,index;

  size = bshell->ysize * bshell->zsize;
  index = bshell->Myz->tbrow[V.z] + V.y;

  low = bshell->Myz->val[index];

  do {
    index++;
    if (index == size)
      return(bshell->nvoxels-1);
  } while ( bshell->Myz->val[index] < 0);

  hi = bshell->Myz->val[index]-1;

  /* Binary search for index using current coord x as key*/

  while (low <= hi) {
    mid = (low + hi)/2;
    if (V.x == bshell->voxel[mid].x)
      return(mid);
    if (V.x < bshell->voxel[mid].x)
      hi=mid-1;
    else 
      low=mid+1;
  }
  return(-1);
}

void SetBShellNormal (BShell *bshell, Scene *scn)
{  
  int i,i1,i2,mag;
  Voxel v;
  Vector normal;

  for (v.z = 0; v.z != bshell->zsize; v.z ++) 
    for (v.y = 0; v.y != bshell->ysize; v.y ++) {
      i = bshell->Myz->tbrow[v.z] + v.y;     
      if (bshell->Myz->val[i] >= 0) {	
	i1 = bshell->Myz->val[i];
	i++;
	while (bshell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = bshell->Myz->val[i];
	for (i = i1; i != i2; i++) {	  
	  v.x = bshell->voxel[i].x;
	  SetBVoxelNormal(scn,&v,&normal,&mag);
	  bshell->voxel[i].normal = GetNormalIndex(&normal);
	  bshell->voxel[i].mag = (ushort)mag;
	}        
      }
    }
}



void SetBVoxelNormal(Scene *scn, Voxel *v, Vector *normal, int *mag) {

  int Vind,i,value;
  double modn;
  AdjRel3 *A = Spheric(2.5);
  AdjVxl *V;

  if (scn == NULL){
    Error(MSG1,"SetBVoxelNormal");
  }

  normal->x = normal->y = normal->z = 0.0;

  Vind = scn->tbz[v->z] + scn->tby[v->y] + v->x;

  V = AdjVoxels(scn,A);
 
  for (i=0;i<V->n;i++) {
    if (ValidVoxel(scn, v->x+A->dx[i], v->y+A->dy[i], v->z+A->dz[i])) {
      value = -(scn->data[Vind + V->dp[i]] - scn->data[Vind]);      
    }
    normal->x += value * A->dx[i];
    normal->y += value * A->dy[i];
    normal->z += value * A->dz[i];
  }

  // normalization
  modn = sqrt((double) (normal->x * normal->x + normal->y * normal->y + normal->z * normal->z));
  *mag = (int)modn;

  if (modn > 0.0) {
    normal->x /= modn;
    normal->y /= modn;
    normal->z /= modn;
  }
  else {
    normal->x = 0.0;
    normal->y = 0.0;
    normal->z = 0.0;
  }
  DestroyAdjRel3(&A);
  DestroyAdjVxl(&V);
}



Image *SWBShellRendering(BShell *bshell,Context *cxt) {

  Image *img=NULL;
  FBuffer *shear=NULL,*warp=NULL;
  Voxel p,q,c;
  Pixel d;
  Vector viewer;
  AdjPxl *fprint=NULL;

  int u,v,ut,vt,uw,vw,is,iw,iw_p,i,i_p,i1,i2,j,n;
  float w,wt,amb,spec,diff,shading,opac,idist,cos_a,cos_2a,pow;
  uchar l;

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = (float)cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;

  // warp buffer translation
  d.x = cxt->width/2;
  d.y = cxt->height/2;

  shear = CreateFBuffer(cxt->isize, cxt->jsize);
  warp = CreateFBuffer(cxt->width, cxt->height);
  InitFBuffer(shear,1.0);
  InitFBuffer(warp,1.0);
  
  img=CreateImage(cxt->width, cxt->height);
  fprint = AdjPixels(img,cxt->footprint->adj);

  viewer.x = -cxt->IR[0][2];
  viewer.y = -cxt->IR[1][2];
  viewer.z = -cxt->IR[2][2];
    
  switch(cxt->PAxis) {

  case 'x':
    
    for (p.x = cxt->xi; p.x != cxt->xf; p.x += cxt->dx) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = bshell->Mzx->tbrow[p.x] + p.z;
        
        if (bshell->Mzx->val[i] >= 0) {
          
          if (cxt->dy == 1) {              
            i1 = bshell->Mzx->val[i];
            i++;
            while (bshell->Mzx->val[i] < 0) {
              i++;
            } 
            i2 = bshell->Mzx->val[i]-1;            
          } else {            
            i2 = bshell->Mzx->val[i];
            i++;
            while (bshell->Mzx->val[i] < 0) {
              i++;
            } 
            i1 = bshell->Mzx->val[i]-1;
	  }
	  i2 += cxt->dy;          
          for (i = i1; i != i2; i += cxt->dy) {

	    // shear
            p.y = bshell->pointer[i].y;

	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;

	    u = (int) (q.y + cxt->Su[p.x]); 
	    v = (int) (q.z + cxt->Sv[p.x]); 

	    is = u + ut + shear->tbv[v + vt];

	    if (shear->val[is] > 0.05) {
	    
	      // normal
	      i_p = bshell->pointer[i].i;
	      n = bshell->voxel[i_p].normal;

	      cos_a = cxt->viewer.x * bshell->normaltable[n].x +\
		cxt->viewer.y * bshell->normaltable[n].y +\
		cxt->viewer.z * bshell->normaltable[n].z;

	      if (cos_a > 0) {

		// shading
		l = bshell->voxel[i_p].obj;
		w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		idist = 1.0 - w/(float)cxt->depth;

		cos_2a = 2*cos_a*cos_a - 1.0;
	      
		if (cos_2a < 0.) {
		  pow = 0.;
		  spec = 0.;
		} else {
		  pow = 1.;
		  for (j=0; j < cxt->obj[l].ns; j++) 
		    pow = pow * cos_2a;
		  spec = cxt->obj[l].spec * pow;
		}

		opac = bshell->voxel[i_p].opac;	
		amb  = cxt->obj[l].amb;
		diff = cxt->obj[l].diff * cos_a;

		shading =  opac * 255. * (amb + idist * (diff + spec));

		//warp	      
		uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
	      
		vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);

		iw = warp->tbv[vw + d.y] + uw + d.x;
	      
		// splatting
		for (j=0; j < fprint->n; j++){		
		  iw_p = iw + fprint->dp[j];
		  if (warp->val[iw_p] > .05) {                
		    img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->footprint->val[j]);
		    warp->val[iw_p] *= (1.0- (opac * cxt->footprint->val[j]));
		  }
		}
		shear->val[is]=warp->val[iw];
	      }
	    }
	  }
	}
      }

    break;
    
  case 'y': 
    
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = bshell->Myz->tbrow[p.z] + p.y;
        
        if (bshell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = bshell->Myz->val[i];
            i++;
            while (bshell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = bshell->Myz->val[i]-1;            
          } else {            
            i2 = bshell->Myz->val[i];
            i++;
            while (bshell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = bshell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
            p.x = bshell->voxel[i].x;
	   
	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;
	    
	    u = (int) (q.z + cxt->Su[p.y]); 
	    v = (int) (q.x + cxt->Sv[p.y]); 

	    is = u + ut+ shear->tbv[v + vt];

	    if (shear->val[is] > 0.05) {
	      
	      // normal
	      i_p = i;
	      n = bshell->voxel[i_p].normal;

	      cos_a = cxt->viewer.x * bshell->normaltable[n].x +\
		cxt->viewer.y * bshell->normaltable[n].y +\
		cxt->viewer.z * bshell->normaltable[n].z;

	      if (cos_a > 0) {

		// shading
		l = bshell->voxel[i_p].obj;
		w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		idist = 1.0 - w/(float)cxt->depth;

		cos_2a = 2*cos_a*cos_a - 1.0;
		
		if (cos_2a < 0.) {
		  pow = 0.;
		  spec = 0.;
		} else {
		  pow = 1.;
		  for (j=0; j < cxt->obj[l].ns; j++) 
		    pow = pow * cos_2a;
		  spec = cxt->obj[l].spec * pow;
		}

		opac = bshell->voxel[i_p].opac;	
		amb  = cxt->obj[l].amb;
		diff = cxt->obj[l].diff * cos_a;
		
		shading =  opac * 255. * (amb + idist * (diff + spec));
		
		// warp	      
		uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		
		iw = warp->tbv[vw + d.y] + uw + d.x;
		
		// splatting
		for (j=0; j < fprint->n; j++){		
		  iw_p = iw + fprint->dp[j];
		  if (warp->val[iw_p] > .05) {                
		    img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->footprint->val[j]);
 		    warp->val[iw_p] *= (1.0- (opac * cxt->footprint->val[j]));
		  }
		}
		shear->val[is]=warp->val[iw];
	      }
	    }
	  }
	}
      }
    break;

  case 'z': 
    
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) 
      for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
        
        i = bshell->Myz->tbrow[p.z] + p.y;
        
        if (bshell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = bshell->Myz->val[i];
            i++;
            while (bshell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = bshell->Myz->val[i]-1;            
          } else {            
            i2 = bshell->Myz->val[i];
            i++;
            while (bshell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = bshell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
            p.x = bshell->voxel[i].x;

	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z; 

	    u = (int) (q.x + cxt->Su[p.z]); 
	    v = (int) (q.y + cxt->Sv[p.z]); 

	    is = u + ut + shear->tbv[v + vt];
	    
	    if (shear->val[is] > 0.05) {
	      
	      // normal
	      i_p = i;
	      n = bshell->voxel[i_p].normal;

	      cos_a = cxt->viewer.x * bshell->normaltable[n].x +\
		cxt->viewer.y * bshell->normaltable[n].y +\
		cxt->viewer.z * bshell->normaltable[n].z;

	      if (cos_a > 0) {

		// shading
		l = bshell->voxel[i_p].obj;
		w = cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + wt;
		idist = 1.0 - w/(float)cxt->depth;

		cos_2a = 2*cos_a*cos_a - 1.0;
		
		if (cos_2a < 0.) {
		  pow = 0.;
		  spec = 0.;
		} else {
		  pow = 1.;
		  for (j=0; j < cxt->obj[l].ns; j++) 
		    pow = pow * cos_2a;
		  spec = cxt->obj[l].spec * pow;
		}
		
		opac = bshell->voxel[i_p].opac;	
		amb  = cxt->obj[l].amb;
		diff = cxt->obj[l].diff * cos_a;
		
		shading =  opac * 255. * (amb + idist * (diff + spec));
		
		// warp
		uw = (int)(cxt->W[0][0] * u + cxt->W[0][1] * v);
		
		vw = (int)(cxt->W[1][0] * u + cxt->W[1][1] * v);
		
		iw = warp->tbv[vw + d.y] + uw + d.x;
		
		// splatting
		
		for (j=0; j < fprint->n; j++){		
		  iw_p = iw + fprint->dp[j];
		  if (warp->val[iw_p] > .05) {                
		    img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->footprint->val[j]);
		    warp->val[iw_p] *= (1.0- (opac * cxt->footprint->val[j]));
		  }
		}	      
		shear->val[is]=warp->val[iw];
	      }
	    }
	  }
	}
      }
    break;
      
  default: 
    Error(MSG1,"SWBShellRendering");
    break;
    
  }			
  DestroyFBuffer(&shear);
  DestroyFBuffer(&warp);
  DestroyAdjPxl(&fprint);
  return(img);
}

void ClassifyBShell (BShell *bshell, Curve *den, Curve *grad)
{  
  int i,i1,i2;
  Voxel v;
  Curve *fden,*fgrad;

  fden = FillCurve(den,1.0);
  fgrad = FillCurve(grad,1.0);

  for (v.z = 0; v.z != bshell->zsize; v.z ++) 
    for (v.y = 0; v.y != bshell->ysize; v.y ++) {
      i = bshell->Myz->tbrow[v.z] + v.y;     
      if (bshell->Myz->val[i] >= 0) {	
	i1 = bshell->Myz->val[i];
	i++;
	while (bshell->Myz->val[i] < 0) {
	  i++;
	} 
	i2 = bshell->Myz->val[i];
	for (i = i1; i != i2; i++) {	  
	  v.x = bshell->voxel[i].x;	  
	  bshell->voxel[i].opac *= fden->Y[bshell->voxel[i].val];
	  bshell->voxel[i].opac *= fgrad->Y[bshell->voxel[i].mag];
	}        
      }
    }
  DestroyCurve(&fden);
  DestroyCurve(&fgrad);
}	















