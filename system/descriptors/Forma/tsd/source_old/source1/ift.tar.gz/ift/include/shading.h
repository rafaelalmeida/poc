#ifndef _SHADING_H_
#define _SHADING_H_

#include "ift.h"

Image    *DepthShading(Context *cxt);
Vector    ZBuffNormal(int i, Context *cxt);
Image    *PhongShading(Context *cxt);
CImage   *Colorize(Context *cxt, Image *img);

#endif
