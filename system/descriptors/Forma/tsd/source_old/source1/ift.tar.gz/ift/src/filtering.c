#include "filtering.h"
#include "sort.h"
#include "common.h"
#include "segmentation.h"
#include "analysis.h"

Kernel *MakeKernel(char *coefs)
{
  Kernel *K;
  AdjRel *A;
  int xsize,ysize,i;

  sscanf(coefs,"%d",&xsize);
  coefs=strchr(coefs,',')+1;
  sscanf(coefs,"%d",&ysize);
  coefs=strchr(coefs,',')+1;

  A = Box(xsize, ysize);
  K = CreateKernel(A);
  for (i=0;i<A->n;i++) {
    sscanf(coefs,"%f",&K->val[i]);
    coefs=strchr(coefs,',')+1;
  }
  DestroyAdjRel(&A);
  return(K);
}

Kernel *CreateKernel(AdjRel *A)
{
  Kernel *K=NULL;
  int i;
  Pixel max, min;

  max.x = max.y = 0;
  min.x = min.y = 0;

  K = (Kernel *) calloc(1,sizeof(Kernel));
  if (K == NULL){
    Error(MSG1,"CreateKernel");
  }
  K->val = AllocFloatArray(A->n);
  K->adj = CreateAdjRel(A->n);

  for (i=0;i<A->n;i++) {
    max.x = MAX(A->dx[i],max.x);
    max.y = MAX(A->dy[i],max.y);
    min.x = MIN(A->dx[i],min.x);
    min.y = MIN(A->dy[i],min.y);
    K->adj->dx[i] = A->dx[i];
    K->adj->dy[i] = A->dy[i];
  }

  
  K->xsize = max.x - min.x + 1;
  K->ysize = max.y - min.y + 1;
  
  return(K);
}

void DestroyKernel(Kernel **K)
{
  Kernel *aux;

  aux = *K;
  if(aux != NULL){
    if (aux->val != NULL)   free(aux->val); 
    DestroyAdjRel(&(aux->adj));
    free(aux);    
    *K = NULL;
  }
}

Image *LinearFilter(Image *img, Kernel *K) /* generic kernel */ 
{
  Image *cimg;
  Pixel u,v;
  AdjPxl *pxl;
  int p,i;
  float conv;
  
  cimg = CreateImage(img->ncols,img->nrows);

  pxl = AdjPixels(img,K->adj);

  for (u.y=0; u.y < img->nrows; u.y++)
    for (u.x=0; u.x < img->ncols; u.x++){
      conv=0.0;
      for (i=0;i<K->adj->n;i++) {
	if (ValidPixel(img, v.x + K->adj->dx[i], v.y + K->adj->dy[i])){
	  p = v.x + img->tbrow[v.y] + pxl->dp[i];
	  conv += ((float)img->val[p])*K->val[i];	   
	}      
      p = u.x + cimg->tbrow[u.y];
      cimg->val[p] = (int)conv;
      }
    }
  DestroyAdjPxl(&pxl);
  return(cimg);
}

Image *ShapeFilter(Image *bin, float perc)
{
  Image *skel,*msskel,*cont,*filt;
  int p,n;      
  Pixel c,u;
  int r,dx,dy;
  AnnImg *aimg;
  AdjRel *A;

  /* Compute Euclidean IFT */

  cont = LabelContPixel(bin);
  aimg = Annotate(bin,NULL,cont);
  A    = Circular(1.5);
  n      = aimg->img->ncols*aimg->img->nrows;
  for(p = 0; p < n; p++)
    if (aimg->img->val[p] == 0){
      aimg->cost->val[p] = 0;
    }
  iftDilation(aimg,A);
  DestroyImage(&cont);
  DestroyAdjRel(&A);
  
  /* Compute MS Skeletons */

  msskel = CompMSSkel(aimg);

  /*  Compute Skeleton */

  skel = Skeleton(msskel,perc);
  DestroyImage(&msskel);

  /* Paint circles */ 

  filt = CreateImage(skel->ncols,skel->nrows);
  n = skel->ncols*skel->nrows;
  for (p=0; p < n; p++){
    if (skel->val[p]==1){
      c.x = p%skel->ncols;
      c.y = p/skel->ncols;
      r   = (int)sqrt(aimg->cost->val[p]);
      for(u.y = (c.y-r), dy=-r; u.y <= (c.y+r); u.y++,dy++)
	for(u.x = (c.x-r), dx=-r; u.x <= (c.x+r); u.x++,dx++)
	  if (ValidPixel(skel,u.x,u.y)&&((int)sqrt(dx*dx + dy*dy) <= r)){
	    if (aimg->cost->val[u.x + skel->tbrow[u.y]] > 0)
	      filt->val[u.x + skel->tbrow[u.y]] = 1;
	}
    }
  }

  DestroyImage(&skel);
  DeAnnotate(&aimg);

  return(filt);
}

Image *MedianFilter(Image *img, AdjRel *A)
{
  int *val,*oval,n,i,p,q;
  Pixel u,v;
  Image *med;

  val = AllocIntArray(A->n);
  med = CreateImage(img->ncols,img->nrows);
  for (u.y=0; u.y < img->nrows; u.y++)  
    for (u.x=0; u.x < img->ncols; u.x++) {
      p = u.x + img->tbrow[u.y];
      n = 0;
      for (i=0; i < A->n; i++) {
	v.x = u.x + A->dx[i];
	v.y = u.y + A->dy[i];
	if (ValidPixel(img,v.x,v.y)){
	  q = v.x + img->tbrow[v.y];
	  val[n] = img->val[q];
	  n++;
	}
      }
      oval = BucketSort(val,n,INCREASING);
      med->val[p] = oval[n/2];
      free(oval);
    }
  free(val);
  return(med);
}

Kernel *LinearKernel(AdjRel *A)
{
  float dmax,d=0;
  Kernel *K;
  int i;

  K = CreateKernel(A);
  dmax = K->xsize * K->ysize;

  for (i=0;i<A->n;i++) {
    d = A->dx[i] * A->dx[i] + A->dy[i] * A->dy[i];
    K->val[i] = 1.0 - (d / (dmax + 2.)); // squared d!
  }
  return(K);
}
