#include "shell.h"

Shell *CreateShell (Scene *scn, Context *cxt) {

  Shell *shell=NULL;
  int i,n,index,Vind;
  Voxel v;

  shell=(Shell *)calloc(1, sizeof(Shell));
  if (shell == NULL){
    Error(MSG1,"CreateShell");
  }

  if (cxt->normal == NULL){
    fprintf(stderr,"Warning: assuming gray scene as the normal based scene\n");
    SceneBasedNormal(scn,cxt);
  }

  n = scn->xsize * scn->ysize * scn->zsize; 

  shell->nvoxels=0;
  for (i=0;i<n;i++)  
    if (scn->data[i] != 0) 
      shell->nvoxels++;

  shell->xsize = scn->xsize;
  shell->ysize = scn->ysize;
  shell->zsize = scn->zsize;

  shell->voxel=(Attrib *)calloc(shell->nvoxels, sizeof(Attrib));
  if (shell->voxel == NULL) {
    Error(MSG1,"CreateShell");
  }

  shell->pointer=(PAttrib *)calloc(shell->nvoxels, sizeof(PAttrib));
  if (shell->pointer == NULL) {
    Error(MSG1,"CreateShell");
  }

  /* Myz and Mzx */

  shell->Myz=CreateImage(scn->ysize, scn->zsize+1);
  shell->Mzx=CreateImage(scn->zsize, scn->xsize+1);  

  SetImage(shell->Myz,-1);
  SetImage(shell->Mzx,-1);

  shell->Mzx->val[scn->zsize*scn->xsize] = shell->nvoxels;
  shell->Myz->val[scn->zsize*scn->ysize] = shell->nvoxels;

  CreateNormalTable(shell);

  i=0;

  for(v.z=0;v.z<scn->zsize;v.z++)
    for(v.y=0;v.y<scn->ysize;v.y++)
      for(v.x=0;v.x<scn->xsize;v.x++) { 
	Vind = scn->tbz[v.z] + scn->tby[v.y] + v.x;
        if (scn->data[Vind] != 0) {
	  index = shell->Myz->tbrow[v.z] + v.y;
	  if (shell->Myz->val[index] < 0) {
	    shell->Myz->val[index]=i;
	  }
  	  shell->voxel[i].x = v.x;
	  shell->voxel[i].opac = 1.;
	  shell->voxel[i].val = cxt->normal->data[Vind];
	  shell->voxel[i].normal = GetNormalIndex(shell,GetVoxelNormal(cxt->normal,v));
	  i++;
	}
      }

  i=0;  
  for(v.x=0;v.x<scn->xsize;v.x++)
    for(v.z=0;v.z<scn->zsize;v.z++)
      for(v.y=0;v.y<scn->ysize;v.y++) { 
	Vind = scn->tbz[v.z] + scn->tby[v.y] + v.x;
        if (scn->data[Vind] != 0) {
	  index = shell->Mzx->tbrow[v.x] + v.z;
          if (shell->Mzx->val[index] < 0) {
            shell->Mzx->val[index]=i;
          }	  
	  shell->pointer[i].i = GetPointer(shell,v);
	  shell->pointer[i].y = v.y;
	  i++;
	}
      }

  return shell;
}


Shell *CreateShell2 (Scene *scn,float *alpha,Context *cxt)
{
  Shell *shell=NULL;
  int i,j,Vind,index,xysize;
  Voxel v;

  shell=(Shell *)calloc(1, sizeof(Shell));
  if (shell == NULL){
    Error(MSG1,"CreateShell2");
  }

  if (cxt->normal == NULL){
    cxt->normal = scn;
  }

  xysize = scn->xsize * scn->ysize;
  shell->nvoxels = 0;

  for (v.z = 0; v.z != scn->zsize; v.z ++) 
    for (v.y = 0; v.y != scn->ysize; v.y ++) 
      for (v.x = 0; v.x != scn->xsize; v.x ++) {
	Vind = scn->tbz[v.z]+scn->tby[v.y]+v.x;
	if (scn->data[Vind] != 0) {
	  j = 0;
	  if (alpha[Vind] > .05) {
	    if (v.x > 0) {    
	      if  (alpha[Vind - 1] >= .95) j++;
	    }
	    if (v.x < scn->xsize - 1) {
	      if  (alpha[Vind + 1] >= .95) j++;
	    }
	    if (v.y > 0) {
	      if (alpha[Vind - scn->xsize] >= .95) j++;
	    }
	    if  (v.y < scn->ysize - 1) {
	      if (alpha[Vind + scn->xsize] >= .95) j++;
	    }
	    if (v.z > 0) {
	      if (alpha[Vind - xysize] >= .95) j++;
	    }
	    if (v.z < scn->zsize - 1) {
	      if (alpha[Vind + xysize] >= .95) j++;
	    }
	    if (j==6) 
	      alpha[Vind] = 0.;
	    else 
	      shell->nvoxels++;
	  } else
	    alpha[Vind] = 0.;
	}
      }
  
  shell->xsize = scn->xsize;
  shell->ysize = scn->ysize;
  shell->zsize = scn->zsize;

  shell->voxel=(Attrib *)calloc(shell->nvoxels, sizeof(Attrib));
  if (shell->voxel == NULL) {
    Error(MSG1,"CreateShell");
  }

  shell->pointer=(PAttrib *)calloc(shell->nvoxels, sizeof(PAttrib));
  if (shell->pointer == NULL) {
    Error(MSG1,"CreateShell");
  }

  /* Myz and Mzx */

  shell->Myz=CreateImage(scn->ysize, scn->zsize+1);
  shell->Mzx=CreateImage(scn->zsize, scn->xsize+1);  

  SetImage(shell->Myz,-1);
  SetImage(shell->Mzx,-1);

  shell->Mzx->val[scn->zsize*scn->xsize] = shell->nvoxels;
  shell->Myz->val[scn->zsize*scn->ysize] = shell->nvoxels;

  CreateNormalTable(shell);

  i=0;

  for(v.z=0;v.z<scn->zsize;v.z++)
    for(v.y=0;v.y<scn->ysize;v.y++)
      for(v.x=0;v.x<scn->xsize;v.x++) { 
	Vind = scn->tbz[v.z] + scn->tby[v.y] + v.x;
        if (scn->data[Vind] != 0 && alpha[Vind] != 0.) {
	  index = shell->Myz->tbrow[v.z] + v.y;
	  if (shell->Myz->val[index] < 0) {
	    shell->Myz->val[index]=i;
	  }
  	  shell->voxel[i].x = v.x;
	  shell->voxel[i].opac = alpha[Vind];
	  shell->voxel[i].val = cxt->normal->data[Vind];
	  shell->voxel[i].normal = GetNormalIndex(shell,GetVoxelNormal(cxt->normal,v));
	  i++;
	}
      }

  i=0;  
  for(v.x=0;v.x<scn->xsize;v.x++)
    for(v.z=0;v.z<scn->zsize;v.z++)
      for(v.y=0;v.y<scn->ysize;v.y++) { 
	Vind = scn->tbz[v.z] + scn->tby[v.y] + v.x;
        if (scn->data[Vind] != 0  && alpha[Vind] != 0.) {
	  index = shell->Mzx->tbrow[v.x] + v.z;
          if (shell->Mzx->val[index] < 0) {
            shell->Mzx->val[index]=i;
          }	  
	  shell->pointer[i].i = GetPointer(shell,v);
	  shell->pointer[i].y = v.y;
	  i++;
	}
      }

  if (cxt->normal == scn){
    cxt->normal = NULL;
  }

  return shell;
}

void    DestroyShell(Shell **shell) {

  Shell *aux = *shell;
  if(aux != NULL){
    if (aux->voxel    != NULL)  free(aux->voxel); 
    if (aux->pointer  != NULL)  free(aux->pointer);
    if (aux->normaltable  != NULL)  free(aux->normaltable);
    DestroyImage(&(aux->Myz));
    DestroyImage(&(aux->Mzx));
    free(aux);    
    *shell = NULL;
  }

}


int GetPointer(Shell *shell, Voxel V) {

  int low,hi,mid,size,index;

  size = shell->ysize * shell->zsize;
  index = shell->Myz->tbrow[V.z] + V.y;

  low = shell->Myz->val[index];

  do {
    index++;
    if (index == size)
      return(shell->nvoxels-1);
  } while ( shell->Myz->val[index] < 0);

  hi = shell->Myz->val[index]-1;

  /* Binary search for index using current coord x as key*/

  while (low <= hi) {
    mid = (low + hi)/2;
    if (V.x == shell->voxel[mid].x)
      return(mid);
    if (V.x < shell->voxel[mid].x)
      hi=mid-1;
    else 
      low=mid+1;
  }
  return(-1);
}




Vector GetVindNormal(Scene *scn, int Vind) {

  int u,v,w,xysize;
  int d[6]= {0,0,0,0,0,0};   // density for neighbours
  double modn;
  Vector normal;

  if (scn == NULL){
    Error(MSG1,"GetVindNormal");
  }

  normal.x = normal.y = normal.z = 0.0;

  xysize = scn->xsize * scn->ysize;

  u = (Vind % xysize) % scn->xsize;
  v = (Vind % xysize) / scn->xsize;
  w = Vind / xysize;

  if (u > 0) {
    d[0] = scn->data[Vind - 1];
  }
  if (u < scn->xsize - 1) {
    d[1] = scn->data[Vind + 1];
  }

  if (v > 0) {
    d[2] = scn->data[Vind - scn->xsize];
  }
  if (v < scn->ysize - 1) {
    d[3] = scn->data[Vind + scn->xsize];
  }

  if (w > 0) {
    d[4] = scn->data[Vind - xysize];
  }
  if (w < scn->zsize - 1) {
    d[5] = scn->data[Vind + xysize];
  }

  normal.x = d[0] - d[1];
  normal.y = d[2] - d[3];
  normal.z = d[4] - d[5];

  // normalization
  modn = sqrt((double) (normal.x * normal.x + normal.y * normal.y + normal.z * normal.z));

  if (modn > Epsilon) {
    normal.x /= modn;
    normal.y /= modn;
    normal.z /= modn;
  }
  else {
    normal.x = 0.0;
    normal.y = 0.0;
    normal.z = 0.0;
  }
  
  return(normal);
}

Vector GetVoxelNormal(Scene *scn, Voxel v) {

  int Vind,xysize;
  int d[6]= {0,0,0,0,0,0};   // density for neighbours
  double modn;
  Vector normal;

  if (scn == NULL){
    Error(MSG1,"GetVoxelNormal");
  }

  normal.x = normal.y = normal.z = 0.0;

  xysize = scn->xsize * scn->ysize;

  Vind = scn->tbz[v.z] + scn->tby[v.y] + v.x;

  if (v.x > 0) {    
    d[0] = scn->data[Vind - 1];
  }
  if (v.x < scn->xsize - 1) {
    d[1] = scn->data[Vind + 1];
  }

  if (v.y > 0) {
    d[2] = scn->data[Vind - scn->xsize];
  }
  if (v.y < scn->ysize - 1) {
    d[3] = scn->data[Vind + scn->xsize];
  }

  if (v.z > 0) {
    d[4] = scn->data[Vind - xysize];
  }
  if (v.z < scn->zsize - 1) {
    d[5] = scn->data[Vind + xysize];
  }

  normal.x = d[0] - d[1];
  normal.y = d[2] - d[3];
  normal.z = d[4] - d[5];

  // normalization
  modn = sqrt((double) (normal.x * normal.x + normal.y * normal.y + normal.z * normal.z));

  if (modn > Epsilon) {
    normal.x /= modn;
    normal.y /= modn;
    normal.z /= modn;
  }
  else {
    normal.x = 0.0;
    normal.y = 0.0;
    normal.z = 0.0;
  }
  
  return(normal);
}

ushort GetNormalIndex(Shell *shell, Vector V) {

  int gamma,alpha;
  ushort index;
  
  if ((V.x == 0.0) && (V.y == 0.0) && (V.z == 0.0)) {
    return(0);
  }  
  gamma = (int)(asin(V.z)*180.0/PI); /* [-90,90] */ 
  alpha = (int)(atan2(V.y,V.x)*180.0/PI); /* [-180,180] */
  if (alpha < 0)
    alpha += 360;
  index = ((gamma+90)*360) + alpha + 1;
     
  return(index);
}


void CreateNormalTable(Shell *shell) {

  int i,lin,col;
  float gamma,alpha;

  /* creates normal look-up table */
  shell->normaltable = (Vector*)calloc(65161,sizeof(Vector));

  if (shell->normaltable == NULL) {
    Error(MSG1,"CreateNormalTable");
  } 
  
  shell->normaltable[0].x = 0.0;
  shell->normaltable[0].y = 0.0;
  shell->normaltable[0].z = 0.0;

  i=1;
  for (lin=-90; lin <= 90; lin++){
    gamma = (PI*lin)/180.0;
    for (col=0; col < 360; col++){
      alpha = (PI*col)/180.0;
      shell->normaltable[i].x = cos(gamma)*cos(alpha);
      shell->normaltable[i].y = cos(gamma)*sin(alpha);
      shell->normaltable[i].z = sin(gamma);
      i++;
    }
  }
  
}

FBuffer *CreateFBuffer(int usize, int vsize)
{
  FBuffer *fbuff=NULL;
  int i;

  fbuff = (FBuffer *) calloc(1,sizeof(FBuffer));
  if (fbuff == NULL)
    Error(MSG1,"CreateFBuffer");

  fbuff->val    = AllocFloatArray(usize*vsize);
  fbuff->usize  = usize;
  fbuff->vsize  = vsize;
  fbuff->tbv    = AllocIntArray(vsize);
  fbuff->tbv[0] = 0;
  for (i=1; i < vsize; i++) 
    fbuff->tbv[i] = fbuff->tbv[i-1] + usize;
  
  return(fbuff);
}

void DestroyFBuffer(FBuffer **buff)
{
  FBuffer *aux = *buff;

  if (aux != NULL) {
    if (aux->val    != NULL) free(aux->val);
    if (aux->tbv    != NULL) free(aux->tbv);
    free(aux);
    *buff = NULL;
  }
}

void  InitFBuffer(FBuffer *fbuff, float f)
{
  int i,u,v;
  
  for(v=0; v < fbuff->vsize; v++) 
    for(u=0; u < fbuff->usize; u++) {
      i = u + fbuff->tbv[v];
      fbuff->val[i]   = f;
    }
}



Image *SWShellRendering(Shell *shell,Context *cxt) {

  Image *img=NULL;
  FBuffer *shear=NULL,*warp=NULL;
  Voxel p,q,c;
  Vector viewer;

  int u,v,w,ut,vt,wt,uw,vw,is,iw,iw_p,i,i_p,i1,i2,j,n;
  float amb,spec,diff,shading,opac,idist,cos_a,cos_2a,pow;
  uchar l;

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;


  shear = CreateFBuffer(cxt->isize, cxt->jsize);
  warp = CreateFBuffer(cxt->width, cxt->height);
  InitFBuffer(shear,1.0);
  InitFBuffer(warp,1.0);
  
  img=CreateImage(cxt->zbuff->usize, cxt->zbuff->vsize);

  viewer.x = -cxt->IR[0][2];
  viewer.y = -cxt->IR[1][2];
  viewer.z = -cxt->IR[2][2];
    
  switch(cxt->PAxis) {

  case 'x':
    
    for (p.x = cxt->xi; p.x != cxt->xf; p.x += cxt->dx) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Mzx->tbrow[p.x] + p.z;
        
        if (shell->Mzx->val[i] >= 0) {
          
          if (cxt->dy == 1) {              
            i1 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i2 = shell->Mzx->val[i]-1;            
          } else {            
            i2 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i1 = shell->Mzx->val[i]-1;
	  }
	  i2 += cxt->dy;          
          for (i = i1; i != i2; i += cxt->dy) {

	    // shear
            p.y = shell->pointer[i].y;

	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;

	    u = (int) (q.y + cxt->Su[p.x] + ut); 
	    v = (int) (q.z + cxt->Sv[p.x] + vt); 

	    is = u + shear->tbv[v];

	    if (shear->val[is] > 0.05) {
	    
	      // shading
	      w = (int)(cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + cxt->R[2][3]) + wt;

	      idist = (cxt->depth - w);

	      i_p = shell->pointer[i].i;
	      n = shell->voxel[i_p].normal;
	      l = shell->voxel[i_p].obj;

	      cos_a = fabs(cxt->viewer.x * shell->normaltable[n].x +\
			   cxt->viewer.y * shell->normaltable[n].y +\
			   cxt->viewer.z * shell->normaltable[n].z);

	      cos_2a = 2*cos_a*cos_a - 1.0;
	      
	      if (cos_2a < 0.) {
		pow = 0.;
	        spec = 0.;
	      } else {
		pow = 1.;
		for (j=0; j < cxt->obj[l].ns; j++) 
		  pow = pow*cos_2a;
		spec = cxt->obj[l].spec * pow;
	      }

	      opac = shell->voxel[i_p].opac;	
	      amb  = cxt->obj[l].amb  * 255.;
	      diff = cxt->obj[l].diff * cos_a;

	      shading =  opac * (amb + idist * (diff + spec));

	      //warp	      
	      uw = ROUND(cxt->W[0][0] * (u-warp->usize/2) + cxt->W[0][1] * (v-warp->vsize/2)) + warp->usize/2 ;
	      
	      vw = ROUND(cxt->W[1][0] * (u-warp->usize/2) + cxt->W[1][1] * (v-warp->vsize/2)) + warp->vsize/2 ;

	      iw = warp->tbv[vw] + uw;
	      
              // splatting
	      for (j=0; j < cxt->fprint->n; j++){		
		iw_p = iw + cxt->fprint->dp[j];
		if (warp->val[iw_p] > .05) {                
		  img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->fopac[j]);
		  warp->val[iw_p] *= (1.0- (opac * cxt->fopac[j]));
		}
	      }
	      shear->val[is]=warp->val[iw];
	    }
	  }
	}
      }
    break;
    
  case 'y': 
    
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
            p.x = shell->voxel[i].x;
	   
	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;
	    
	    u = (int) (q.z + cxt->Su[p.y] + ut); 
	    v = (int) (q.x + cxt->Sv[p.y] + vt); 

	    is = u + shear->tbv[v];

	    if (shear->val[is] > 0.05) {
	      
	      // shading
	      w = (int)(cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + cxt->R[2][3]) + wt;
	    
	      idist = (cxt->depth - w);

	      i_p = i;
	      n = shell->voxel[i_p].normal;
	      l = shell->voxel[i_p].obj;

	      cos_a = fabs(cxt->viewer.x * shell->normaltable[n].x +\
			   cxt->viewer.y * shell->normaltable[n].y +\
			   cxt->viewer.z * shell->normaltable[n].z);

	      cos_2a = 2*cos_a*cos_a - 1.0;
	      
	      if (cos_2a < 0.) {
		pow = 0.;
	        spec = 0.;
	      } else {
		pow = 1.;
		for (j=0; j < cxt->obj[l].ns; j++) 
		  pow = pow*cos_2a;
		spec = cxt->obj[l].spec * pow;
	      }

	      opac = shell->voxel[i_p].opac;	
	      amb  = cxt->obj[l].amb  * 255.;
	      diff = cxt->obj[l].diff * cos_a;

	      shading =  opac * (amb + idist * (diff + spec));

	      // warp	      
	      uw = ROUND(cxt->W[0][0] * (u-warp->usize/2) + cxt->W[0][1] * (v-warp->vsize/2)) + warp->usize/2 ;
	      
	      vw = ROUND(cxt->W[1][0] * (u-warp->usize/2) + cxt->W[1][1] * (v-warp->vsize/2)) + warp->vsize/2 ;

	      iw = warp->tbv[vw] + uw;
	      
              // splatting
	      for (j=0; j < cxt->fprint->n; j++){		
		iw_p = iw + cxt->fprint->dp[j];
		if (warp->val[iw_p] > .05) {                
		  img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->fopac[j]);
		  warp->val[iw_p] *= (1.0- (opac * cxt->fopac[j]));
		}
	      }
	      shear->val[is]=warp->val[iw];
	    }
	  }
	}
      }
    break;

  case 'z': 
    
    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) 
      for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
            p.x = shell->voxel[i].x;

	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z; 

	    u = (int) (q.x + cxt->Su[p.z] + ut); 
	    v = (int) (q.y + cxt->Sv[p.z] + vt); 

	    is = u + shear->tbv[v];
	    
	    if (shear->val[is] > 0.05) {
	      
	      // shading
	      w = (int)(cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + cxt->R[2][3]) + wt;
	      
	      idist = (cxt->depth - w);

	      i_p = i;
	      n = shell->voxel[i_p].normal;
	      l = shell->voxel[i_p].obj;

	      cos_a = fabs(cxt->viewer.x * shell->normaltable[n].x +\
			   cxt->viewer.y * shell->normaltable[n].y +\
			   cxt->viewer.z * shell->normaltable[n].z);

	      cos_2a = 2*cos_a*cos_a - 1.0;
	      
	      if (cos_2a < 0.) {
		pow = 0.;
	        spec = 0.;
	      } else {
		pow = 1.;
		for (j=0; j < cxt->obj[l].ns; j++) 
		  pow = pow*cos_2a;
		spec = cxt->obj[l].spec * pow;
	      }

	      opac = shell->voxel[i_p].opac;	
	      amb  = cxt->obj[l].amb  * 255.;
	      diff = cxt->obj[l].diff * cos_a;

	      shading =  opac * (amb + idist * (diff + spec));
	      
	      // warp
	      uw = ROUND(cxt->W[0][0] * (u-warp->usize/2) + cxt->W[0][1] * (v-warp->vsize/2)) + warp->usize/2 ;
	      
	      vw = ROUND(cxt->W[1][0] * (u-warp->usize/2) + cxt->W[1][1] * (v-warp->vsize/2)) + warp->vsize/2 ;

	      iw = warp->tbv[vw] + uw;
	      
              // splatting

	      for (j=0; j < cxt->fprint->n; j++){		
		iw_p = iw + cxt->fprint->dp[j];
		if (warp->val[iw_p] > .05) {                
		  img->val[iw_p] += (int)(shading * warp->val[iw_p] * cxt->fopac[j]);
		  if (cxt->zbuff->voxel[iw_p] == NIL) {
		    cxt->zbuff->object[iw_p] = shell->voxel[i_p].val;
		    cxt->zbuff->dist[iw_p]  = idist;
		    cxt->zbuff->voxel[iw_p] = i_p;
		  }
		  warp->val[iw_p] *= (1.0- (opac * cxt->fopac[j]));
		}
	      }	      
	      shear->val[is]=warp->val[iw];
	    }
	  }
	}
      }
    break;
      
  default: 
    Error(MSG1,"ShellRendering");
    break;
    
  }			
  DestroyFBuffer(&shear);
  DestroyFBuffer(&warp);
  return(img);
}

		
Image *ShellRendering (Shell *shell, Context *cxt) {

  Image *img=NULL;
  FBuffer *buff=NULL;
  Voxel p,q;
  Vector viewer;

  int u,v,w,i1,i2,i,i_p,is,j,n;
  float amb,spec,diff,shading,opac,idist,cos_a,cos_2a,pow;
  uchar l;

  buff = CreateFBuffer(cxt->zbuff->usize, cxt->zbuff->vsize);
  InitFBuffer(buff,1.0);
 
  img = CreateImage(cxt->zbuff->usize, cxt->zbuff->vsize);

  viewer.x = -cxt->IR[0][2];
  viewer.y = -cxt->IR[1][2];
  viewer.z = -cxt->IR[2][2];
    
  for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) 
    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
        
      i = shell->Myz->tbrow[p.z] + p.y;
        
      if (shell->Myz->val[i] >= 0) {
	
	if (cxt->dx == 1) {              
	  i1 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i2 = shell->Myz->val[i]-1;            
	} else {            
	  i2 = shell->Myz->val[i];
	  i++;
	  while (shell->Myz->val[i] < 0) {
	    i++;
	  } 
	  i1 = shell->Myz->val[i]-1;
	}
	i2 += cxt->dx;

	for (i = i1; i != i2; i += cxt->dx) {
	  
	  p.x = shell->voxel[i].x;

	  q.x = p.x - cxt->xsize/2;
	  q.y = p.y - cxt->ysize/2;
	  q.z = p.z - cxt->zsize/2;
	  
	  u = (int)((cxt->R[0][0]*q.x) + (cxt->R[0][1]*q.y) + (cxt->R[0][2]*q.z) + cxt->R[0][3] + cxt->zbuff->usize/2);
	  v = (int)((cxt->R[1][0]*q.x) + (cxt->R[1][1]*q.y) + (cxt->R[1][2]*q.z) + cxt->R[1][3] + cxt->zbuff->usize/2);

	  i_p = u + buff->tbv[v];

	  if (buff->val[i_p] > 0.05){
	    
	      w = (int)((cxt->R[2][0]*q.x) + (cxt->R[2][1]*q.y) + (cxt->R[2][2]*q.z) + cxt->R[2][3] + cxt->zbuff->usize/2);
	   	    
	      idist = (cxt->zbuff->usize - w);

	      n = shell->voxel[i].normal;
	      l = shell->voxel[i].obj;

	      cos_a = ScalarProd(viewer,shell->normaltable[n]);
          	      
	      if (cos_a < -1.0) 
		cos_a = -1.0; 
	      else if (cos_a > 1.0) 
		cos_a = 1.0;	      
	      
	      if (cos_a < -Epsilon)	
		cos_a = 0.;
	      
	      cos_2a = 2*cos_a*cos_a-1;
	      
	      if (cos_2a < 0.)	  /* |angle| >45° */
		pow = 0.;
	      else {
		pow = 1.;		
		for (j=0; j < cxt->obj[l].ns; j++)
		  pow = pow*cos_2a;
	      }
	      opac  = (float)shell->voxel[i].opac;
	      amb  = cxt->obj[l].amb  * 255.;
	      diff = cxt->obj[l].diff * cos_a;
	      spec = cxt->obj[l].spec * pow;
	      shading =  opac * (amb + idist * (diff + spec));
	      
              /* Splatting */
	      for (j=0; j < cxt->fprint->n; j++){		
		is = i_p + cxt->fprint->dp[j];
		if (buff->val[is] > .05) {                
		  img->val[is] += (int)(shading * buff->val[is] * cxt->fopac[j]);
		  cxt->zbuff->object[is] = shell->voxel[i].val;
		  buff->val[is] *= (1.0- (opac * cxt->fopac[j]));
		}
	      }	  
	    }
	  }
	}
      }

  DestroyFBuffer(&buff);

  return(img);
}


Image *ISWShellRendering(Shell *shell,Context *cxt) 
{
  Image *img=NULL;
  Image *tmpimg=NULL;
  FBuffer *shear=NULL;
  Voxel p,q,c;

  int u,v,w,uw,vw,ut,vt,wt,is,is_p,iw,i,i_p,i1,i2,j,n,idist;
  float amb,spec,diff,shading,opac,cos_a,cos_2a,pow;
  uchar l;

  shear = CreateFBuffer(cxt->isize, cxt->jsize);
  
  InitFBuffer(shear,1.0);
  
  img=CreateImage(cxt->width, cxt->height);
  tmpimg=CreateImage(cxt->isize, cxt->jsize);

  // image translation
  ut = cxt->isize/2; 
  vt = cxt->jsize/2;
  wt = cxt->depth/2;

  // scene translation
  c.x = cxt->xsize/2;
  c.y = cxt->ysize/2;
  c.z = cxt->zsize/2;


  switch(cxt->PAxis) {

  case 'x':

    for (p.x = cxt->xi; p.x != cxt->xf; p.x += cxt->dx) 
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Mzx->tbrow[p.x] + p.z;
        
        if (shell->Mzx->val[i] >= 0) {
          
          if (cxt->dy == 1) {              
            i1 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i2 = shell->Mzx->val[i]-1;            
          } else {            
            i2 = shell->Mzx->val[i];
            i++;
            while (shell->Mzx->val[i] < 0) {
              i++;
            } 
            i1 = shell->Mzx->val[i]-1;
	  }
	  i2 += cxt->dy;
	
          for (i = i1; i != i2; i += cxt->dy) {

	    // shear
            p.y = shell->pointer[i].y;

	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;

	    u = (int) (q.y + cxt->Su[p.x] + ut); 
	    v = (int) (q.z + cxt->Sv[p.x] + vt); 

	    is = u + shear->tbv[v];

	    if (shear->val[is] > 0.05) {
	    
	      // shading
	      w = (int)(cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + cxt->R[2][3]) + wt;

	      idist = (cxt->depth - w);

	      i_p = shell->pointer[i].i;
	      n = shell->voxel[i_p].normal;
	      l = shell->voxel[i_p].obj;

	      cos_a = fabs(cxt->viewer.x * shell->normaltable[n].x +\
			   cxt->viewer.y * shell->normaltable[n].y +\
			   cxt->viewer.z * shell->normaltable[n].z);

	      cos_2a = 2*cos_a*cos_a - 1.0;
	      
	      if (cos_2a < 0.) {
		pow = 0.;
	        spec = 0.;
	      } else {
		pow = 1.;
		for (j=0; j < cxt->obj[l].ns; j++) 
		  pow = pow*cos_2a;
		spec = cxt->obj[l].spec * pow;
	      }

	      opac = shell->voxel[i_p].opac;	
	      amb  = cxt->obj[l].amb  * 255.;
	      diff = cxt->obj[l].diff * cos_a;

	      shading =  opac * (amb + idist * (diff + spec));

	      // splatting
              for (j=0;j<cxt->fprint->n;j++) {
		is_p = is + cxt->fprint->dp[j];
		if (shear->val[is_p] > 0.05) {		  
		  tmpimg->val[is_p] += (shading * shear->val[is_p]);
		  shear->val[is_p] *= (1.0- (opac));	      
		}
	      }
	    }
	  }
	}
      }

    break;  
    
  case 'y': 

    for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy)
      for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {
          
          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;          
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
            p.x = shell->voxel[i].x;
	   
	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z;
	    
	    u = (int) (q.z + cxt->Su[p.y] + ut); 
	    v = (int) (q.x + cxt->Sv[p.y] + vt); 

	    is = u + shear->tbv[v];

	    if (shear->val[is] > 0.05) {
	      
	      // shading
	      w = (int)(cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + cxt->R[2][3]) + wt;
	    
	      idist = (cxt->depth - w);

	      i_p = i;
	      n = shell->voxel[i_p].normal;
	      l = shell->voxel[i_p].obj;

	      cos_a = fabs(cxt->viewer.x * shell->normaltable[n].x +\
			   cxt->viewer.y * shell->normaltable[n].y +\
			   cxt->viewer.z * shell->normaltable[n].z);

	      cos_2a = 2*cos_a*cos_a - 1.0;
	      
	      if (cos_2a < 0.) {
		pow = 0.;
	        spec = 0.;
	      } else {
		pow = 1.;
		for (j=0; j < cxt->obj[l].ns; j++) 
		  pow = pow*cos_2a;
		spec = cxt->obj[l].spec * pow;
	      }

	      opac = shell->voxel[i_p].opac;	
	      amb  = cxt->obj[l].amb  * 255.;
	      diff = cxt->obj[l].diff * cos_a;

	      shading =  opac * (amb + idist * (diff + spec));

	      // splatting
              for (j=0;j<cxt->fprint->n;j++) {
		is_p = is + cxt->fprint->dp[j];
		if (shear->val[is_p] > 0.05) {		  
		  tmpimg->val[is_p] += (shading * shear->val[is_p]);
		  shear->val[is_p] *= (1.0- (opac));	      
		}
	      }
	    }
	  }
	}
      }

    break;  

  case 'z': 

    for (p.z = cxt->zi; p.z != cxt->zf; p.z += cxt->dz)
      for (p.y = cxt->yi; p.y != cxt->yf; p.y += cxt->dy) {
        
        i = shell->Myz->tbrow[p.z] + p.y;
        
        if (shell->Myz->val[i] >= 0) {

          if (cxt->dx == 1) {              
            i1 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i2 = shell->Myz->val[i]-1;            
          } else {            
            i2 = shell->Myz->val[i];
            i++;
            while (shell->Myz->val[i] < 0) {
              i++;
            } 
            i1 = shell->Myz->val[i]-1;
	  }
	  i2 += cxt->dx;
          for (i = i1; i != i2; i += cxt->dx) {

	    // shear
            p.x = shell->voxel[i].x;

	    q.x = p.x - c.x;
	    q.y = p.y - c.y;
	    q.z = p.z - c.z; 

	    u = (int) (q.x + cxt->Su[p.z] + ut); 
	    v = (int) (q.y + cxt->Sv[p.z] + vt); 

	    is = u + shear->tbv[v];
	    
	    if (shear->val[is] > 0.05) {
	      
	      // shading
	      w = (int)(cxt->R[2][0]*q.x + cxt->R[2][1]*q.y + cxt->R[2][2]*q.z + cxt->R[2][3]) + wt;
	      
	      idist = (cxt->depth - w);

	      i_p = i;
	      n = shell->voxel[i_p].normal;
	      l = shell->voxel[i_p].obj;

	      cos_a = fabs(cxt->viewer.x * shell->normaltable[n].x +\
			   cxt->viewer.y * shell->normaltable[n].y +\
			   cxt->viewer.z * shell->normaltable[n].z);

	      cos_2a = 2*cos_a*cos_a - 1.0;
	      
	      if (cos_2a < 0.) {
		pow = 0.;
	        spec = 0.;
	      } else {
		pow = 1.;
		for (j=0; j < cxt->obj[l].ns; j++) 
		  pow = pow*cos_2a;
		spec = cxt->obj[l].spec * pow;
	      }

	      opac = shell->voxel[i_p].opac;	
	      amb  = cxt->obj[l].amb  * 255.;
	      diff = cxt->obj[l].diff * cos_a;

	      shading =  opac * (amb + idist * (diff + spec));

	      // splatting
              for (j=0;j<cxt->fprint->n;j++) {
		is_p = is + cxt->fprint->dp[j];
		if (shear->val[is_p] > 0.05) {		  
		  tmpimg->val[is_p] += (shading * shear->val[is_p]);
		  shear->val[is_p] *= (1.0- (opac));	      
		}
	      }
	    }
	  }
	}
      }
    break;
      
  default: 
    Error(MSG1,"ShellRendering");
    break;    
  }

  c.x = img->nrows/2; 
  c.y = img->ncols/2;
  
  for (vw=0;vw<img->nrows;vw++)
    for (uw=0;uw<img->ncols;uw++) {      

      u = (int)(cxt->IW[0][0] * (uw-c.x) + cxt->IW[0][1] * (vw-c.y)) + ut;
      v = (int)(cxt->IW[1][0] * (uw-c.x) + cxt->IW[1][1] * (vw-c.y)) + vt;
       
      if (ValidPixel(tmpimg,u,v)) {
	i = tmpimg->tbrow[v] + u; 		
	iw = img->tbrow[vw] + uw;	
	img->val[iw] = (int)tmpimg->val[i];
      }
    }  
  
  DestroyFBuffer(&shear);
  DestroyImage(&tmpimg);
  return(img);
}

















